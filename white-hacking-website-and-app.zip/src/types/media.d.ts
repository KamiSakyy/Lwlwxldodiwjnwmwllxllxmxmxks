declare module "mux.js" {
  type Segment = { type: string; data: Uint8Array; initSegment: Uint8Array };
  class Transmuxer {
    constructor(options?: { remux?: boolean; keepOriginalTimestamps?: boolean; baseMediaDecodeTime?: number });
    on(event: "data", callback: (segment: Segment) => void): void;
    on(event: "done", callback: () => void): void;
    on(event: "error", callback: (error: Error) => void): void;
    push(data: Uint8Array): void;
    flush(): void;
    dispose(): void;
    reset(): void;
    setBaseMediaDecodeTime(time: number): void;
  }
  const muxjs: { mp4: { Transmuxer: typeof Transmuxer } };
  export default muxjs;
}

declare module "m3u8-parser" {
  export type ByteRange = { length: number; offset?: number };
  export type Segment = {
    uri: string; duration: number; discontinuity?: boolean;
    byterange?: ByteRange;
    key?: { method: string; uri?: string; iv?: Uint32Array; keyFormat?: string };
    map?: { uri: string; byterange?: ByteRange };
  };
  export type Manifest = {
    endList?: boolean; mediaSequence?: number; segments: Segment[];
    playlists?: { uri: string; attributes: { RESOLUTION?: { width: number; height: number }; BANDWIDTH?: number; AUDIO?: string } }[];
    mediaGroups?: { AUDIO?: Record<string, Record<string, { uri?: string }>> };
  };
  export class Parser {
    constructor(options?: { url?: string });
    push(content: string): void;
    end(): void;
    manifest: Manifest;
  }
}