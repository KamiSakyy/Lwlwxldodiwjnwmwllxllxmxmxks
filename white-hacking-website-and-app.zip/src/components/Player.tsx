import { useCallback, useEffect, useRef, useState, type MouseEvent } from "react";
import { AnimatePresence } from "framer-motion";
import { ArrowDownToLine, ArrowLeftRight, ChevronRight, Cpu, Expand, LoaderCircle, LockKeyhole, Maximize, Minimize, Pause, PictureInPicture2, Play, RotateCcw, RotateCw, Settings2, SkipBack, SkipForward, UnlockKeyhole, Volume2, VolumeX, WifiOff, X } from "lucide-react";
import { fmtTime, img, qualities, titleOf, type Episode, type Release, type VideoQuality } from "../api";
import { getQuality, progressOf, saveProgress, setEpisodeWatched, setQuality } from "../store";
import { VideoEnhancer, type EnhanceOptions, type EnhanceStats } from "../lib/enhancer";
import { readEnhance, readPreference, savePreference } from "../lib/preferences";
import { useDownloads } from "../lib/downloads";
import { emptyPlayback, SingleMediaSession, type PlaybackState } from "../lib/mediaSession";
import { resolveEpisodeMedia } from "../lib/resolveMedia";
import { isDownloadActive } from "../lib/mediaCoordinator";
import { episodeNumber, sourcesForVoice } from "../lib/playback";
import PlayerSettings, { type PlayerTab } from "./PlayerSettings";

type Props = {
  release: Release; episode: Episode; episodes: Episode[]; voice?: string; voiceName?: string;
  onChange: (ordinal: number) => void; localSource?: string; onAlternative?: () => void;
};

export default function Player({ release, episode, episodes, voice = "primary", voiceName = "Основная озвучка", onChange, localSource, onAlternative }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sessionRef = useRef<SingleMediaSession | null>(null);
  const enhancerRef = useRef<VideoEnhancer | null>(null);
  const resumeRef = useRef({ key: "", time: 0, wantsPlay: true });
  const forcePlayNext = useRef(false);
  const hideTimer = useRef(0);
  const noticeTimer = useRef(0);
  const tapTimer = useRef(0);
  const lastTap = useRef({ time: 0, zone: 0 });
  const [playback, setPlayback] = useState<PlaybackState>(emptyPlayback);
  const [preference, setPreference] = useState<VideoQuality>(getQuality);
  const [retry, setRetry] = useState(0);
  const [backupFor, setBackupFor] = useState("");
  const [volume, setVolume] = useState(() => Math.max(0, Math.min(1, readPreference("volume", .85))));
  const [muted, setMuted] = useState(false);
  const [speed, setSpeed] = useState(() => Math.max(.5, Math.min(2, readPreference("speed", 1))));
  const [controls, setControls] = useState(true);
  const [locked, setLocked] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);
  const [immersive, setImmersive] = useState(false);
  const [cover, setCover] = useState(false);
  const [panel, setPanel] = useState<PlayerTab | null>(null);
  const [notice, setNotice] = useState("");
  const [autoNext, setAutoNext] = useState(() => readPreference("autoNext", true));
  const [autoSkip, setAutoSkip] = useState(() => readPreference("autoSkip", false));
  const [countdown, setCountdown] = useState<number | null>(null);
  const [sleepAt, setSleepAt] = useState(() => readPreference("sleepAt", 0));
  const [enhance, setEnhance] = useState<EnhanceOptions>(readEnhance);
  const [stats, setStats] = useState<EnhanceStats | null>(null);
  const [gpuError, setGpuError] = useState("");
  const [downloadQuality, setDownloadQuality] = useState<VideoQuality>(preference);
  const { jobs, start: startDownload } = useDownloads();

  const key = localSource ? `file:${localSource}` : `${release.id}:${voice}:${episode.ordinal}`;
  const useBackup = backupFor === key;
  const index = episodes.findIndex((item) => item.ordinal === episode.ordinal);
  const previous = index > 0 ? episodes[index - 1] : undefined;
  const next = index >= 0 ? episodes[index + 1] : undefined;
  const time = playback.time;
  const duration = playback.duration || episode.duration || 0;
  const playing = playback.playing;
  const loaded = playback.ready;
  const buffering = ["resolving", "loading", "buffering"].includes(playback.status);
  const error = playback.status === "error" ? playback.error : "";
  const quality = playback.variant?.quality || preference;
  const available = localSource ? [] : playback.media?.variants.map((variant) => variant.quality) || qualities(episode);
  const downloading = jobs.some((job) => job.status === "loading") || isDownloadActive();
  const videoSourceKey = `${key}:${playback.variant?.url || ""}`;
  const latest = useRef({ release, episode, voice, volume, speed, next, autoNext, panel, localSource });
  latest.current = { release, episode, voice, volume, speed, next, autoNext, panel, localSource };
  const enhanceRef = useRef(enhance);
  enhanceRef.current = enhance;

  const notify = useCallback((message: string) => {
    clearTimeout(noticeTimer.current); setNotice(message);
    noticeTimer.current = window.setTimeout(() => setNotice(""), 3500);
  }, []);
  const revealControls = useCallback(() => {
    clearTimeout(hideTimer.current); setControls(true);
    hideTimer.current = window.setTimeout(() => { if (!videoRef.current?.paused && !latest.current.panel) setControls(false); }, 3200);
  }, []);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    let live = true;
    let session: SingleMediaSession | null = null;
    const context = latest.current;
    const saved = context.localSource ? undefined : progressOf(context.release.id, context.voice, context.episode.ordinal);
    const same = resumeRef.current.key === key;
    const position = same ? resumeRef.current.time : saved?.time || 0;
    setPlayback({ ...emptyPlayback, time: position, duration: context.episode.duration || 0 });
    setCountdown(null); setStats(null); setControls(true);
    // Defer only session creation, so StrictMode's cancelled setup never starts
    // a second manifest request. Dependencies are content identity, not objects.
    const startTimer = window.setTimeout(() => {
      if (!live) return;
      session = new SingleMediaSession(video, {
        local: Boolean(context.localSource), quality: preference, initialTime: position,
        autoplay: same ? resumeRef.current.wantsPlay : true, volume: context.volume, speed: context.speed,
        resolve: (signal) => context.localSource
          ? Promise.resolve({ variants: [{ quality: preference, url: context.localSource, kind: "mp4" }], sourceId: "local", voiceId: "local" })
          : resolveEpisodeMedia(context.release, context.episode, context.voice, signal, retry > 0, useBackup),
        update: (state) => {
          if (!live) return;
          setPlayback(state);
          if (state.status === "error" && !useBackup && !context.localSource
            && state.media?.sourceId.startsWith("primary:") && !/401|403/.test(state.code)
            && sourcesForVoice(latest.current.episode, context.voice).length) {
            setBackupFor(key);
            notify("Восстанавливаем выбранную озвучку с того же момента.");
          }
        },
        save: (position, length) => { if (!context.localSource) saveProgress(context.release, context.episode.ordinal, position, length, context.voice, voiceName); },
        ended: () => {
          if (!live) return;
          if (!context.localSource) setEpisodeWatched(context.release.id, context.episode.ordinal, true, context.voice);
          if (latest.current.autoNext && latest.current.next) setCountdown(6);
        },
      });
      sessionRef.current = session;
      forcePlayNext.current = false;
      void session.start();
    }, 0);
    return () => {
      live = false; clearTimeout(startTimer);
      if (session) {
        const snapshot = session.snapshot();
        resumeRef.current = { key, time: snapshot.time, wantsPlay: forcePlayNext.current || snapshot.wantsPlay };
        void session.stop();
        if (sessionRef.current === session) sessionRef.current = null;
      }
    };
  }, [key, preference, retry, useBackup, notify]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    const changed = () => { setVolume(video.volume); setMuted(video.muted); savePreference("volume", video.volume); };
    video.addEventListener("volumechange", changed);
    return () => video.removeEventListener("volumechange", changed);
  }, []);
  useEffect(() => {
    if (videoRef.current) { videoRef.current.defaultPlaybackRate = speed; videoRef.current.playbackRate = speed; }
    savePreference("speed", speed);
  }, [speed]);
  useEffect(() => { if (playing) revealControls(); else setControls(true); }, [playing, revealControls]);
  useEffect(() => { savePreference("autoNext", autoNext); }, [autoNext]);
  useEffect(() => { savePreference("autoSkip", autoSkip); }, [autoSkip]);

  const opening = playback.media?.opening ?? episode.opening;
  const ending = playback.media?.ending ?? episode.ending;
  useEffect(() => {
    if (autoSkip && playing && opening?.start != null && opening.stop != null && opening.stop > opening.start
      && time >= opening.start && time < opening.stop && videoRef.current && !videoRef.current.seeking) {
      videoRef.current.currentTime = opening.stop; notify("Опенинг пропущен");
    }
  }, [time, autoSkip, opening, playing, notify]);

  useEffect(() => {
    setStats(null);
    if (enhance.mode === "off" || !loaded || playback.status === "download" || error || !canvasRef.current || !videoRef.current) return;
    let live = true;
    const fail = (message: string) => {
      if (!live) return;
      setStats(null); setGpuError(message);
      setEnhance((value) => { const off = { ...value, mode: "off" as const, compare: false }; savePreference("enhance", off); return off; });
      notify("Продолжаем просмотр в оригинальном качестве.");
    };
    try { enhancerRef.current = new VideoEnhancer(videoRef.current, canvasRef.current, enhanceRef.current, (value) => { if (live) setStats(value); }, fail); }
    catch (error) { fail(error instanceof Error ? error.message : "Обработка изображения недоступна."); }
    return () => { live = false; enhancerRef.current?.dispose(); enhancerRef.current = null; };
  }, [enhance.mode, videoSourceKey, loaded, error, playback.status === "download", notify]);
  useEffect(() => { enhancerRef.current?.update(enhance); }, [enhance]);

  useEffect(() => {
    if (countdown === null || !next) return;
    if (countdown <= 0) { setCountdown(null); onChange(next.ordinal); return; }
    const timer = window.setTimeout(() => setCountdown((value) => value === null ? null : value - 1), 1000);
    return () => clearTimeout(timer);
  }, [countdown, next, onChange]);
  useEffect(() => {
    if (!sleepAt) return;
    const timer = window.setTimeout(() => { sessionRef.current?.pause(); setSleepAt(0); savePreference("sleepAt", 0); setCountdown(null); notify("Таймер сна: приятных снов."); }, Math.max(0, sleepAt - Date.now()));
    return () => clearTimeout(timer);
  }, [sleepAt, notify]);
  useEffect(() => {
    if (!playing || !("wakeLock" in navigator)) return;
    let active = true;
    let lock: WakeLockSentinel | null = null;
    const acquire = async () => {
      if (!active || document.hidden || lock && !lock.released) return;
      try { const result = await navigator.wakeLock.request("screen"); if (!active) await result.release(); else lock = result; } catch { /* OS power-saving policy. */ }
    };
    void acquire(); document.addEventListener("visibilitychange", acquire);
    return () => { active = false; document.removeEventListener("visibilitychange", acquire); void lock?.release().catch(() => undefined); };
  }, [playing]);

  const reconnect = useCallback(() => {
    if (isDownloadActive() && !localSource) { notify("Сначала дождитесь скачивания или отмените его."); return; }
    resumeRef.current = { key, time: sessionRef.current?.snapshot().time || playback.time, wantsPlay: true };
    forcePlayNext.current = true;
    setRetry((value) => value + 1);
  }, [key, playback.time, localSource, notify]);
  const togglePlay = useCallback(() => {
    setCountdown(null);
    if (playback.status === "error" || playback.status === "download") { reconnect(); return; }
    const video = videoRef.current;
    if (!video) return;
    video.paused ? sessionRef.current?.play() : sessionRef.current?.pause();
    revealControls();
  }, [playback.status, reconnect, revealControls]);
  const seek = useCallback((target: number) => {
    const video = videoRef.current;
    if (video && Number.isFinite(video.duration)) { video.currentTime = Math.max(0, Math.min(video.duration, target)); setCountdown(null); }
  }, []);
  const seekBy = useCallback((amount: number) => { seek((videoRef.current?.currentTime || 0) + amount); notify(amount > 0 ? "+10 секунд" : "-10 секунд"); revealControls(); }, [seek, notify, revealControls]);
  const toggleFullscreen = useCallback(async () => {
    const root = wrapRef.current;
    if (!root) return;
    if (immersive) { setImmersive(false); return; }
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else if (root.requestFullscreen) {
        await root.requestFullscreen();
        const orientation = screen.orientation as ScreenOrientation & { lock?: (orientation: string) => Promise<void> };
        await orientation?.lock?.("landscape").catch(() => undefined);
      } else setImmersive(true);
    } catch { setImmersive((value) => !value); }
    revealControls();
  }, [immersive, revealControls]);
  useEffect(() => {
    const changed = () => { setFullscreen(Boolean(document.fullscreenElement)); if (!document.fullscreenElement) screen.orientation?.unlock?.(); };
    document.addEventListener("fullscreenchange", changed);
    return () => document.removeEventListener("fullscreenchange", changed);
  }, []);
  useEffect(() => {
    if (!immersive) return;
    const old = document.body.style.overflow; document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = old; };
  }, [immersive]);
  const pip = async () => {
    try {
      if (document.pictureInPictureElement) await document.exitPictureInPicture();
      else if (videoRef.current?.requestPictureInPicture) { await videoRef.current.requestPictureInPicture(); if (stats) notify("Mini-плеер показывает исходное изображение."); }
    } catch { notify("Сначала запустите видео, затем откройте mini-плеер."); }
  };
  useEffect(() => {
    if (!("mediaSession" in navigator) || typeof MediaMetadata === "undefined") return;
    const session = navigator.mediaSession;
    session.metadata = new MediaMetadata({ title: titleOf(release), artist: localSource ? "Kurenai" : `${episodeNumber(episode)} · ${voiceName}`, album: "Kurenai", artwork: img(release.poster) ? [{ src: img(release.poster) }] : [] });
    const handlers: [MediaSessionAction, () => void][] = [["play", () => sessionRef.current?.play()], ["pause", () => sessionRef.current?.pause()], ["seekbackward", () => seekBy(-10)], ["seekforward", () => seekBy(10)], ["nexttrack", () => { if (next) onChange(next.ordinal); }], ["previoustrack", () => { if (previous) onChange(previous.ordinal); }]];
    handlers.forEach(([action, callback]) => { try { session.setActionHandler(action, callback); } catch { /* Unsupported key. */ } });
    return () => { handlers.forEach(([action]) => { try { session.setActionHandler(action, null); } catch { /* Unsupported key. */ } }); session.metadata = null; };
  }, [release, episode.ordinal, voiceName, next, previous, localSource, onChange, seekBy]);
  useEffect(() => {
    const keydown = (event: KeyboardEvent) => {
      if (event.key === "Escape") { setPanel(null); setLocked(false); setImmersive(false); return; }
      if ((event.target as HTMLElement).closest("input,select,textarea,button,a,[contenteditable=true]") || event.ctrlKey || event.altKey || event.metaKey || locked) return;
      const video = videoRef.current; if (!video) return;
      switch (event.key.toLowerCase()) {
        case " ": case "k": event.preventDefault(); togglePlay(); break;
        case "arrowright": event.preventDefault(); seekBy(10); break;
        case "arrowleft": event.preventDefault(); seekBy(-10); break;
        case "arrowup": event.preventDefault(); video.volume = Math.min(1, video.volume + .05); break;
        case "arrowdown": event.preventDefault(); video.volume = Math.max(0, video.volume - .05); break;
        case "f": event.preventDefault(); void toggleFullscreen(); break;
        case "m": video.muted = !video.muted; break;
        case "n": if (next) onChange(next.ordinal); break;
        case "p": if (previous) onChange(previous.ordinal); break;
      }
    };
    window.addEventListener("keydown", keydown); return () => window.removeEventListener("keydown", keydown);
  }, [locked, togglePlay, seekBy, toggleFullscreen, next, previous, onChange]);
  useEffect(() => () => { clearTimeout(hideTimer.current); clearTimeout(noticeTimer.current); clearTimeout(tapTimer.current); }, []);

  const surfaceClick = (event: MouseEvent<HTMLButtonElement>) => {
    if (locked) { revealControls(); return; }
    clearTimeout(tapTimer.current);
    if (!window.matchMedia("(pointer: coarse)").matches) { if (event.detail < 2) tapTimer.current = window.setTimeout(togglePlay, 220); return; }
    const rect = event.currentTarget.getBoundingClientRect(); const x = (event.clientX - rect.left) / rect.width;
    const zone = x < .45 ? -1 : x > .55 ? 1 : 0;
    const now = performance.now();
    if (now - lastTap.current.time < 320 && lastTap.current.zone === zone && zone !== 0) { seekBy(zone * 10); lastTap.current.time = 0; }
    else { lastTap.current = { time: now, zone }; tapTimer.current = window.setTimeout(() => { if (controls && playing) setControls(false); else revealControls(); }, 250); }
  };
  const openPanel = (tab: PlayerTab) => { setPanel(tab); revealControls(); };
  const closePanel = () => { setPanel(null); wrapRef.current?.focus({ preventScroll: true }); revealControls(); };
  const changeEnhance = (options: EnhanceOptions) => { setGpuError(""); setEnhance(options); savePreference("enhance", { ...options, compare: false }); };
  const sleepMinutes = sleepAt > Date.now() ? Math.ceil((sleepAt - Date.now()) / 60_000) : 0;
  const downloadable = playback.media?.variants.filter((variant) => variant.kind === "hls").map((variant) => variant.quality) || [];
  const startSaving = () => {
    const variant = playback.media?.variants.find((item) => item.quality === downloadQuality && item.kind === "hls");
    if (!variant) return;
    startDownload({ url: variant.url, quality: downloadQuality, name: titleOf(release), episode: episode.ordinal, poster: img(release.poster, "thumbnail"), voiceName });
    closePanel();
  };
  const visible = (controls || !playing || panel !== null) && !locked;
  const skip = opening?.start != null && opening.stop != null && time >= opening.start && time < opening.stop ? { label: "Пропустить опенинг", end: opening.stop }
    : ending?.start != null && ending.stop != null && time >= ending.start && time < ending.stop ? { label: "Пропустить эндинг", end: ending.stop } : null;

  return <div>
    <div ref={wrapRef} tabIndex={-1} aria-label="Видеоплеер Kurenai" className={`player ${visible ? "controls-visible" : "is-idle"} ${immersive ? "immersive" : ""} ${panel ? "has-panel" : ""}`} onPointerMove={(event) => { if (event.pointerType === "mouse") revealControls(); }}>
      <video ref={videoRef} playsInline preload="none" crossOrigin="anonymous" poster={img(episode.preview) || img(release.poster)} style={{ objectFit: cover ? "cover" : "contain" }} />
      <canvas ref={canvasRef} aria-hidden="true" style={{ visibility: stats && enhance.mode !== "off" ? "visible" : "hidden", objectFit: cover ? "cover" : "contain" }} />
      <button className="player-hit" aria-label="Показать управление" onClick={surfaceClick} onDoubleClick={() => { if (!locked && !window.matchMedia("(pointer: coarse)").matches) { clearTimeout(tapTimer.current); void toggleFullscreen(); } }} tabIndex={-1} />
      <div className="player-scrim" />
      {stats && enhance.compare && <div className="compare-divider" style={{ left: `${enhance.split * 100}%` }}><span><ArrowLeftRight size={14} /></span></div>}
      <div className={`player-top ${visible ? "player-shown" : "player-hidden"}`}><div className="min-w-0 truncate text-[12px] font-medium text-white/85">{localSource ? "" : episodeNumber(episode)}</div><div className="flex"><button className="player-button" aria-label="Блокировка касаний" onClick={() => { setLocked(true); setPanel(null); notify("Касания заблокированы."); }}><UnlockKeyhole size={17} /></button>{(fullscreen || immersive) && <button className="player-button" aria-label="Свернуть" onClick={toggleFullscreen}><X size={19} /></button>}</div></div>
      {locked && controls && <button className="player-button absolute right-3 top-3 z-[8] !bg-black/60" onClick={() => { setLocked(false); revealControls(); }} aria-label="Разблокировать"><LockKeyhole size={19} /></button>}
      {notice && <div className="player-notice" role="status">{notice}</div>}
      {!error && playback.status !== "download" && countdown === null && !locked && !panel && (visible || buffering) && <div className="player-center"><button className="player-button !h-12 !w-12 md:hidden" disabled={!loaded} aria-label="Назад 10 секунд" onClick={() => seekBy(-10)}><RotateCcw size={25} /></button>{buffering ? <LoaderCircle size={35} className="animate-spin text-white/75" aria-label="Загрузка видео" /> : <button className="play-orb" onClick={togglePlay} aria-label={playing ? "Пауза" : "Смотреть"}>{playing ? <Pause size={25} fill="currentColor" /> : <Play size={27} fill="currentColor" />}</button>}<button className="player-button !h-12 !w-12 md:hidden" disabled={!loaded} aria-label="Вперёд 10 секунд" onClick={() => seekBy(10)}><RotateCw size={25} /></button></div>}
      {error && <div className="player-error" role="alert"><Play size={29} className="text-shu" /><p>{error}</p><div className="flex flex-wrap justify-center gap-2"><button className="btn btn-secondary btn-small" onClick={reconnect}><RotateCcw size={14} />Продолжить</button>{onAlternative && <button className="btn btn-primary btn-small" onClick={onAlternative}>Выбрать озвучку</button>}</div></div>}
      {playback.status === "download" && <div className="player-error"><ArrowDownToLine size={28} className="text-shu" /><p>{downloading ? "Скачиваем серию. Просмотр приостановлен, чтобы не загружать два потока одновременно." : "Можно продолжить просмотр с сохранённого момента."}</p><button className="btn btn-secondary btn-small" disabled={downloading} onClick={reconnect}><Play size={14} />Продолжить просмотр</button></div>}
      {playback.status === "offline" && <div className="player-notice" role="status"><WifiOff size={13} className="mr-2 inline" />Ожидаем подключение к интернету</div>}
      {countdown !== null && next && <div className="player-error"><p className="!text-white/90">Продолжаем в той же озвучке</p><button className="btn btn-primary" onClick={() => onChange(next.ordinal)}><Play size={16} fill="currentColor" />{episodeNumber(next)} через {countdown} сек.</button><button className="text-xs text-mist" onClick={() => setCountdown(null)}>Остаться здесь</button></div>}
      <div className={`player-bottom ${visible ? "player-shown" : "player-hidden"}`}>{skip && !panel && <button className="btn btn-secondary btn-small mb-3 !bg-black/60" onClick={() => seek(skip.end)}>{skip.label}<ChevronRight size={14} /></button>}
        <div className="seek-track"><div className="seek-line"><div className="seek-buffer" style={{ width: `${duration ? Math.min(100, playback.buffered / duration * 100) : 0}%` }} /><div className="seek-fill" style={{ width: `${duration ? Math.min(100, time / duration * 100) : 0}%` }} /></div><input className="seek-input" type="range" aria-label="Позиция просмотра" aria-valuetext={`${fmtTime(time)} из ${fmtTime(duration)}`} min="0" max={duration || 1} step=".1" value={Math.min(time, duration || 1)} disabled={!loaded} onChange={(event) => seek(+event.target.value)} /></div>
        <div className="flex items-center gap-0.5 sm:gap-1"><button className="player-button" onClick={togglePlay} aria-label={playing ? "Пауза" : "Смотреть"}>{playing ? <Pause size={19} fill="currentColor" /> : <Play size={19} fill="currentColor" />}</button><button className="player-button max-md:hidden" disabled={!previous} onClick={() => previous && onChange(previous.ordinal)} aria-label="Предыдущая серия"><SkipBack size={18} /></button><button className="player-button max-sm:hidden" disabled={!next} onClick={() => next && onChange(next.ordinal)} aria-label="Следующая серия"><SkipForward size={18} /></button>
          <div className="mr-2 hidden items-center md:flex"><button className="player-button" aria-label={muted ? "Включить звук" : "Выключить звук"} onClick={() => { if (videoRef.current) videoRef.current.muted = !videoRef.current.muted; }}>{muted || volume === 0 ? <VolumeX size={18} /> : <Volume2 size={18} />}</button><input className="range w-16" type="range" aria-label="Громкость" min="0" max="1" step=".05" value={muted ? 0 : volume} onChange={(event) => { if (videoRef.current) { videoRef.current.volume = +event.target.value; videoRef.current.muted = false; } }} /></div>
          <span className="num whitespace-nowrap text-[10px] text-white/70 sm:text-[11px]">{fmtTime(time)}<span className="mx-1.5 text-white/35">/</span>{fmtTime(duration)}</span><div className="ml-auto flex items-center gap-0.5 sm:gap-1"><button className="player-button !px-2 max-sm:hidden" onClick={() => openPanel("playback")} aria-label="Качество видео">{localSource ? "Файл" : `${quality}p`}</button><button className="player-button" onClick={() => openPanel("enhance")} aria-label="Улучшить изображение"><Cpu size={18} className={stats ? "text-[#b7dbbd]" : ""} /></button><button className="player-button" onClick={() => panel ? closePanel() : openPanel("playback")} aria-label="Настройки"><Settings2 size={18} /></button><button className="player-button max-md:hidden" onClick={() => { setCover(!cover); notify(cover ? "Вписать в экран" : "Заполнить экран: края могут быть обрезаны"); }} aria-label="Масштаб изображения"><Expand size={18} /></button>{document.pictureInPictureEnabled && <button className="player-button max-sm:hidden" aria-label="Mini-плеер" onClick={pip}><PictureInPicture2 size={18} /></button>}<button className="player-button" aria-label={fullscreen || immersive ? "Свернуть" : "На весь экран"} onClick={toggleFullscreen}>{fullscreen || immersive ? <Minimize size={19} /> : <Maximize size={19} />}</button></div>
        </div>
      </div>
      <AnimatePresence>{panel && <><div className="settings-scrim" onClick={closePanel} /><PlayerSettings tab={panel} onTab={setPanel} onClose={closePanel} quality={quality} qualities={available} onQuality={(value) => { setPreference(value); setQuality(value); }} speed={speed} onSpeed={setSpeed} autoNext={autoNext} onAutoNext={setAutoNext} autoSkip={autoSkip} onAutoSkip={setAutoSkip} enhance={enhance} onEnhance={changeEnhance} stats={stats} gpuError={gpuError} downloadQuality={downloadQuality} downloadQualities={downloadable} onDownloadQuality={setDownloadQuality} onDownload={startSaving} canDownload={downloadable.includes(downloadQuality) && !downloading && !localSource} sleepMinutes={sleepMinutes} onSleep={(minutes) => { const deadline = minutes ? Date.now() + minutes * 60_000 : 0; setSleepAt(deadline); savePreference("sleepAt", deadline); }} bufferedSeconds={Math.max(0, playback.buffered - time)} /></>}</AnimatePresence>
    </div>
    <div className="player-after">
      <button onClick={() => openPanel("enhance")} aria-label="Улучшить изображение"><Cpu size={15} /><span>Изображение</span></button>
      {!localSource && <button onClick={() => { setDownloadQuality(downloadable.includes(quality) ? quality : downloadable[0] || quality); openPanel("download"); }} aria-label="Скачать серию"><ArrowDownToLine size={15} /><span>Скачать</span></button>}
    </div>
  </div>;
}