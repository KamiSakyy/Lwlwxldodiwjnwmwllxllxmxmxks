import { useEffect, useRef, useState } from "react";
import { ArrowDownToLine, Smartphone, X } from "lucide-react";

type InstallEvent = Event & { prompt(): Promise<void>; userChoice: Promise<{ outcome: string }> };

export default function InstallButton({ className = "btn btn-secondary" }: { className?: string }) {
  const prompt = useRef<InstallEvent | null>(null);
  const [help, setHelp] = useState(false);
  const [installed, setInstalled] = useState(() => window.matchMedia("(display-mode: standalone)").matches);
  useEffect(() => {
    const before = (event: Event) => { event.preventDefault(); prompt.current = event as InstallEvent; };
    const after = () => setInstalled(true);
    const key = (event: KeyboardEvent) => { if (event.key === "Escape") setHelp(false); };
    window.addEventListener("beforeinstallprompt", before);
    window.addEventListener("appinstalled", after);
    window.addEventListener("keydown", key);
    return () => { window.removeEventListener("beforeinstallprompt", before); window.removeEventListener("appinstalled", after); window.removeEventListener("keydown", key); };
  }, []);
  const install = async () => {
    if (prompt.current) {
      try {
        await prompt.current.prompt();
        if ((await prompt.current.userChoice).outcome === "accepted") setInstalled(true);
        prompt.current = null;
      } catch { setHelp(true); }
    } else setHelp(true);
  };
  if (installed) return null;
  return <>
    <button className={className} onClick={install}><Smartphone size={16} /><span>Установить</span></button>
    {help && <div className="modal-backdrop" onClick={() => setHelp(false)}>
      <section className="modal-body" role="dialog" aria-modal="true" aria-label="Установка Kurenai" onClick={(event) => event.stopPropagation()} onKeyDown={(event) => {
        if (event.key !== "Tab") return;
        const buttons = event.currentTarget.querySelectorAll<HTMLButtonElement>("button");
        if (event.shiftKey && document.activeElement === buttons[0]) { event.preventDefault(); buttons[buttons.length - 1]?.focus(); }
        else if (!event.shiftKey && document.activeElement === buttons[buttons.length - 1]) { event.preventDefault(); buttons[0]?.focus(); }
      }}>
        <div className="flex items-center justify-between"><Smartphone size={26} className="text-shu" /><button className="icon-button" aria-label="Закрыть" onClick={() => setHelp(false)} autoFocus><X size={20} /></button></div>
        <h2 className="mt-5 text-2xl font-medium">Kurenai, всегда рядом</h2>
        <p className="mt-3 text-sm leading-7 text-mist">На Android откройте меню браузера и выберите «Установить приложение» или «Добавить на главный экран».</p>
        <p className="mt-3 text-sm leading-7 text-mist">На iPhone: «Поделиться», затем «На экран Домой». Приложение откроется в отдельном окне.</p>
        <p className="mt-4 text-xs text-mist">Установка доступна на HTTPS. Для онлайн-просмотра нужен интернет.</p>
        <button className="btn btn-primary mt-6 w-full" onClick={() => setHelp(false)}><ArrowDownToLine size={16} />Понятно</button>
      </section>
    </div>}
  </>;
}