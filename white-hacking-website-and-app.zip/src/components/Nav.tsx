import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Search, Bookmark, Download, Home, Compass, CalendarDays, Shuffle, X, LoaderCircle, ArrowUpRight } from "lucide-react";
import { getRandom, searchReleases, titleOf, img, type Release } from "../api";
import { catalogHref, type Route } from "../router";
import { useDownloads } from "../lib/downloads";

export function Brand() {
  return <a href="#/" className="brand" aria-label="Kurenai, главная"><span className="brand-symbol" aria-hidden="true">紅</span><span className="brand-word">Kurenai</span></a>;
}

export default function Nav({ route }: { route: Route }) {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [mobileSearch, setMobileSearch] = useState(false);
  const [hits, setHits] = useState<Release[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [randomBusy, setRandomBusy] = useState(false);
  const box = useRef<HTMLDivElement>(null);
  const input = useRef<HTMLInputElement>(null);
  const { jobs } = useDownloads();
  const activeJobs = jobs.filter((job) => job.status === "loading" || job.status === "ready").length;

  useEffect(() => {
    let live = true;
    setError(""); setHits([]);
    if (!query.trim()) { setLoading(false); return; }
    setLoading(true);
    const timer = window.setTimeout(() => {
      searchReleases(query.trim(), (items) => { if (live) { setHits(items); setLoading(false); } }).then((data) => { if (live) setHits(data); })
        .catch(() => { if (live) setError("Не удалось найти тайтлы. Попробуйте ещё раз."); })
        .finally(() => { if (live) setLoading(false); });
    }, 320);
    return () => { live = false; clearTimeout(timer); };
  }, [query]);
  useEffect(() => { setOpen(false); setMobileSearch(false); setQuery(""); }, [route]);
  useEffect(() => {
    const outside = (event: PointerEvent) => { if (box.current && !box.current.contains(event.target as Node)) setOpen(false); };
    const key = (event: KeyboardEvent) => {
      if (event.key === "Escape") { setOpen(false); setMobileSearch(false); }
      if (event.key === "/" && !["INPUT", "TEXTAREA"].includes((event.target as HTMLElement).tagName)) {
        event.preventDefault(); setMobileSearch(true); setTimeout(() => input.current?.focus(), 0);
      }
    };
    window.addEventListener("pointerdown", outside); window.addEventListener("keydown", key);
    return () => { window.removeEventListener("pointerdown", outside); window.removeEventListener("keydown", key); };
  }, []);
  const random = async () => {
    setRandomBusy(true);
    try { const release = await getRandom(); if (release) location.hash = `/title/${release.id}`; }
    catch { setOpen(true); setError("Пока не удалось выбрать историю. Попробуйте поиск."); setMobileSearch(true); }
    finally { setRandomBusy(false); }
  };
  const links = [
    { text: "Главная", href: "#/", name: "home", icon: Home },
    { text: "Каталог", href: "#/catalog", name: "catalog", icon: Compass },
    { text: "Расписание", href: "#/schedule", name: "schedule", icon: CalendarDays },
  ];

  return <>
    <header className="sticky top-0 z-50 border-b border-white/5 bg-void/95 backdrop-blur-xl">
      <div className="page-shell flex h-[76px] items-center gap-5 max-md:h-[66px] max-md:gap-3 xl:gap-8">
        <Brand />
        <nav className="hidden shrink-0 items-center gap-5 md:flex xl:ml-5 xl:gap-7" aria-label="Основная навигация">
          {links.map((link) => <a key={link.name} href={link.href} className={`nav-link ${route.name === link.name ? "active" : ""}`} aria-current={route.name === link.name ? "page" : undefined}>{link.text}</a>)}
        </nav>
        <div ref={box} className={`${mobileSearch ? "max-md:absolute max-md:inset-x-4 max-md:top-3 max-md:z-30 md:relative" : "relative ml-auto hidden md:block"} min-w-0 md:ml-auto md:w-[190px] md:shrink lg:w-[240px] xl:w-[270px]`}>
          <form className="flex h-10 items-center gap-2.5 rounded-full border border-white/9 bg-[#19191d] px-3.5" onSubmit={(event) => { event.preventDefault(); if (query.trim()) location.hash = catalogHref({ q: query.trim() }).slice(1); setOpen(false); }}>
            <Search size={16} className="shrink-0 text-mist" />
            <input ref={input} type="search" aria-label="Поиск аниме" placeholder="Найти свою историю" value={query} onChange={(event) => { setQuery(event.target.value); setOpen(true); }} onFocus={() => setOpen(true)} className="w-full min-w-0 bg-transparent text-[12px] text-ink outline-none placeholder:text-[#78767f]" />
            {mobileSearch ? <button type="button" onClick={() => { setMobileSearch(false); setOpen(false); }} aria-label="Закрыть поиск"><X size={17} /></button> : <kbd className="hidden text-xs text-mist md:block">/</kbd>}
          </form>
          <AnimatePresence>
            {open && (query.trim() || error) && <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} className="absolute right-0 top-full mt-3 max-h-[65svh] w-[360px] max-w-[calc(100vw-32px)] overflow-auto rounded-xl border border-white/10 bg-[#19191d] p-2 shadow-2xl max-md:w-full">
              {loading ? <div className="flex items-center gap-3 p-5 text-sm text-mist"><LoaderCircle className="animate-spin" size={16} />Ищем вашу историю...</div> : error ? <p role="alert" className="p-4 text-sm text-mist">{error}</p> : hits.length ? <>
                {hits.slice(0, 7).map((release) => <a key={release.id} href={`#/title/${release.id}`} className="flex items-center gap-3 rounded-lg p-2 hover:bg-white/5">
                  <img src={img(release.poster, "thumbnail")} alt="" className="h-14 w-10 shrink-0 rounded object-cover" />
                  <div className="min-w-0"><div className="line-clamp-2 text-xs leading-5">{titleOf(release)}</div><div className="mt-1 text-[10px] text-mist">{release.year} · {release.type?.description}{release.provider === "yummy" ? " · Мультиозвучка" : ""}</div></div>
                </a>)}
                <a className="flex items-center justify-between p-3 text-xs text-shu" href={catalogHref({ q: query.trim() })}>Все результаты<ArrowUpRight size={16} /></a>
              </> : <p className="p-4 text-sm text-mist">Ничего не найдено. Попробуйте другое название.</p>}
            </motion.div>}
          </AnimatePresence>
        </div>
        <div className="ml-auto flex items-center gap-1 md:ml-0">
          <button className="icon-button md:hidden" aria-label="Поиск" onClick={() => { setMobileSearch(true); setTimeout(() => input.current?.focus(), 0); }}><Search size={20} /></button>
          <button className="icon-button max-lg:hidden" aria-label="Случайное аниме" title="Случайная история" disabled={randomBusy} onClick={random}>{randomBusy ? <LoaderCircle size={18} className="animate-spin" /> : <Shuffle size={18} />}</button>
          <a href="#/favorites" className="icon-button max-md:hidden" aria-label="Моя коллекция"><Bookmark size={19} /></a>
          <a href="#/downloads" className="icon-button relative" aria-label="Загрузки"><Download size={19} />{activeJobs > 0 && <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-shu" />}</a>
        </div>
      </div>
    </header>
    <nav className="mobile-nav" aria-label="Мобильная навигация">
      {[...links, { text: "Коллекция", href: "#/favorites", name: "favorites", icon: Bookmark }, { text: "Загрузки", href: "#/downloads", name: "downloads", icon: Download }].map((link) => <a key={link.name} href={link.href} className={route.name === link.name ? "active" : ""} aria-current={route.name === link.name ? "page" : undefined}><link.icon size={20} strokeWidth={1.7} /><span>{link.text}</span></a>)}
    </nav>
  </>;
}