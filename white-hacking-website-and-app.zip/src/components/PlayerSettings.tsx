import { ArrowDownToLine, Check, Cpu, Info, X } from "lucide-react";
import { motion } from "framer-motion";
import type { EnhanceOptions, EnhanceStats } from "../lib/enhancer";
import type { VideoQuality } from "../api";

export type PlayerTab = "playback" | "enhance" | "download";

export function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (value: boolean) => void }) {
  return <button type="button" role="switch" aria-checked={checked} aria-label={label} className={`toggle ${checked ? "on" : ""}`} onClick={() => onChange(!checked)} />;
}

type Props = {
  tab: PlayerTab; onTab: (tab: PlayerTab) => void; onClose: () => void;
  quality: VideoQuality; qualities: VideoQuality[]; onQuality: (q: VideoQuality) => void;
  speed: number; onSpeed: (speed: number) => void;
  autoNext: boolean; onAutoNext: (value: boolean) => void;
  autoSkip: boolean; onAutoSkip: (value: boolean) => void;
  enhance: EnhanceOptions; onEnhance: (options: EnhanceOptions) => void;
  stats: EnhanceStats | null; gpuError: string;
  downloadQuality: VideoQuality; onDownloadQuality: (q: VideoQuality) => void;
  downloadQualities: VideoQuality[];
  onDownload: () => void; canDownload: boolean;
  sleepMinutes: number; onSleep: (minutes: number) => void;
  bufferedSeconds: number;
};

export default function PlayerSettings(props: Props) {
  const { tab, onTab, onClose, enhance, onEnhance, stats } = props;
  const updateEnhance = (change: Partial<EnhanceOptions>) => onEnhance({ ...enhance, ...change });
  const qualityLabel = (quality: VideoQuality) => quality === "auto" ? "Авто" : `${quality}p`;
  return <motion.aside className="settings-panel hide-scroll" role="dialog" aria-modal="true" aria-label="Настройки плеера" initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 12 }} transition={{ duration: .2 }} onKeyDown={(event) => {
    if (event.key === "Escape") { event.stopPropagation(); onClose(); }
    if (event.key === "Tab") {
      const items = event.currentTarget.querySelectorAll<HTMLElement>("button:not([disabled]), input:not([disabled]), select:not([disabled]), a[href]");
      if (event.shiftKey && document.activeElement === items[0]) { event.preventDefault(); items[items.length - 1]?.focus(); }
      else if (!event.shiftKey && document.activeElement === items[items.length - 1]) { event.preventDefault(); items[0]?.focus(); }
    }
  }}>
    <div className="flex items-center justify-between"><span className="text-[14px] font-medium">Твой идеальный просмотр</span><button autoFocus className="player-button !h-7 !min-w-7 !p-1" aria-label="Закрыть настройки" onClick={onClose}><X size={18} /></button></div>
    <div className="settings-tabs" role="tablist">{([['playback', 'Плеер'], ['enhance', 'Изображение'], ['download', 'Скачать']] as [PlayerTab, string][]).map(([id, name]) => <button key={id} role="tab" aria-selected={tab === id} className={tab === id ? "active" : ""} onClick={() => onTab(id)}>{name}</button>)}</div>
    {tab === "playback" && <div role="tabpanel">
      {props.qualities.length > 0 && <div className="setting-row"><span className="setting-label">Качество видео</span><div className="segmented">{props.qualities.map((q) => <button key={q} className={props.quality === q ? "active" : ""} onClick={() => props.onQuality(q)}>{q}p{props.quality === q && <Check size={11} className="ml-1 inline" />}</button>)}</div></div>}
      <div className="setting-row"><span className="setting-label">Скорость<span className="text-mist">{props.speed}×</span></span><div className="segmented">{[.75, 1, 1.25, 1.5, 2].map((speed) => <button key={speed} className={props.speed === speed ? "active" : ""} onClick={() => props.onSpeed(speed)}>{speed}×</button>)}</div></div>
      <div className="setting-row setting-label">Следующая серия автоматически<Toggle label="Автопереход" checked={props.autoNext} onChange={props.onAutoNext} /></div>
      <div className="setting-row setting-label">Пропускать опенинг<Toggle label="Автопропуск опенинга" checked={props.autoSkip} onChange={props.onAutoSkip} /></div>
      <div className="setting-row"><span className="setting-label">Таймер сна<span className="text-mist">{props.sleepMinutes ? `${props.sleepMinutes} мин` : "Выкл."}</span></span><div className="segmented">{[0, 15, 30, 60].map((minutes) => <button key={minutes} className={props.sleepMinutes === minutes ? "active" : ""} onClick={() => props.onSleep(minutes)}>{minutes ? `${minutes} мин` : "Выкл."}</button>)}</div></div>
      <div className="setting-row"><span className="setting-label">Загружено вперёд<span className="text-gold">{Math.round(props.bufferedSeconds)} сек.</span></span><p className="mt-2 text-[10px] leading-5 text-mist">Другие озвучки и следующие серии не загружаются в фоне. Уже начатый сегмент может догрузиться после паузы.</p></div>
      <p className="mt-4 text-[10px] leading-5 text-mist">Двойное касание слева или справа: 10 секунд назад или вперёд. Пробел: пауза. F: весь экран.</p>
    </div>}
    {tab === "enhance" && <div role="tabpanel">
      <div className="mb-4 mt-5 flex items-center gap-3"><span className="grid h-9 w-9 place-items-center rounded-lg bg-shu/10 text-shu"><Cpu size={19} /></span><div><p className="text-[13px] font-medium">Kurenai Enhance</p><p className="mt-0.5 text-[10px] text-mist">Чище линии. Больше деталей.</p></div></div>
      <div className="segmented">{([['off', 'Оригинал'], ['balanced', 'Баланс 1.5×'], ['quality', 'Детали 2×']] as const).map(([mode, label]) => <button key={mode} className={enhance.mode === mode ? "active" : ""} onClick={() => updateEnhance({ mode })}>{label}</button>)}</div>
      <p className="mt-3 text-[10px] leading-5 text-mist">Реальный апскейл кадров на GPU. До 2× по каждой стороне, в пределах возможностей устройства. Не нейросеть.</p>
      {props.gpuError && <p role="status" className="mt-3 rounded-md bg-shu/10 p-3 text-[11px] leading-5 text-[#ffad9f]">{props.gpuError}</p>}
      {enhance.mode !== "off" && <>
        <div className="setting-row"><label className="setting-label" htmlFor="enhance-sharpness">Восстановление контуров<span className="text-mist">{Math.round(enhance.sharpness * 100)}%</span></label><input id="enhance-sharpness" type="range" min="0" max="1" step="0.05" value={enhance.sharpness} onChange={(event) => updateEnhance({ sharpness: +event.target.value })} className="range mt-4 w-full" /></div>
        <div className="setting-row"><label className="setting-label" htmlFor="enhance-denoise">Шумоподавление<span className="text-mist">{Math.round(enhance.denoise * 100)}%</span></label><input id="enhance-denoise" type="range" min="0" max="1" step="0.05" value={enhance.denoise} onChange={(event) => updateEnhance({ denoise: +event.target.value })} className="range mt-4 w-full" /></div>
        <div className="setting-row setting-label">Сравнить до / после<Toggle label="Сравнить оригинал и обработку" checked={enhance.compare} onChange={(compare) => updateEnhance({ compare })} /></div>
        {enhance.compare && <div className="setting-row"><input aria-label="Граница сравнения" type="range" min="0.05" max="0.95" step="0.01" value={enhance.split} onChange={(event) => updateEnhance({ split: +event.target.value })} className="range w-full" /><div className="mt-2 flex justify-between text-[10px] text-mist"><span>Оригинал</span><span>Enhance</span></div></div>}
        <div className="mt-4 rounded-lg bg-black/20 p-3 text-[10px] leading-6 text-mist">{stats ? <><div className="flex justify-between"><span>Исходный кадр</span><span className="text-white/80">{stats.sourceWidth} × {stats.sourceHeight}</span></div><div className="flex justify-between"><span>После обработки</span><span className="text-[#b7dbbd]">{stats.width} × {stats.height}</span></div><div className="flex justify-between"><span>Обработано кадров</span><span className="text-white/80">{stats.frames.toLocaleString("ru")} · {stats.fps} fps</span></div></> : "Ожидаем декодированный кадр для запуска GPU..."}</div>
      </>}
      <p className="mt-4 flex items-start gap-2 text-[10px] leading-5 text-mist"><Info size={13} className="mt-1 shrink-0" />Обработка доступна при поддержке WebGL и разрешении браузера. При ошибке останется оригинал. В системном mini-плеере показывается исходное видео.</p>
    </div>}
    {tab === "download" && <div role="tabpanel" className="pt-4">
      <span className="setting-label">Качество скачивания</span>
      <div className="segmented">{props.downloadQualities.map((q) => <button key={q} className={props.downloadQuality === q ? "active" : ""} onClick={() => props.onDownloadQuality(q)}>{qualityLabel(q)}</button>)}</div>
      {props.downloadQualities.length ? <button className="btn btn-primary mt-5 w-full" onClick={props.onDownload} disabled={!props.canDownload}><ArrowDownToLine size={16} />Скачать серию · {qualityLabel(props.downloadQuality)}</button> : <p className="mt-4 rounded-lg bg-white/5 p-3 text-xs leading-6 text-mist">Сохранение файла этой озвучки пока не поддерживается. Онлайн-просмотр доступен в нашем плеере.</p>}
      {props.downloadQualities.length > 0 && <p className="mt-4 text-[11px] leading-6 text-mist">Это отдельная загрузка полного MP4. Онлайн-просмотр остановится перед скачиванием, чтобы не загружать видео дважды одновременно.</p>}
      <p className="mt-3 text-[10px] leading-5 text-mist">Апскейл работает при просмотре и не встраивается в скачанный файл. Не закрывайте приложение до завершения загрузки.</p>
      <p className="mt-3 text-[10px] leading-5 text-mist">Доступность зависит от видеоформата и разрешений сервера. Сохраняйте только контент, который вы вправе скачивать.</p>
    </div>}
  </motion.aside>;
}