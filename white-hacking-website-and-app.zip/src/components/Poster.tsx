import { useEffect, useRef, useState, type ReactNode } from "react";
import { motion } from "framer-motion";
import { ArrowRight, Bookmark, Check, ChevronLeft, ChevronRight, Play, Star } from "lucide-react";
import { img, ratingOf, titleOf, type Release } from "../api";
import { isFav, toggleFav } from "../store";

export function PosterCard({ r, href, progress, wide = false }: { r: Release; href: string; progress?: number; wide?: boolean }) {
  const [favorite, setFavorite] = useState(() => isFav(r.id));
  const [failed, setFailed] = useState(false);
  const source = img(r.poster, wide ? "src" : "preview");
  const rating = ratingOf(r);
  useEffect(() => {
    const sync = () => setFavorite(isFav(r.id));
    window.addEventListener("kurenai:library", sync);
    return () => window.removeEventListener("kurenai:library", sync);
  }, [r.id]);
  return <article className="group relative min-w-0">
    <div className={`poster-image ${wide ? "!aspect-video" : ""}`}>
      <a href={href} className="absolute inset-0 block" aria-label={`Открыть ${titleOf(r)}`}>
        {source && !failed ? <img src={source} alt={titleOf(r)} onError={() => setFailed(true)} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.035]" loading="lazy" /> : <div className="flex h-full flex-col items-center justify-center gap-3 p-5 text-center"><span className="brand-symbol">紅</span><span className="text-xs text-mist">{titleOf(r)}</span></div>}
        <div className="poster-play"><span className="grid h-12 w-12 place-items-center rounded-full border border-white/50 bg-black/20 backdrop-blur-sm"><Play size={20} fill="currentColor" className="ml-0.5" /></span></div>
      </a>
      {rating && <span className="absolute left-2.5 top-2.5 flex items-center gap-1 rounded bg-[#151416df] px-1.5 py-1 text-[10px] text-white"><Star size={10} fill="#c5ae88" stroke="#c5ae88" />{rating.toFixed(1)}</span>}
      <button className={`absolute right-2 top-2 grid h-8 w-8 place-items-center rounded-full bg-black/60 text-white transition-opacity ${favorite ? "opacity-100" : "opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 max-md:opacity-100"}`} onClick={() => setFavorite(toggleFav(r))} aria-label={favorite ? "Убрать из коллекции" : "Добавить в коллекцию"} aria-pressed={favorite}>{favorite ? <Check size={15} /> : <Bookmark size={15} />}</button>
      {r.is_ongoing && <span className="absolute bottom-2.5 left-2.5 rounded bg-[#141416df] px-2 py-1 text-[9px] text-ink"><span className="mr-1.5 inline-block h-1.5 w-1.5 rounded-full bg-shu" />Выходит</span>}
      {typeof progress === "number" && progress > 0 && <span className="absolute inset-x-0 bottom-0 h-[3px] bg-white/20"><span className="block h-full bg-shu" style={{ width: `${Math.min(100, progress * 100)}%` }} /></span>}
    </div>
    <a href={href} className="poster-title line-clamp-2 transition-colors hover:text-shu">{titleOf(r)}</a>
    <div className="poster-meta">{r.year || "Аниме"} <span className="mx-1 text-white/25">·</span> {r.type?.description || "Сериал"}{r.provider === "yummy" ? " · Расширенная коллекция" : r.episodes_total ? ` · ${r.episodes_total} эп.` : ""}</div>
  </article>;
}

export function Rail({ label, kicker, children, more }: { label: string; kicker?: string; children: ReactNode; more?: string }) {
  const rail = useRef<HTMLDivElement>(null);
  const scroll = (direction: number) => rail.current?.scrollBy({ left: direction * rail.current.clientWidth * .8, behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" });
  return <motion.section initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "60px" }} transition={{ duration: .45 }} className="page-shell mt-12 sm:mt-16">
    <div className="mb-6 flex items-center justify-between gap-3">
      <div>{kicker && <p className="tag mb-2 text-gold">{kicker}</p>}<h2 className="section-heading">{label}</h2></div>
      <div className="flex items-center gap-2 sm:gap-4">{more && <a href={more} className="mr-2 flex items-center gap-2 text-[11px] text-mist hover:text-ink"><span className="max-sm:hidden">Смотреть всё</span><ArrowRight size={15} /></a>}<button className="icon-button !h-8 !w-8 border border-white/10" aria-label="Прокрутить влево" onClick={() => scroll(-1)}><ChevronLeft size={16} /></button><button className="icon-button !h-8 !w-8 border border-white/10" aria-label="Прокрутить вправо" onClick={() => scroll(1)}><ChevronRight size={16} /></button></div>
    </div>
    <div ref={rail} className="hide-scroll rail flex gap-5 overflow-x-auto pb-2">{children}</div>
  </motion.section>;
}

export function SkeletonPoster({ n = 6 }: { n?: number; wide?: boolean }) {
  return <>{Array.from({ length: n }).map((_, index) => <div className="poster-slot" key={index}><div className="poster-image skeleton" /><div className="skeleton mt-3 h-3 w-4/5 rounded" /><div className="skeleton mt-2 h-2 w-1/2 rounded" /></div>)}</>;
}

export function Empty({ title, text }: { title: string; text: string }) {
  return <div className="flex min-h-[45vh] flex-col items-center justify-center px-6 py-20 text-center"><span className="brand-symbol !text-5xl">紅</span><h2 className="disp mt-6 text-4xl italic">{title}</h2><p className="mt-4 max-w-[44ch] text-sm leading-7 text-mist">{text}</p><a href="#/catalog" className="btn btn-secondary mt-6">Открыть каталог<ArrowRight size={15} /></a></div>;
}