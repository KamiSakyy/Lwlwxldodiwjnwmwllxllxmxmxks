import { useEffect, useMemo, useState } from "react";
import { ArrowDownWideNarrow, Check, ChevronLeft, ChevronRight, Clock3, Eye, EyeOff, LayoutGrid, List, Play, Search } from "lucide-react";
import { motion } from "framer-motion";
import { img, type Episode, type Release } from "../api";
import { getWatched, progressOf, setEpisodeWatched } from "../store";
import { episodeCountText, episodeNumber, episodeTitle, episodesForVoice, watchHref } from "../lib/playback";

export function EpisodeImage({ episode, release, className = "", hideSpoilers = false }: { episode: Episode; release: Release; className?: string; hideSpoilers?: boolean }) {
  const [attempt, setAttempt] = useState(0);
  const candidates = useMemo(() => [...new Set([
    img(episode.preview, "preview"),
    img(episode.preview ? { src: episode.preview.src, preview: episode.preview.preview } : null),
    img(release.poster, "preview"),
  ].filter(Boolean))], [episode.preview, release.poster]);
  useEffect(() => { setAttempt(0); }, [episode.id]);
  const source = candidates[attempt];
  const isPoster = episode.preview_is_poster || source === img(release.poster, "preview");
  return <div className={`episode-image ${className}`}>
    {source ? <img src={source} alt={`${episodeNumber(episode)}: ${episodeTitle(episode)}`} loading="lazy" decoding="async" onError={() => setAttempt((value) => value + 1)} className={`h-full w-full object-cover transition-transform duration-500 ${hideSpoilers ? "scale-110 blur-xl" : "group-hover:scale-[1.035]"} ${isPoster ? "opacity-55" : ""}`} /> : <div className="flex h-full flex-col items-center justify-center gap-2 bg-[#202026]"><span className="brand-symbol !text-2xl">紅</span><span className="text-[9px] text-white/35">Превью пока нет</span></div>}
    <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/55 via-transparent to-transparent" />
    {isPoster && source && !hideSpoilers && <span className="absolute bottom-2 left-2 rounded bg-black/55 px-1.5 py-0.5 text-[8px] text-white/65">Обложка тайтла</span>}
    {hideSpoilers && <EyeOff size={18} className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-white/60" />}
  </div>;
}

type Props = { release: Release; episodes: Episode[]; current?: number; voice?: string; compact?: boolean; title?: string };

export default function EpisodeGallery({ release, episodes, current, voice, compact = false, title = "Все серии" }: Props) {
  const [search, setSearch] = useState("");
  const [reverse, setReverse] = useState(false);
  const [hideSpoilers, setHideSpoilers] = useState(false);
  const [layout, setLayout] = useState<"grid" | "list">(compact ? "list" : "grid");
  const [page, setPage] = useState(0);
  const [watched, setWatched] = useState(() => getWatched(release.id, voice));
  const [progress, setProgress] = useState(() => progressOf(release.id, voice));
  const selectedEpisodes = useMemo(() => voice ? episodesForVoice(episodes, voice) : episodes, [episodes, voice]);
  const perPage = compact ? 24 : 24;

  useEffect(() => {
    const sync = () => { setWatched(getWatched(release.id, voice)); setProgress(progressOf(release.id, voice)); };
    sync(); window.addEventListener("kurenai:library", sync);
    return () => window.removeEventListener("kurenai:library", sync);
  }, [release.id, voice]);
  const filtered = useMemo(() => {
    const found = selectedEpisodes.filter((episode) => `${episodeNumber(episode)} ${episodeTitle(episode)}`.toLocaleLowerCase("ru").includes(search.toLocaleLowerCase("ru")));
    return reverse ? [...found].reverse() : found;
  }, [selectedEpisodes, search, reverse]);
  useEffect(() => { setPage(0); }, [search, reverse, voice]);
  useEffect(() => {
    if (current == null) return;
    const index = filtered.findIndex((episode) => episode.ordinal === current);
    if (index >= 0) setPage(Math.floor(index / perPage));
  }, [current, release.id, voice]);
  const pages = Math.max(1, Math.ceil(filtered.length / perPage));
  const visible = filtered.slice(Math.min(page, pages - 1) * perPage, (Math.min(page, pages - 1) + 1) * perPage);

  return <section className={`episode-gallery ${compact ? "compact" : ""}`}>
    <div className="mb-5 flex items-center justify-between gap-3"><div><h2 className={compact ? "text-[16px] font-medium" : "section-heading"}>{title}</h2><p className="mt-1.5 text-[10px] text-mist">{episodeCountText(selectedEpisodes.length)}{watched.length ? ` · ${selectedEpisodes.filter((episode) => watched.includes(episode.ordinal)).length} просмотрено` : ""}</p></div>
      <div className="flex gap-0.5"><button className={`icon-button !h-9 !w-9 ${hideSpoilers ? "!text-shu" : ""}`} onClick={() => setHideSpoilers(!hideSpoilers)} aria-label={hideSpoilers ? "Показать превью и названия" : "Скрыть спойлеры"} title="Скрыть спойлеры">{hideSpoilers ? <EyeOff size={15} /> : <Eye size={15} />}</button><button className="icon-button !h-9 !w-9" onClick={() => setLayout(layout === "grid" ? "list" : "grid")} aria-label={layout === "grid" ? "Показать списком" : "Показать сеткой"}>{layout === "grid" ? <List size={16} /> : <LayoutGrid size={15} />}</button></div>
    </div>
    <div className="mb-5 flex gap-2"><label className="flex h-10 min-w-0 flex-1 items-center gap-2.5 rounded-lg border border-white/9 bg-white/[.025] px-3"><Search size={14} className="shrink-0 text-mist" /><input type="search" aria-label="Поиск по сериям" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Номер или название серии" className="min-w-0 w-full bg-transparent text-[11px] outline-none" /></label><button className={`icon-button !h-10 !w-10 rounded-lg border border-white/9 ${reverse ? "!text-shu" : ""}`} aria-label={reverse ? "Сначала первые серии" : "Сначала последние серии"} onClick={() => setReverse(!reverse)}><ArrowDownWideNarrow size={16} /></button></div>
    <div className={`episode-collection ${layout}`}>
      {visible.map((episode, index) => {
        const active = episode.ordinal === current;
        const done = watched.includes(episode.ordinal);
        const percent = progress?.ep === episode.ordinal && progress.duration > 0 ? Math.min(100, progress.time / progress.duration * 100) : 0;
        return <motion.article key={`${voice}:${episode.id}`} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: Math.min(index * .025, .15), duration: .25 }} className={`episode-card group ${active ? "active" : ""}`}>
          <a className="episode-card-link" href={watchHref(release.id, episode.ordinal, voice)} aria-current={active ? "true" : undefined}>
            <div className="relative min-w-0">
              <EpisodeImage episode={episode} release={release} hideSpoilers={hideSpoilers} />
              <span className="episode-index">{episode.label || String(episode.ordinal).padStart(2, "0")}</span>
              {episode.duration ? <span className="episode-duration">{Math.floor(episode.duration / 60)}:{String(Math.round(episode.duration % 60)).padStart(2, "0")}</span> : null}
              <span className="episode-play"><Play size={19} fill="currentColor" className="ml-0.5" /></span>
              {percent > 0 && <span className="episode-progress"><span style={{ width: `${percent}%` }} /></span>}
            </div>
            <div className="episode-copy"><p className="episode-overline">{active ? <><span className="now-playing"><i /><i /><i /></span>Сейчас смотрите</> : episodeNumber(episode)}</p><h3>{hideSpoilers ? episodeNumber(episode) : episodeTitle(episode)}</h3><p className="episode-description">{done ? "Просмотрено" : episode.duration ? <><Clock3 size={10} />{Math.round(episode.duration / 60)} мин</> : "Название ещё не опубликовано"}</p></div>
          </a>
          <button className={`episode-watchmark ${done ? "checked" : ""}`} onClick={() => setEpisodeWatched(release.id, episode.ordinal, !done, voice)} aria-label={done ? `Снять отметку: ${episodeNumber(episode)}` : `Отметить просмотренной: ${episodeNumber(episode)}`} aria-pressed={done} title={done ? "Просмотрено" : "Отметить просмотренной"}><Check size={13} /></button>
        </motion.article>;
      })}
    </div>
    {filtered.length === 0 && <p className="py-10 text-center text-xs leading-6 text-mist">{episodes.length ? "Такой серии нет. Попробуйте другое название." : "Эпизоды появятся здесь после публикации."}</p>}
    {pages > 1 && <div className="mt-5 flex items-center justify-between gap-3"><button className="icon-button border border-white/10" disabled={page <= 0} aria-label="Предыдущие серии" onClick={() => setPage((value) => value - 1)}><ChevronLeft size={15} /></button><span className="text-[10px] text-mist">{Math.min(page, pages - 1) + 1} / {pages}</span><button className="icon-button border border-white/10" disabled={page >= pages - 1} aria-label="Следующие серии" onClick={() => setPage((value) => value + 1)}><ChevronRight size={15} /></button></div>}
  </section>;
}