import { Check, ChevronDown, Headphones, LoaderCircle, RefreshCw } from "lucide-react";
import type { VoiceChoice } from "../lib/playback";
import { episodeCountText } from "../lib/playback";

type Props = { choices: VoiceChoice[]; selected: string; onSelect: (voice: string) => void; loading?: boolean; error?: string; onRetry?: () => void };

export default function VoicePicker({ choices, selected, onSelect, loading, error, onRetry }: Props) {
  const current = choices.find((voice) => voice.id === selected);
  return <section className="voice-selector voice-selector-v5" id="voice-selector">
    <div className="flex items-center gap-3"><span className="voice-icon"><Headphones size={19} strokeWidth={1.5} /></span><div><p className="text-[13px] font-medium">Озвучка</p><p className="mt-1 text-[10px] text-mist">{current ? episodeCountText(current.count) : loading ? "Подбираем голоса..." : "Пока недоступна"}{current && <span className="ml-1.5 text-white/30">в этом переводе</span>}</p></div></div>
    <div className="min-w-0 flex-1 sm:max-w-[380px]"><label className="relative block"><span className="sr-only">Выбрать озвучку</span><select value={current ? selected : ""} onChange={(event) => onSelect(event.target.value)} className="voice-select" disabled={!choices.length}>{!current && <option value="">{loading ? "Загружаем озвучки..." : "Нет доступных озвучек"}</option>}{choices.map((voice) => <option value={voice.id} key={voice.id}>{voice.name} · {episodeCountText(voice.count)}</option>)}</select><ChevronDown size={14} className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-mist" /></label>
      <div className="mt-2 flex items-center gap-1.5 text-[9px] text-mist">{loading ? <><LoaderCircle size={10} className="animate-spin" />Ищем дополнительные озвучки</> : current ? <><Check size={11} className="text-[#a9caae]" />Список серий соответствует выбранной озвучке</> : "Доступность зависит от опубликованных серий"}</div>
      {error && <div className="mt-2 flex items-start gap-2"><p role="status" className="text-[10px] leading-5 text-[#c0a7a0]">Не удалось обновить дополнительные озвучки.</p>{onRetry && <button className="icon-button !h-6 !w-6" aria-label="Повторить загрузку озвучек" onClick={onRetry}><RefreshCw size={12} /></button>}</div>}
    </div>
  </section>;
}