import { useEffect, useRef } from "react";
import { AnimatePresence, motion, MotionConfig } from "framer-motion";
import { ArrowUpRight, Download, X } from "lucide-react";
import Nav, { Brand } from "./components/Nav";
import { useRoute } from "./router";
import { DownloadsProvider, useDownloads } from "./lib/downloads";
import Home from "./pages/Home";
import Catalog from "./pages/Catalog";
import Title from "./pages/Title";
import Watch from "./pages/Watch";
import Schedule from "./pages/Schedule";
import Favorites from "./pages/Favorites";
import Downloads from "./pages/Downloads";
import Connections from "./pages/Connections";

function Application() {
  const route = useRoute();
  const previousPage = useRef("");
  const { notice, dismissNotice } = useDownloads();
  useEffect(() => {
    if (route.name !== "watch" || previousPage.current !== "watch") window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
    previousPage.current = route.name;
    const titles: Record<string, string> = { home: "Твой мир аниме", catalog: "Каталог", schedule: "Расписание", favorites: "Моя коллекция", title: "Аниме", watch: "Просмотр", downloads: "Загрузки", connections: "Настройки просмотра" };
    document.title = `${titles[route.name]} - Kurenai`;
  }, [route]);
  useEffect(() => {
    const env = (import.meta as ImportMeta & { env?: { PROD?: boolean } }).env;
    if (env?.PROD && "serviceWorker" in navigator) {
      void navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    }
  }, []);
  useEffect(() => {
    if (!notice) return;
    const timer = window.setTimeout(dismissNotice, 6500);
    return () => clearTimeout(timer);
  }, [notice, dismissNotice]);

  return <div className="min-h-screen bg-void text-ink">
    <a href="#main-content" onClick={(event) => { event.preventDefault(); document.getElementById("main-content")?.focus(); }} className="sr-only z-[100] bg-panel px-5 py-3 focus:not-sr-only focus:fixed focus:left-4 focus:top-4">Перейти к содержимому</a>
    <Nav route={route} />
    <main id="main-content" tabIndex={-1} className="outline-none">
      {route.name === "home" && <Home />}
      {route.name === "catalog" && <Catalog q={route.q} />}
      {route.name === "title" && <Title id={route.id} />}
      {route.name === "watch" && <Watch id={route.id} ep={route.ep} voice={route.voice} />}
      {route.name === "schedule" && <Schedule />}
      {route.name === "favorites" && <Favorites />}
      {route.name === "downloads" && <Downloads />}
      {route.name === "connections" && <Connections />}
    </main>
    {route.name !== "watch" && <footer className="page-shell mt-10">
      <div className="flex flex-col justify-between gap-7 border-t border-white/10 py-9 sm:flex-row sm:items-center">
        <div><Brand /><p className="mt-3 text-[11px] text-mist">Для тех, кто чувствует чуть больше.</p></div>
        <div className="flex flex-wrap gap-6 text-xs text-mist"><a className="hover:text-ink" href="#/catalog">Каталог</a><a className="hover:text-ink" href="#/favorites">Моя коллекция</a><a className="flex items-center gap-1 hover:text-ink" href="#/downloads">Смотреть офлайн<ArrowUpRight size={12} /></a><a className="hover:text-ink" href="#/connections">Настройки</a></div>
        <p className="text-[10px] text-white/30">Kurenai © {new Date().getFullYear()}</p>
      </div>
    </footer>}
    <AnimatePresence>{notice && <motion.div className="toast" role="status" initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }}><div className="flex items-start gap-3"><Download size={18} className="mt-0.5 shrink-0 text-shu" /><div><p className="text-xs leading-6">{notice}</p><a className="mt-1 inline-flex items-center gap-2 text-xs text-shu" href="#/downloads" onClick={dismissNotice}>Открыть загрузки<ArrowUpRight size={13} /></a></div><button aria-label="Закрыть уведомление" onClick={dismissNotice} className="p-1 text-mist"><X size={16} /></button></div></motion.div>}</AnimatePresence>
  </div>;
}

export default function App() {
  return <MotionConfig reducedMotion="user"><DownloadsProvider><Application /></DownloadsProvider></MotionConfig>;
}