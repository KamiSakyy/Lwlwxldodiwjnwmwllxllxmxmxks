import { useEffect, useState } from "react";

export type Route =
  | { name: "home" }
  | { name: "catalog"; q: Record<string, string> }
  | { name: "title"; id: number }
  | { name: "watch"; id: number; ep: number; voice?: string }
  | { name: "schedule" }
  | { name: "downloads" }
  | { name: "connections" }
  | { name: "favorites" };

export function parseHash(): Route {
  const raw = (location.hash.replace(/^#/, "") || "/").trim();
  const [path, query] = raw.split("?");
  const parts = path.split("/").filter(Boolean);
  const q: Record<string, string> = {};
  new URLSearchParams(query || "").forEach((v, k) => {
    q[k] = v;
  });

  if (parts[0] === "catalog") return { name: "catalog", q };
  if (parts[0] === "schedule") return { name: "schedule" };
  if (parts[0] === "downloads") return { name: "downloads" };
  if (parts[0] === "connections") return { name: "connections" };
  if (parts[0] === "favorites") return { name: "favorites" };
  const id = Number(parts[1]);
  const ep = Number(parts[2] ?? 1);
  if (parts[0] === "title" && Number.isInteger(id) && id > 0) return { name: "title", id };
  if (parts[0] === "watch" && Number.isInteger(id) && id > 0 && Number.isFinite(ep) && ep >= 0) return { name: "watch", id, ep, voice: q.voice };
  return { name: "home" };
}

export function go(to: string) {
  const path = (to.startsWith("#") ? to.slice(1) : to) || "/";
  const next = path.startsWith("/") ? path : `/${path}`;
  if (location.hash === `#${next}`) return;
  location.hash = next;
}

export function href(to: string) {
  return `#${to.startsWith("/") ? to : `/${to}`}`;
}

export function useRoute(): Route {
  const [route, setRoute] = useState<Route>(parseHash);
  useEffect(() => {
    const on = () => setRoute(parseHash());
    window.addEventListener("hashchange", on);
    if (!location.hash) location.hash = "/";
    return () => window.removeEventListener("hashchange", on);
  }, []);
  return route;
}

export function catalogHref(q: Record<string, string | undefined>) {
  const p = new URLSearchParams();
  Object.entries(q).forEach(([k, v]) => {
    if (v) p.set(k, v);
  });
  const s = p.toString();
  return s ? `#/catalog?${s}` : "#/catalog";
}
