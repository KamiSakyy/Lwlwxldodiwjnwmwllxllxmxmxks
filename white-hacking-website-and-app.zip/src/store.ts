import type { Release, VideoQuality } from "./api";
import { img, titleOf } from "./api";
import { migrateVoice } from "./lib/voices";

const HKEY = "kurenai.history";
const FKEY = "kurenai.favorites";
const QKEY = "kurenai.quality";
const memory = new Map<string, unknown>();

export type HistoryItem = {
  id: number;
  name: string;
  poster: string;
  ep: number;
  time: number;
  duration: number;
  updated: number;
  voice?: string;
  voiceName?: string;
};

export type FavItem = { id: number; name: string; poster: string };

function read<T>(key: string, fallback: T): T {
  if (memory.has(key)) return memory.get(key) as T;
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write(key: string, value: unknown) {
  memory.set(key, value);
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* Keep the session usable if persistent storage is unavailable. */
  }
  window.dispatchEvent(new Event("kurenai:library"));
}

export function getHistory(): HistoryItem[] {
  const data = read<HistoryItem[]>(HKEY, []);
  return (Array.isArray(data) ? data : []).filter((item) => item && typeof item.id === "number" && typeof item.name === "string" && Number.isFinite(item.time) && Number.isFinite(item.ep)).sort((a, b) => b.updated - a.updated);
}

export function saveProgress(r: Release, ep: number, time: number, duration: number, voice = "primary", voiceName?: string) {
  if (!Number.isFinite(time) || !Number.isFinite(duration) || r.id < 0) return;
  const list = getHistory().filter((h) => h.id !== r.id);
  const item: HistoryItem = {
    id: r.id,
    name: titleOf(r),
    poster: img(r.episodes?.find((episode) => episode.ordinal === ep)?.preview || r.poster, "preview"),
    ep,
    time,
    duration,
    updated: Date.now(),
    voice: migrateVoice(voice), voiceName,
  };
  list.unshift(item);
  write(HKEY, list.slice(0, 40));
  const previous = read<HistoryItem[]>("kurenai.positions", []);
  const positions = Array.isArray(previous) ? previous.filter((entry) => entry && !(entry.id === r.id && entry.ep === ep && migrateVoice(entry.voice) === item.voice)) : [];
  write("kurenai.positions", [item, ...positions].slice(0, 500));
}

export function progressOf(id: number, voice?: string, episode?: number): HistoryItem | undefined {
  if (voice === undefined && episode === undefined) return getHistory().find((item) => item.id === id);
  const key = migrateVoice(voice);
  const positions = read<HistoryItem[]>("kurenai.positions", []);
  const match = (item: HistoryItem) => item && item.id === id && migrateVoice(item.voice) === key && (episode === undefined || item.ep === episode) && Number.isFinite(item.time);
  return (Array.isArray(positions) ? positions.find(match) : undefined) || getHistory().find(match);
}

export function getFavs(): FavItem[] {
  const data = read<FavItem[]>(FKEY, []);
  return (Array.isArray(data) ? data : []).filter((item) => item && typeof item.id === "number" && typeof item.name === "string");
}

export function removeFavorite(id: number) { write(FKEY, getFavs().filter((item) => item.id !== id)); }
export function removeHistory(id: number) {
  write(HKEY, getHistory().filter((item) => item.id !== id));
  const positions = read<HistoryItem[]>("kurenai.positions", []);
  write("kurenai.positions", Array.isArray(positions) ? positions.filter((item) => item.id !== id) : []);
}

export function getWatched(id: number, voice = "primary"): number[] {
  const selected = migrateVoice(voice);
  const data = read<unknown>(selected === "primary" ? `kurenai.watched.${id}` : `kurenai.watched.${id}.${encodeURIComponent(selected)}`, []);
  return Array.isArray(data) ? data.filter((value): value is number => typeof value === "number" && Number.isFinite(value)) : [];
}

export function setEpisodeWatched(id: number, ordinal: number, watched: boolean, voice = "primary") {
  const selected = migrateVoice(voice);
  const previous = getWatched(id, selected);
  const key = selected === "primary" ? `kurenai.watched.${id}` : `kurenai.watched.${id}.${encodeURIComponent(selected)}`;
  write(key, watched ? [...new Set([...previous, ordinal])].slice(-3000) : previous.filter((value) => value !== ordinal));
}

export function isFav(id: number): boolean {
  return getFavs().some((f) => f.id === id);
}

export function toggleFav(r: Release): boolean {
  const list = getFavs();
  const exists = list.some((f) => f.id === r.id);
  const next = exists
    ? list.filter((f) => f.id !== r.id)
    : [{ id: r.id, name: titleOf(r), poster: img(r.poster, "preview") }, ...list];
  write(FKEY, next);
  return !exists;
}

export function getQuality(): VideoQuality {
  const q = read<string>(QKEY, "720");
  return q === "1080" || q === "480" || q === "360" ? q : "720";
}

export function setQuality(q: VideoQuality) {
  write(QKEY, q);
}

window.addEventListener("storage", (event) => {
  if (event.key) memory.delete(event.key);
  else memory.clear();
  window.dispatchEvent(new Event("kurenai:library"));
});
