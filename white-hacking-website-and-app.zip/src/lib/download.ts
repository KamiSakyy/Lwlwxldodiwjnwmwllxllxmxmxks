import { Parser, type ByteRange, type Manifest, type Segment } from "m3u8-parser";
import muxjs from "mux.js";
import { hasVideoAndAudio, setMp4Duration, trackSignature } from "./mp4";
import { mediaUrl } from "./network";

export type DownloadProgress = { completed: number; total: number; bytes: number; speed: number };
export type FileSink = { write(data: Uint8Array): Promise<void>; close(): Promise<void>; abort(): Promise<void> };
export type SaveHandle = { createWritable(): Promise<FileSink> };
export type DownloadResult = { blob?: Blob; bytes: number; cleanup?: () => Promise<void> };

async function temporaryDiskFile(): Promise<{ sink: FileSink; file: FileSystemFileHandle; cleanup: () => Promise<void> } | null> {
  if (!navigator.storage?.getDirectory) return null;
  let cleanup: (() => Promise<void>) | undefined;
  try {
    const root = await navigator.storage.getDirectory();
    const directory = await root.getDirectoryHandle("kurenai-prepared-downloads", { create: true });
    // Only remove our stale temporary files, never user-picked files.
    const entries = directory as FileSystemDirectoryHandle & { entries?: () => AsyncIterableIterator<[string, FileSystemHandle]> };
    if (entries.entries) {
      for await (const [name] of entries.entries()) {
        const created = Number(name.split("-")[0]);
        if (created > 0 && Date.now() - created > 7 * 24 * 3600_000) await directory.removeEntry(name).catch(() => undefined);
      }
    }
    const name = `${Date.now()}-${Math.random().toString(36).slice(2)}.mp4`;
    cleanup = () => directory.removeEntry(name).catch(() => undefined);
    const file = await directory.getFileHandle(name, { create: true });
    const writable = await file.createWritable();
    const sink: FileSink = {
      write: (data) => writable.write(new Uint8Array(data)),
      close: () => writable.close(),
      abort: () => writable.abort(),
    };
    return { sink, file, cleanup };
  } catch {
    await cleanup?.();
    return null;
  }
}

export function downloadFilename(name: string, episode: number, quality: string) {
  const safe = name.replace(/[<>:"/\\|?*\u0000-\u001f]/g, "").trim().slice(0, 110) || "Kurenai";
  return `${safe} - ${String(episode).padStart(2, "0")} - ${quality}p.mp4`;
}

export function readableBytes(bytes: number) {
  if (bytes < 1024) return `${Math.round(bytes)} Б`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} КБ`;
  if (bytes < 1024 ** 3) return `${(bytes / 1024 ** 2).toFixed(1)} МБ`;
  return `${(bytes / 1024 ** 3).toFixed(2)} ГБ`;
}

function cancelled(signal: AbortSignal) {
  if (signal.aborted) throw new DOMException("Загрузка отменена", "AbortError");
}

async function resource(url: string, signal: AbortSignal, range?: ByteRange): Promise<{ bytes: Uint8Array<ArrayBuffer>; url: string }> {
  url = await mediaUrl(url);
  for (let attempt = 0; attempt < 3; attempt++) {
    cancelled(signal);
    const controller = new AbortController();
    const abort = () => controller.abort();
    signal.addEventListener("abort", abort, { once: true });
    const timeout = window.setTimeout(abort, 25_000);
    try {
      const offset = range?.offset ?? 0;
      const headers: Record<string, string> = range ? { Range: `bytes=${offset}-${offset + range.length - 1}` } : {};
      const response = await fetch(url, { signal: controller.signal, headers, credentials: "omit" });
      if (!response.ok) throw new Error("Сервер временно не отдаёт файл.");
      let bytes = new Uint8Array(await response.arrayBuffer());
      if (range && response.status === 200) bytes = bytes.slice(offset, offset + range.length);
      if (range && bytes.byteLength !== range.length) throw new Error("Сегмент видео загружен не полностью.");
      return { bytes, url: response.url || url };
    } catch {
      cancelled(signal);
      if (attempt === 2) throw new Error("Не удалось загрузить видео. Проверьте сеть; браузер или сервер могут ограничивать скачивание.");
      await new Promise((resolve) => setTimeout(resolve, 600 * (attempt + 1)));
    } finally {
      clearTimeout(timeout);
      signal.removeEventListener("abort", abort);
    }
  }
  throw new Error("Загрузка недоступна.");
}

async function playlist(url: string, quality: number, signal: AbortSignal, depth = 0): Promise<{ manifest: Manifest; base: string }> {
  if (depth > 3) throw new Error("Слишком много вложенных плейлистов.");
  const data = await resource(url, signal);
  const content = new TextDecoder().decode(data.bytes);
  if (!content.trimStart().startsWith("#EXTM3U")) throw new Error("Вместо видео получен недопустимый ответ.");
  const parser = new Parser({ url: data.url });
  parser.push(content);
  parser.end();
  const manifest = parser.manifest;
  if (manifest.playlists?.length) {
    const choices = manifest.playlists;
    const selected = choices.find((p) => p.attributes.RESOLUTION?.height === quality)
      ?? (choices.length === 1 && !choices[0].attributes.RESOLUTION ? choices[0] : undefined);
    if (!selected) throw new Error("Выбранное качество отсутствует. Выберите другое качество скачивания.");
    const audio = selected.attributes.AUDIO;
    if (audio && Object.values(manifest.mediaGroups?.AUDIO?.[audio] ?? {}).some((track) => track.uri)) {
      throw new Error("Этот выпуск использует раздельную звуковую дорожку. Скачивание такого формата пока не поддерживается.");
    }
    return playlist(new URL(selected.uri, data.url).href, quality, signal, depth + 1);
  }
  if (!manifest.endList) throw new Error("Скачивание доступно только для завершённых видео, не для прямых трансляций.");
  if (!manifest.segments?.length) throw new Error("В этой серии пока нет видео.");
  if (manifest.segments.length > 12_000) throw new Error("Видео слишком длинное для загрузки в браузере.");
  return { manifest, base: data.url };
}

export async function downloadEpisode(
  url: string,
  quality: number,
  signal: AbortSignal,
  onProgress: (progress: DownloadProgress) => void,
  handle?: SaveHandle,
): Promise<DownloadResult> {
  const { manifest, base } = await playlist(url, quality, signal);
  const segments = manifest.segments;
  const totalDuration = segments.reduce((sum, segment) => sum + (segment.duration || 0), 0);
  const fmp4 = Boolean(segments[0].map);
  if (segments.some((segment) => Boolean(segment.map) !== fmp4)) {
    throw new Error("Выпуск содержит разные видеоформаты и не может быть сохранён одним файлом.");
  }
  if (segments.some((segment) => segment.key && !["NONE", "AES-128"].includes(segment.key.method))) {
    throw new Error("Защищённое видео недоступно для скачивания.");
  }
  const mapKey = (s: Segment) => JSON.stringify(s.map);
  if (fmp4 && segments.some((s) => mapKey(s) !== mapKey(segments[0]) || s.discontinuity)) {
    throw new Error("Этот выпуск содержит смену видеоформата. Сохранение единого MP4 пока недоступно.");
  }

  // Resolve implicit byte ranges before parallel fetching.
  const offsets = new Map<string, number>();
  for (const segment of segments) {
    if (segment.byterange) {
      segment.byterange.offset ??= offsets.get(segment.uri) ?? 0;
      offsets.set(segment.uri, segment.byterange.offset + segment.byterange.length);
    }
  }
  const temporary = handle ? null : await temporaryDiskFile();
  const sink = handle ? await handle.createWritable() : temporary?.sink;
  const parts: Blob[] = [];
  const keys = new Map<string, CryptoKey>();
  const memory = (navigator as Navigator & { deviceMemory?: number }).deviceMemory ?? 4;
  const maxBytes = (memory <= 2 ? 256 : 600) * 1024 * 1024;
  let bytes = 0;
  let completed = 0;
  let elapsed = 0;
  let initialized = false;
  let initialSignature = "";
  let fragments: Uint8Array[] = [];
  let muxError: Error | null = null;
  const started = performance.now();
  const transmuxer = fmp4 ? undefined : new muxjs.mp4.Transmuxer({ remux: true, keepOriginalTimestamps: false });

  transmuxer?.on("data", (segment) => {
    if (muxError) return;
    if (!initialized) {
      if (segment.type !== "combined") {
        muxError = new Error("Не удалось собрать обе дорожки. Файл без звука или изображения не будет сохранён.");
        return;
      }
      if (!segment.initSegment.byteLength) { muxError = new Error("Не удалось собрать видеоконтейнер."); return; }
      try {
        initialSignature = trackSignature(segment.initSegment);
        fragments.push(setMp4Duration(segment.initSegment, totalDuration));
      } catch { muxError = new Error("Не удалось подготовить заголовок MP4."); return; }
      initialized = true;
    } else if (segment.type === "combined" && trackSignature(segment.initSegment) !== initialSignature) {
      muxError = new Error("Выпуск меняет формат изображения или звука. Сохранение такого видео одним MP4 пока недоступно.");
      return;
    }
    fragments.push(segment.data);
  });
  transmuxer?.on("error", () => { muxError = new Error("Не удалось собрать MP4 из этого видеоформата."); });

  const append = async (data: Uint8Array) => {
    cancelled(signal);
    bytes += data.byteLength;
    if (sink) await sink.write(new Uint8Array(data));
    else {
      if (bytes > maxBytes) throw new Error("Файл превысил безопасный лимит памяти браузера. Попробуйте 480p или браузер с записью прямо на диск.");
      parts.push(new Blob([new Uint8Array(data)]));
    }
  };

  const getSegment = async (segment: Segment, index: number) => {
    let { bytes: data } = await resource(new URL(segment.uri, base).href, signal, segment.byterange);
    const key = segment.key;
    if (key?.method === "AES-128") {
      if (!key.uri || !crypto.subtle || (key.keyFormat && key.keyFormat !== "identity")) {
        throw new Error("Формат шифрования этого выпуска не поддерживается.");
      }
      const keyUrl = new URL(key.uri, base).href;
      let imported = keys.get(keyUrl);
      if (!imported) {
        const keyData = await resource(keyUrl, signal);
        imported = await crypto.subtle.importKey("raw", keyData.bytes, { name: "AES-CBC" }, false, ["decrypt"]);
        keys.set(keyUrl, imported);
      }
      const iv = new Uint8Array(16);
      const view = new DataView(iv.buffer);
      if (key.iv) for (let i = 0; i < 4; i++) view.setUint32(i * 4, key.iv[i], false);
      else view.setUint32(12, (manifest.mediaSequence ?? 0) + index, false);
      data = new Uint8Array(await crypto.subtle.decrypt({ name: "AES-CBC", iv }, imported, data));
    }
    return data;
  };

  try {
    onProgress({ completed: 0, total: segments.length, bytes: 0, speed: 0 });
    if (fmp4 && segments[0].map) {
      if (segments[0].key?.method === "AES-128") throw new Error("Скачивание шифрованного MP4 пока не поддерживается.");
      const map = segments[0].map;
      const initialization = (await resource(new URL(map.uri, base).href, signal, map.byterange)).bytes;
      if (!hasVideoAndAudio(initialization)) throw new Error("Этот файл содержит только одну дорожку. Скачивание без звука или изображения не поддерживается.");
      await append(setMp4Duration(initialization, totalDuration));
    }
    for (let start = 0; start < segments.length; start += 3) {
      cancelled(signal);
      const batch = segments.slice(start, start + 3);
      const data = await Promise.all(batch.map((segment, i) => getSegment(segment, start + i)));
      for (let i = 0; i < data.length; i++) {
        cancelled(signal);
        const segment = batch[i];
        if (transmuxer) {
          if (segment.discontinuity) {
            transmuxer.reset();
            transmuxer.setBaseMediaDecodeTime(Math.round(elapsed * 90_000));
          }
          fragments = [];
          transmuxer.push(data[i]);
          transmuxer.flush();
          if (muxError) throw muxError;
          if (!fragments.length) throw new Error("Видео использует неподдерживаемый кодек. Файл не будет сохранён без звука или изображения.");
          for (const fragment of fragments) await append(fragment);
        } else await append(data[i]);
        elapsed += segment.duration || 0;
        completed++;
        onProgress({ completed, total: segments.length, bytes, speed: bytes / Math.max(1, (performance.now() - started) / 1000) });
      }
      await new Promise((resolve) => setTimeout(resolve, 0));
    }
    cancelled(signal);
    if (sink) {
      await sink.close();
      if (temporary) return { bytes, blob: await temporary.file.getFile(), cleanup: temporary.cleanup };
      return { bytes };
    }
    return { blob: new Blob(parts, { type: "video/mp4" }), bytes };
  } catch (error) {
    await sink?.abort().catch(() => undefined);
    await temporary?.cleanup();
    if (error instanceof DOMException && error.name === "QuotaExceededError") throw new Error("Недостаточно места для видео. Освободите память устройства или выберите качество ниже.");
    throw error;
  } finally {
    transmuxer?.dispose();
    keys.clear();
  }
}