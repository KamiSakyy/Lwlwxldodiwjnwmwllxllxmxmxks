import { qualities, type Episode, type EpisodeSource, type SourceProvider } from "../api";
import { migrateVoice, PRIMARY_VOICE } from "./voices";

export type VoiceChoice = { id: string; name: string; count: number; ordinals: number[] };

/** Preferred attempt order. Public direct streams come first; the rest are still listed. */
const PROVIDER_ORDER: SourceProvider[] = ["aksor", "alloha", "cvh", "sibnet", "zedfilm", "vk", "rutube", "other"];

export function episodeTitle(episode: Episode) {
  return episode.name?.trim().replace(/^[«“"]|[»”"]$/g, "") || episode.name_english?.trim() || episode.label || `Эпизод ${episode.ordinal}`;
}

export function episodeNumber(episode: Episode) { return episode.label || `Серия ${episode.ordinal}`; }

export function sourcesForVoice(episode: Episode, voice: string): EpisodeSource[] {
  const id = migrateVoice(voice);
  const list = (episode.sources || []).filter((source) => source.voiceId === id);
  return [...list].sort((a, b) => PROVIDER_ORDER.indexOf(a.provider) - PROVIDER_ORDER.indexOf(b.provider));
}

export function voiceAvailable(episode: Episode, voice: string) {
  const id = migrateVoice(voice);
  return (id === PRIMARY_VOICE && qualities(episode).length > 0) || sourcesForVoice(episode, id).length > 0;
}

export function voiceChoices(episodes: Episode[]): VoiceChoice[] {
  const voices = new Map<string, { name: string; numbers: Set<number> }>();
  const add = (id: string, name: string, ordinal: number) => {
    if (!Number.isFinite(ordinal)) return;
    const current = voices.get(id) || { name, numbers: new Set<number>() };
    current.numbers.add(ordinal);
    voices.set(id, current);
  };
  for (const episode of episodes) {
    if (qualities(episode).length) add(PRIMARY_VOICE, "Основная озвучка", episode.ordinal);
    for (const source of episode.sources || []) {
      add(source.voiceId, source.voiceId === PRIMARY_VOICE ? "Основная озвучка" : source.name, episode.ordinal);
    }
  }
  return [...voices].map(([id, voice]) => ({ id, name: voice.name, count: voice.numbers.size, ordinals: [...voice.numbers].sort((a, b) => a - b) }))
    .sort((a, b) => a.id === PRIMARY_VOICE ? -1 : b.id === PRIMARY_VOICE ? 1 : a.name.localeCompare(b.name, "ru"));
}

export function episodesForVoice(episodes: Episode[], voice: string): Episode[] {
  const id = migrateVoice(voice);
  const seen = new Set<number>();
  return [...episodes].sort((a, b) => a.ordinal - b.ordinal).filter((episode) => {
    if (seen.has(episode.ordinal) || !voiceAvailable(episode, id)) return false;
    seen.add(episode.ordinal); return true;
  }).map((episode) => {
    const direct = id === PRIMARY_VOICE && qualities(episode).length > 0;
    const source = sourcesForVoice(episode, id)[0];
    return { ...episode, voiceId: id, voiceName: direct ? "Основная озвучка" : source?.name,
      duration: direct ? episode.duration : source?.duration ?? episode.duration,
      opening: direct ? episode.opening : source?.opening,
      ending: direct ? episode.ending : source?.ending,
    };
  });
}

export function episodeCountText(count: number) {
  const last = count % 10; const teen = count % 100;
  return `${count} ${last === 1 && teen !== 11 ? "серия" : last >= 2 && last <= 4 && (teen < 12 || teen > 14) ? "серии" : "серий"}`;
}

export function watchHref(id: number, ordinal: number, voice?: string) {
  return `#/watch/${id}/${ordinal}${voice ? `?voice=${encodeURIComponent(migrateVoice(voice))}` : ""}`;
}