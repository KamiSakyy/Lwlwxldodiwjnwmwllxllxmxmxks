import { getRelease, img, YUMMY_ID_OFFSET, type CatalogFilter, type CatalogResult, type Episode, type EpisodeSource, type Genre, type Release, type Skip, type SourceProvider } from "../api";

import { getApplicationToken, getGateway, httpsUrl } from "./network";
import { aksorVideoId, voiceIdentity } from "./voices";

type YummyVideo = {
  video_id: number; number: string; index?: number; iframe_url: string; duration?: number;
  data?: { player?: string; player_id?: number; dubbing?: string };
  skips?: { opening?: { time: number; length: number } | null; ending?: { time: number; length: number } | null };
};
type YummyAnime = {
  anime_id: number; anime_url?: string; title: string; description?: string; year?: number;
  other_titles?: string[]; duration?: number; episodes?: { count?: number; aired?: number };
  poster?: { fullsize?: string; big?: string; medium?: string; small?: string; huge?: string };
  rating?: { average?: number; shikimori_rating?: number; myanimelist_rating?: number };
  type?: { value?: number; shortname?: string; name?: string; alias?: string };
  min_age?: { value?: number; title?: string }; anime_status?: { value?: number; title?: string };
  genres?: { id: number; title: string }[]; season?: number; videos?: YummyVideo[];
  remote_ids?: { anilibria_alias?: string; shikimori_id?: number; myanimelist_id?: number };
};
type Envelope<T> = { response?: T; error?: unknown; error_code?: number; error_title?: string; error_name?: string };

const cache = new Map<string, { value: unknown; time: number }>();
const requests = new Map<string, Promise<unknown>>();
let connectionRevision = 0;
window.addEventListener("kurenai:connections", () => { connectionRevision++; cache.clear(); requests.clear(); });

export class CatalogConnectionError extends Error {
  constructor(public readonly needsToken: boolean, message: string) { super(message); this.name = "CatalogConnectionError"; }
}

async function request<T>(path: string, fresh = false): Promise<T> {
  const key = `${connectionRevision}:${path}`;
  const cached = cache.get(key);
  if (!fresh && cached && Date.now() - cached.time < 60_000) return cached.value as T;
  if (!fresh && requests.has(key)) return requests.get(key) as Promise<T>;
  const promise = (async () => {
    const gateway = await getGateway();
    const token = getApplicationToken();
    const headers: Record<string, string> = { Accept: "application/json, image/webp" };
    if (token) headers["X-Application"] = token;
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), 15_000);
    try {
      const response = await fetch(gateway ? `/api/kurenai/yummy${path}` : `https://api.yani.tv${path}`, {
        signal: controller.signal, headers, credentials: "omit", cache: fresh ? "no-store" : "default",
      });
      if ([401, 403].includes(response.status)) throw new CatalogConnectionError(true, "Дополнительный каталог требует ключ приложения. Откройте настройки подключения.");
      if (response.status === 429) throw new CatalogConnectionError(false, "Слишком много запросов. Подождите немного и попробуйте снова.");
      if (!response.ok) throw new CatalogConnectionError(false, "Дополнительный каталог временно недоступен.");
      const data = await response.json() as Envelope<T>;
      if (data.error || data.error_code) {
        const auth = /token|application|auth/i.test(`${data.error_name || ""} ${String(data.error || "")}`);
        throw new CatalogConnectionError(auth, auth ? "Для подключения нужен действующий ключ приложения." : "Источник не разрешил этот запрос. Попробуйте позже.");
      }
      if (data.response == null) throw new CatalogConnectionError(false, "Источник не вернул данные для этого аниме.");
      cache.set(key, { value: data.response, time: Date.now() });
      if (cache.size > 90) cache.delete(cache.keys().next().value!);
      return data.response;
    } catch (error) {
      if (error instanceof CatalogConnectionError) throw error;
      throw new CatalogConnectionError(false, "Нет соединения с дополнительным каталогом. Проверьте интернет или настройки подключения.");
    } finally { clearTimeout(timer); }
  })();
  requests.set(key, promise);
  try { return await promise; } finally { if (requests.get(key) === promise) requests.delete(key); }
}

function list<T>(data: unknown): T[] { return Array.isArray(data) ? data as T[] : []; }
const number = (value?: number | null) => typeof value === "number" && Number.isFinite(value) && value > 0 ? value : undefined;

export function normalizeYummy(raw: YummyAnime): Release {
  if (!raw || !Number.isSafeInteger(raw.anime_id) || raw.anime_id <= 0 || !raw.title) throw new Error("Некорректная запись каталога.");
  const original = raw.other_titles?.find((name) => /^[a-z0-9]/i.test(name));
  return {
    id: YUMMY_ID_OFFSET + raw.anime_id, provider_id: raw.anime_id, provider: "yummy", alias: raw.anime_url,
    name: { main: raw.title, english: original }, description: raw.description?.replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]*>/g, ""),
    year: raw.year, type: { value: raw.type?.alias?.toUpperCase(), description: raw.type?.shortname || raw.type?.name },
    poster: { src: httpsUrl(raw.poster?.fullsize), preview: httpsUrl(raw.poster?.big || raw.poster?.medium), thumbnail: httpsUrl(raw.poster?.medium || raw.poster?.small) },
    season: { value: ["", "winter", "spring", "summer", "autumn"][raw.season || 0] },
    genres: raw.genres?.map((genre) => ({ id: genre.id, name: genre.title })),
    age_rating: { label: raw.min_age?.title, is_adult: raw.min_age?.value === 5 },
    is_ongoing: raw.anime_status?.value === 1,
    episodes_total: raw.episodes?.count,
    primary_alias: raw.remote_ids?.anilibria_alias || undefined,
    shikimori: { id: raw.remote_ids?.shikimori_id, rating: number(raw.rating?.shikimori_rating) },
    mal: { id: raw.remote_ids?.myanimelist_id, rating: number(raw.rating?.myanimelist_rating) },
    catalog_rating: number(raw.rating?.average) || number(raw.rating?.shikimori_rating),
  };
}

function skip(value?: { time: number; length: number } | null): Skip | undefined {
  if (!value || !Number.isFinite(value.time) || !Number.isFinite(value.length) || value.length <= 0) return;
  return { start: value.time, stop: value.time + value.length };
}

function ordinalOf(label: string): number | null {
  const match = label.trim().match(/^(?:серия\s*)?(\d+(?:[.,]\d+)?)$/iu);
  return match ? Number(match[1].replace(",", ".")) : null;
}

function providerOf(url: string): SourceProvider {
  try {
    const parsed = new URL(url);
    if (/player\.aksor\.tv$/.test(parsed.hostname) || /aksor\.yani\.tv$/.test(parsed.hostname)) return "aksor";
    if (/(^|\.)video\.sibnet\.ru$/.test(parsed.hostname)) return "sibnet";
    if (/alloha/i.test(parsed.hostname) || /\.stloadi\.live$/i.test(parsed.hostname)) return "alloha";
    if (/yummyani\.me$/.test(parsed.hostname) && /iframeCVH/i.test(parsed.pathname)) return "cvh";
    if (/(^|\.)vk\.(com|ru|video)$/.test(parsed.hostname)) return "vk";
    if (/rutube\.(ru|tv)$/.test(parsed.hostname)) return "rutube";
    if (/zedfilm/i.test(parsed.hostname)) return "zedfilm";
    return "other";
  } catch { return "other"; }
}

function providerRef(provider: SourceProvider, url: string): string | undefined {
  if (provider === "aksor") return aksorVideoId(url) ?? undefined;
  if (provider === "sibnet") return url.match(/[?&]videoid=(\d+)/i)?.[1];
  // Alloha/CVH resolvers take the whole embed URL (their ids live in the query).
  if (provider === "alloha" || provider === "cvh") return url;
  return undefined;
}

export function groupYummyEpisodes(videos: YummyVideo[], release: Release): Episode[] {
  videos = videos.filter((video) => video && (typeof video.number === "string" || typeof video.number === "number") && String(video.number).trim());
  const specialLabels = [...new Set(videos.map((video) => String(video.number).trim()).filter((label) => ordinalOf(label) === null))].sort();
  const groups = new Map<number, Episode>();
  for (const video of videos) {
    const url = httpsUrl(video.iframe_url);
    // Every catalogued voice of this anime stays listed. Whether a provider
    // exposes a direct stream is decided by the resolver, not by this filter.
    if (!url || !Number.isFinite(video.video_id)) continue;
    const label = String(video.number).trim();
    if (!label) continue;
    const parsed = ordinalOf(label);
    const ordinal = parsed ?? 1_000_000 + specialLabels.indexOf(label);
    const identity = voiceIdentity(video.data?.dubbing?.trim() || "Без названия");
    const provider = providerOf(url);
    const ref = providerRef(provider, url);
    const source: EpisodeSource = {
      id: `${provider}:${ref ?? url}`, voiceId: identity.id, name: identity.name, provider, url,
      videoId: ref, animeId: release.provider_id, episodeLabel: label, duration: video.duration,
      opening: skip(video.skips?.opening), ending: skip(video.skips?.ending),
    };
    let episode = groups.get(ordinal);
    if (!episode) {
      episode = { id: `yummy-${release.provider_id}-${label}`, ordinal, label: parsed === null ? label : undefined,
        name: parsed === null ? label : null, duration: video.duration, sources: [],
        preview: release.poster, preview_is_poster: true, release_id: release.id };
      groups.set(ordinal, episode);
    }
    if (!episode.sources!.some((item) => item.id === source.id)) episode.sources!.push(source);
  }
  return [...groups.values()].sort((a, b) => a.ordinal - b.ordinal);
}

function samePrimary(release: Release, primary: Release) {
  if (release.primary_alias !== primary.alias) return false;
  return !(release.shikimori?.id && primary.shikimori?.id && release.shikimori.id !== primary.shikimori.id);
}

export async function getYummyRelease(id: number, fresh = false): Promise<Release> {
  const raw = await request<YummyAnime>(`/anime/${id}?need_videos=1`, fresh);
  const release = normalizeYummy(raw);
  const videos = raw.videos ?? await request<YummyVideo[]>(`/anime/${id}/videos`, fresh);
  release.episodes = groupYummyEpisodes(list<YummyVideo>(videos), release);
  release.episodes_total = release.episodes_total || release.episodes.filter((episode) => !episode.label).length;
  if (release.primary_alias) {
    let deadline = 0;
    try {
      const primary = await Promise.race([
        getRelease(release.primary_alias, fresh),
        new Promise<null>((resolve) => { deadline = window.setTimeout(() => resolve(null), 5500); }),
      ]);
      if (primary && samePrimary(release, primary) && !primary.is_blocked_by_geo && !primary.is_blocked_by_copyrights) {
        release.primary_id = primary.id;
        const primaryEpisodes = new Map(primary.episodes?.map((episode) => [episode.ordinal, episode]));
        release.episodes = release.episodes.map((episode) => {
          const original = primaryEpisodes.get(episode.ordinal);
          return original ? { ...episode, ...original, id: episode.id, sources: episode.sources, preview_is_poster: !img(original.preview) } : episode;
        });
        for (const episode of primary.episodes || []) {
          if (!release.episodes.some((item) => item.ordinal === episode.ordinal)) release.episodes.push(episode);
        }
        release.episodes.sort((a, b) => a.ordinal - b.ordinal);
      }
    } catch { /* An independent catalog must remain usable when the first source is offline. */ }
    finally { clearTimeout(deadline); }
  }
  return release;
}

export async function searchYummy(query: string): Promise<Release[]> {
  const data = await request<YummyAnime[]>(`/anime?q=${encodeURIComponent(query)}&limit=10&offset=0`);
  return list<YummyAnime>(data).map(normalizeYummy);
}

export async function getYummyCatalog(filter: CatalogFilter): Promise<CatalogResult> {
  const limit = Math.min(48, filter.limit || 24);
  const page = Math.max(1, filter.page || 1);
  const params = new URLSearchParams({ limit: String(limit + 1), offset: String((page - 1) * limit) });
  params.set("sort", filter.sorting?.startsWith("YEAR") ? "year" : "rating");
  params.set("sort_forward", filter.sorting?.endsWith("ASC") ? "true" : "false");
  if (filter.search) params.set("q", filter.search);
  if (filter.genres) params.set("genres", filter.genres);
  const types: Record<string, string> = { TV: "1", MOVIE: "2", OVA: "4", SPECIAL: "5", ONA: "7" };
  if (filter.types && types[filter.types]) params.set("types", types[filter.types]);
  const seasons: Record<string, string> = { winter: "1", spring: "2", summer: "3", autumn: "4" };
  if (filter.seasons && seasons[filter.seasons]) params.set("season", seasons[filter.seasons]);
  if (filter.status) params.set("status", filter.status === "IS_IN_PRODUCTION" ? "1" : "0");
  const data = list<YummyAnime>(await request<YummyAnime[]>(`/anime?${params}`));
  const hasMore = data.length > limit;
  return { items: data.slice(0, limit).map(normalizeYummy), total: null, pages: page + (hasMore ? 1 : 0), hasMore };
}

export async function getYummyGenres(): Promise<Genre[]> {
  const data = await request<{ genres: { value: number; title: string }[] }>("/anime/genres");
  return list<{ value: number; title: string }>(data.genres).map((genre) => ({ id: genre.value, name: genre.title }));
}

export async function getAlternativeEpisodes(release: Release): Promise<{ episodes: Episode[]; matched: boolean }> {
  if (release.provider === "yummy") return { episodes: release.episodes || [], matched: true };
  const queries = [...new Set([release.name.english, release.name.main].filter((query): query is string => Boolean(query)))];
  let matched: YummyAnime | undefined;
  for (const query of queries.slice(0, 2)) {
    const candidates = list<YummyAnime>(await request<YummyAnime[]>(`/anime?q=${encodeURIComponent(query)}&limit=20`));
    matched = candidates.find((candidate) => {
      if (release.shikimori?.id && candidate.remote_ids?.shikimori_id && candidate.remote_ids.shikimori_id !== release.shikimori.id) return false;
      if (release.mal?.id && candidate.remote_ids?.myanimelist_id && candidate.remote_ids.myanimelist_id !== release.mal.id) return false;
      return (Boolean(release.alias) && candidate.remote_ids?.anilibria_alias === release.alias)
      || (Boolean(release.shikimori?.id) && candidate.remote_ids?.shikimori_id === release.shikimori?.id)
      || (Boolean(release.mal?.id) && candidate.remote_ids?.myanimelist_id === release.mal?.id);
    });
    if (matched) break;
  }
  if (!matched) return { episodes: release.episodes || [], matched: false };
  const videos = list<YummyVideo>(await request<YummyVideo[]>(`/anime/${matched.anime_id}/videos`));
  const extra = groupYummyEpisodes(videos, normalizeYummy(matched));
  const episodes = (release.episodes || []).map((episode) => {
    const sources = extra.find((item) => item.ordinal === episode.ordinal)?.sources;
    return sources?.length ? { ...episode, sources } : episode;
  });
  for (const item of extra) if (!episodes.some((episode) => episode.ordinal === item.ordinal)) episodes.push({ ...item, sources: item.sources || [] });
  return { episodes: episodes.sort((a, b) => a.ordinal - b.ordinal), matched: true };
}

export async function testYummyConnection() {
  const data = await request<YummyAnime[]>("/anime?limit=1", true);
  if (!Array.isArray(data)) throw new Error("Неверный ответ каталога.");
  return data.length;
}