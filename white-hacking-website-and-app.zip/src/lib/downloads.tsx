import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { downloadEpisode, downloadFilename, type DownloadProgress, type SaveHandle } from "./download";
import { beginDownload, endDownload } from "./mediaCoordinator";

export type DownloadRequest = { url: string; quality: string; name: string; episode: number; poster: string; voiceName?: string };
export type DownloadJob = DownloadRequest & DownloadProgress & {
  id: string; status: "loading" | "ready" | "saved" | "error" | "cancelled";
  filename: string; blobUrl?: string; error?: string;
};
type DownloadsContextValue = {
  jobs: DownloadJob[]; start: (request: DownloadRequest) => void;
  cancel: (id: string) => void; remove: (id: string) => void; markSaved: (id: string) => void;
  notice: string; dismissNotice: () => void;
};
const DownloadsContext = createContext<DownloadsContextValue | null>(null);

export function DownloadsProvider({ children }: { children: ReactNode }) {
  const [jobs, setJobs] = useState<DownloadJob[]>([]);
  const [notice, setNotice] = useState("");
  const controllers = useRef(new Map<string, AbortController>());
  const urls = useRef(new Map<string, string>());
  const diskCleanup = useRef(new Map<string, () => Promise<void>>());
  const busy = useRef(false);
  const mounted = useRef(true);

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
      controllers.current.forEach((c) => c.abort());
      urls.current.forEach((url) => URL.revokeObjectURL(url));
      diskCleanup.current.forEach((cleanup) => { void cleanup(); });
    };
  }, []);

  useEffect(() => {
    const beforeLeave = (event: BeforeUnloadEvent) => {
      if (busy.current || jobs.some((j) => j.status === "ready")) {
        event.preventDefault();
        event.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", beforeLeave);
    return () => window.removeEventListener("beforeunload", beforeLeave);
  }, [jobs]);

  const patch = useCallback((id: string, changes: Partial<DownloadJob>) => {
    if (mounted.current) setJobs((old) => old.map((job) => job.id === id ? { ...job, ...changes } : job));
  }, []);

  const start = useCallback((request: DownloadRequest) => {
    if (busy.current) { setNotice("Дождитесь текущей загрузки или отмените её в разделе «Загрузки»."); return; }
    if (urls.current.size >= 2) { setNotice("Сохраните готовые файлы и удалите их из списка, чтобы освободить память."); return; }
    busy.current = true;
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const controller = new AbortController();
    controllers.current.set(id, controller);
    const filename = downloadFilename(`${request.name}${request.voiceName ? ` - ${request.voiceName}` : ""}`, request.episode, request.quality);
    setJobs((old) => [{ ...request, id, filename, status: "loading", completed: 0, total: 0, bytes: 0, speed: 0 }, ...old]);
    setNotice("Скачивание началось. Прогресс доступен в разделе «Загрузки».");
    const picker = (window as Window & {
      showSaveFilePicker?: (options: { suggestedName: string; types: { description: string; accept: Record<string, string[]> }[] }) => Promise<SaveHandle>;
    }).showSaveFilePicker;
    // Invoke the picker during the user gesture, before any network await.
    let handlePromise: Promise<SaveHandle | undefined>;
    try {
      handlePromise = picker
        ? picker.call(window, { suggestedName: filename, types: [{ description: "MP4 видео", accept: { "video/mp4": [".mp4"] } }] })
        : Promise.resolve(undefined);
    } catch { handlePromise = Promise.resolve(undefined); }

    void (async () => {
      let ownsTransfer = false;
      try {
        let handle: SaveHandle | undefined;
        try { handle = await handlePromise; }
        catch (error) {
          if (error instanceof DOMException && error.name === "AbortError") throw error;
          // Embedded browsers may expose the API but deny its use.
        }
        if (controller.signal.aborted) throw new DOMException("Отменено", "AbortError");
        await beginDownload();
        ownsTransfer = true;
        const result = await downloadEpisode(request.url, Number(request.quality), controller.signal, (progress) => patch(id, progress), handle);
        if (!mounted.current) { await result.cleanup?.(); return; }
        if (result.blob) {
          const blobUrl = URL.createObjectURL(result.blob);
          urls.current.set(id, blobUrl);
          if (result.cleanup) diskCleanup.current.set(id, result.cleanup);
          patch(id, { status: "ready", blobUrl, bytes: result.bytes });
          setNotice("Серия готова. Нажмите «Сохранить файл» в загрузках.");
        } else {
          patch(id, { status: "saved", bytes: result.bytes });
          setNotice("Серия сохранена на устройство.");
        }
      } catch (error) {
        controller.abort();
        const aborted = error instanceof DOMException && error.name === "AbortError";
        patch(id, { status: aborted ? "cancelled" : "error", error: aborted ? undefined : error instanceof Error ? error.message : "Не удалось скачать серию." });
        if (mounted.current && !aborted) setNotice("Загрузка прервана. Подробности в разделе «Загрузки».");
      } finally {
        if (ownsTransfer) endDownload();
        controllers.current.delete(id);
        busy.current = false;
      }
    })();
  }, [patch]);

  const dismissNotice = useCallback(() => setNotice(""), []);
  const cancel = (id: string) => controllers.current.get(id)?.abort();
  const remove = (id: string) => {
    controllers.current.get(id)?.abort();
    const url = urls.current.get(id);
    if (url) URL.revokeObjectURL(url);
    urls.current.delete(id);
    void diskCleanup.current.get(id)?.();
    diskCleanup.current.delete(id);
    setJobs((old) => old.filter((j) => j.id !== id));
  };

  return <DownloadsContext.Provider value={{ jobs, start, cancel, remove, markSaved: (id) => patch(id, { status: "saved" }), notice, dismissNotice }}>{children}</DownloadsContext.Provider>;
}

export function useDownloads() {
  const context = useContext(DownloadsContext);
  if (!context) throw new Error("DownloadsProvider is required");
  return context;
}