export const PRIMARY_VOICE = "primary";

export function voiceIdentity(label: string): { id: string; name: string } {
  const subtitle = /субтитр|subtitles?/iu.test(label);
  const name = label.normalize("NFKC").replace(/^(?:озвучка|субтитры)\s*/iu, "").trim() || (subtitle ? "Субтитры" : "Без названия");
  const key = name.toLocaleLowerCase("ru").replace(/[\s._\-()[\]]+/g, "");
  // The renamed studio is one voice; mirrors are never separate choices.
  if (!subtitle && /^(?:anilibria|aniliberty|анилибрия|анилиберти)$/.test(key)) return { id: PRIMARY_VOICE, name: "Основная озвучка" };
  return { id: `voice:${subtitle ? "sub:" : "dub:"}${key}`, name: subtitle && name !== "Субтитры" ? `${name} · субтитры` : name };
}

export function migrateVoice(value?: string | null): string {
  if (typeof value !== "string" || !value || value === PRIMARY_VOICE) return PRIMARY_VOICE;
  if (value.startsWith("voice:")) return value;
  if (value.startsWith("yummy:")) return voiceIdentity(value.split(":").slice(2).join(":")).id;
  return value;
}

export function aksorVideoId(value: string): string | null {
  try {
    const url = new URL(value.startsWith("//") ? `https:${value}` : value);
    if (!/^https?:$/.test(url.protocol) || url.username || url.password) return null;
    if (!["player.aksor.tv", "aksor.yani.tv"].includes(url.hostname)) return null;
    return url.pathname.match(/^\/video\/([a-f0-9]{24,40})\/?$/i)?.[1] ?? null;
  } catch { return null; }
}