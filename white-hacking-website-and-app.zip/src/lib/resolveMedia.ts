import { qualities, refreshEpisode, type Episode, type EpisodeSource, type MediaVariant, type Release, type Skip } from "../api";
import { getGateway, httpsUrl } from "./network";
import { sourcesForVoice } from "./playback";
import { migrateVoice, PRIMARY_VOICE } from "./voices";
import { interceptAlloha, interceptCvh, interceptSibnet } from "../../shared/intercept.js";
import { proxyFetcher } from "./proxyFetch";

export type ResolvedMedia = {
  variants: MediaVariant[];
  sourceId: string;
  voiceId: string;
  opening?: Skip | null;
  ending?: Skip | null;
  /** Player origin/referer some CDNs demand — forwarded by our media proxy. */
  proxy?: { origin: string; referer: string };
};

const cache = new Map<string, { value: ResolvedMedia; expires: number }>();

function abortCheck(signal: AbortSignal) {
  if (signal.aborted) throw new DOMException("Отменено", "AbortError");
}

function primary(episode: Episode): ResolvedMedia {
  return { sourceId: `primary:${episode.id}`, voiceId: PRIMARY_VOICE,
    variants: qualities(episode).map((quality) => ({ quality, kind: "hls", url: episode[`hls_${quality}`]! })),
    opening: episode.opening, ending: episode.ending };
}

type SourceResponse = {
  id?: string; anime_id?: number; episode?: string; qualities?: Record<string, string | null>;
  opening_start?: number; opening_length?: number; ending_start?: number; ending_length?: number;
};

function timing(start?: number, length?: number): Skip | undefined {
  return typeof start === "number" && typeof length === "number" && length > 0 ? { start, stop: start + length } : undefined;
}

/** Sibnet publishes a plain MP4 on its own page — read it, play the file. */
async function resolveSibnet(source: EpisodeSource, signal: AbortSignal, fresh: boolean): Promise<ResolvedMedia> {
  const videoId = source.videoId;
  if (!videoId) throw new Error("У этой озвучки нет доступного видеофайла.");
  const gateway = await getGateway();
  abortCheck(signal);
  return resolveRemote(
    `sibnet:${source.videoId}`,
    gateway?.sibnetResolver ? `/api/kurenai/resolve/sibnet/${source.videoId}` : null,
    async () => {
      const found = await interceptSibnet(proxyFetcher(), videoId);
      return { url: found.url } as InterceptResult & { url: string };
    },
    signal, fresh,
    (data, src) => {
      const raw = (data as unknown as { url?: string }).url;
      const url = httpsUrl(raw);
      const parsed = url ? new URL(url) : null;
      if (!parsed || parsed.protocol !== "https:"
        || !/(^|\.)video\.sibnet\.ru$/i.test(parsed.hostname) || !parsed.pathname.startsWith("/sh/")) {
        throw new Error("Источник вернул недопустимое видео. Воспроизведение отменено.");
      }
      return { variants: [{ quality: "auto", url, kind: "mp4" }], sourceId: src.id, voiceId: src.voiceId,
        opening: src.opening, ending: src.ending };
    },
    source,
  );
}

async function resolveSource(source: EpisodeSource, signal: AbortSignal, fresh: boolean): Promise<ResolvedMedia> {
  const key = `${source.animeId}:${source.id}:${source.episodeLabel}`;
  const cached = cache.get(key);
  if (!fresh && cached && cached.expires > Date.now()) return cached.value;
  abortCheck(signal);
  const gateway = await getGateway();
  abortCheck(signal);
  const endpoint = gateway?.directVoices ? `/api/kurenai/voice/${source.videoId}` : `https://player.aksor.tv/api/video/${source.videoId}`;
  const controller = new AbortController();
  const abort = () => controller.abort();
  signal.addEventListener("abort", abort, { once: true });
  const timeout = window.setTimeout(abort, 14_000);
  try {
    const response = await fetch(endpoint, { signal: controller.signal, headers: { Accept: "application/json" }, credentials: "omit", cache: fresh ? "no-store" : "default" });
    if (!response.ok) throw new Error(response.status === 403 || response.status === 401
      ? "Эта озвучка ограничена для просмотра." : "Не удалось получить видео выбранной озвучки. Повторите попытку позже.");
    const data = await response.json() as SourceResponse;
    abortCheck(signal);
    // Identity comes from catalog metadata, never from fuzzy title guessing.
    const actualEpisode = String(data.episode).trim();
    const wantedEpisode = source.episodeLabel.trim();
    const numeric = /^\d+(?:\.\d+)?$/;
    const sameEpisode = actualEpisode === wantedEpisode || (numeric.test(actualEpisode) && numeric.test(wantedEpisode) && Number(actualEpisode) === Number(wantedEpisode));
    if (data.id !== source.videoId || data.anime_id !== source.animeId || !sameEpisode) {
      throw new Error("Источник вернул другую серию. Воспроизведение отменено.");
    }
    const variants: MediaVariant[] = [];
    for (const quality of ["1080", "720", "480", "360"] as const) {
      const url = httpsUrl(data.qualities?.[`q${quality}`]);
      if (!url) continue;
      const parsed = new URL(url);
      if (parsed.protocol !== "https:" || !/(^|\.)takehost-cdn\.aksor\.tv$/i.test(parsed.hostname) || !/^\/static\d*\/video\//.test(parsed.pathname)) continue;
      const kind = /\.mpd$/i.test(parsed.pathname) ? "dash" : /\.m3u8$/i.test(parsed.pathname) ? "hls" : /\.mp4$/i.test(parsed.pathname) ? "mp4" : null;
      if (kind) variants.push({ quality, url, kind });
    }
    if (!variants.length) throw new Error("Для этой серии пока нет совместимого видео. Выберите другую доступную озвучку.");
    const result: ResolvedMedia = { variants, sourceId: source.id, voiceId: source.voiceId,
      opening: timing(data.opening_start, data.opening_length) || source.opening,
      ending: timing(data.ending_start, data.ending_length) || source.ending };
    cache.set(key, { value: result, expires: Date.now() + 90_000 });
    if (cache.size > 60) cache.delete(cache.keys().next().value!);
    return result;
  } catch (error) {
    abortCheck(signal);
    if (error instanceof DOMException && error.name === "AbortError") throw new Error("Озвучка отвечает слишком долго. Повторите подключение позже.");
    if (error instanceof TypeError) throw new Error("Не удалось подключить выбранную озвучку. Для прямого просмотра может потребоваться серверное подключение сайта.");
    throw error;
  } finally { clearTimeout(timeout); signal.removeEventListener("abort", abort); }
}

type InterceptResult = {
  qualities?: Record<string, string>;
  hls?: string | null;
  dash?: string | null;
  mp4?: Record<string | number, string>;
  translation?: string | null;
  opening?: Skip | null;
  ending?: Skip | null;
  origin?: string;
  referer?: string;
};

async function gatewayJson<T>(path: string, signal: AbortSignal, fresh: boolean): Promise<T> {
  const controller = new AbortController();
  const abort = () => controller.abort();
  signal.addEventListener("abort", abort, { once: true });
  const timeout = window.setTimeout(abort, 20_000);
  try {
    const response = await fetch(path, { signal: controller.signal, headers: { Accept: "application/json" }, credentials: "omit", cache: fresh ? "no-store" : "default" });
    if (response.status === 404) throw new Error("NOT_FOUND");
    if (!response.ok) throw new Error(`HTTP_${response.status}`);
    return (await response.json()) as T;
  } finally {
    clearTimeout(timeout);
    signal.removeEventListener("abort", abort);
  }
}

async function browserSha256hex(text: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function variantsFromMap(map: Record<string, string> | undefined, kind: MediaVariant["kind"] = "hls"): MediaVariant[] {
  const out: MediaVariant[] = [];
  for (const q of ["1080", "720", "480", "360"] as const) {
    const url = httpsUrl(map?.[q] || map?.[`q${q}`]);
    if (url) out.push({ quality: q, url, kind });
  }
  return out;
}

function nearestQuality(n: number): MediaVariant["quality"] {
  return n >= 900 ? "1080" : n >= 600 ? "720" : n >= 400 ? "480" : "360";
}

/**
 * Server first (exact headers, no CORS pain), direct intercept as fallback.
 * Either way exactly ONE metadata chain runs — the video itself streams once.
 */
async function resolveRemote(
  key: string,
  gatewayPath: string | null,
  direct: () => Promise<InterceptResult>,
  signal: AbortSignal,
  fresh: boolean,
  toMedia: (data: InterceptResult, source: EpisodeSource) => ResolvedMedia,
  source: EpisodeSource,
): Promise<ResolvedMedia> {
  const cached = cache.get(key);
  if (!fresh && cached && cached.expires > Date.now()) return cached.value;
  abortCheck(signal);
  let data: InterceptResult | null = null;
  let lastErr: unknown = null;
  if (gatewayPath) {
    try {
      data = await gatewayJson<InterceptResult>(gatewayPath, signal, fresh);
    } catch (e) {
      lastErr = e;
    }
    abortCheck(signal);
  }
  if (!data) {
    try {
      data = await direct();
    } catch (e) {
      lastErr = e;
    }
  }
  if (!data) {
    if (lastErr instanceof DOMException && lastErr.name === "AbortError") throw lastErr;
    throw new Error("Не удалось перехватить поток этой озвучки. Попробуйте другую озвучку.");
  }
  const result = toMedia(data, source);
  if (!result.variants.length) throw new Error("Поток этой озвучки не поддерживается. Выберите другую озвучку.");
  cache.set(key, { value: result, expires: Date.now() + 60_000 });
  if (cache.size > 60) cache.delete(cache.keys().next().value!);
  return result;
}

/** Alloha: iframe → signature → manifest list. Streams play in OUR player. */
async function resolveAlloha(source: EpisodeSource, signal: AbortSignal, fresh: boolean): Promise<ResolvedMedia> {
  const gateway = await getGateway();
  abortCheck(signal);
  return resolveRemote(
    `alloha:${source.url}`,
    gateway?.allohaResolver ? `/api/kurenai/resolve/alloha?url=${encodeURIComponent(source.url)}` : null,
    () => interceptAlloha(proxyFetcher(), source.url, browserSha256hex),
    signal, fresh,
    (data, src) => ({ variants: variantsFromMap(data.qualities), sourceId: src.id, voiceId: src.voiceId,
      proxy: data.origin && data.referer ? { origin: data.origin, referer: data.referer } : undefined,
      opening: src.opening, ending: src.ending }),
    source,
  );
}

/** CVH: open playlist API → episode video → HLS/DASH/MP4. */
async function resolveCvh(source: EpisodeSource, signal: AbortSignal, fresh: boolean): Promise<ResolvedMedia> {
  const gateway = await getGateway();
  abortCheck(signal);
  return resolveRemote(
    `cvh:${source.url}`,
    gateway?.cvhResolver ? `/api/kurenai/resolve/cvh?url=${encodeURIComponent(source.url)}` : null,
    () => interceptCvh(proxyFetcher(), source.url),
    signal, fresh,
    (data, src) => {
      const variants: MediaVariant[] = [];
      const hls = httpsUrl(data.hls);
      const dash = httpsUrl(data.dash);
      if (hls) variants.push({ quality: "auto", url: hls, kind: "hls" });
      if (dash) variants.push({ quality: "auto", url: dash, kind: "dash" });
      for (const [q, url] of Object.entries(data.mp4 || {})) {
        const clean = httpsUrl(url);
        if (clean) variants.push({ quality: nearestQuality(Number(q) || 0), url: clean, kind: "mp4" });
      }
      return { variants, sourceId: src.id, voiceId: src.voiceId, opening: src.opening, ending: src.ending };
    },
    source,
  );
}

export async function resolveEpisodeMedia(release: Release, episode: Episode, voice: string, signal: AbortSignal, fresh = false, useBackup = false): Promise<ResolvedMedia> {
  const voiceId = migrateVoice(voice);
  abortCheck(signal);
  if (!useBackup && voiceId === PRIMARY_VOICE && qualities(episode).length) {
    const selected = fresh ? await refreshEpisode(release, episode.ordinal) : episode;
    abortCheck(signal);
    const media = primary(selected);
    if (!media.variants.length) throw new Error("Для этой озвучки выбранная серия сейчас недоступна.");
    return media;
  }
  const candidates = sourcesForVoice(episode, voiceId);
  if (!candidates.length) throw new Error("В этой озвучке выбранная серия не опубликована.");
  // One metadata request per attempt, in provider priority order. Hidden players
  // are never started; a provider without a direct stream fails explicitly.
  let lastError: unknown = null;
  for (const source of candidates) {
    abortCheck(signal);
    try {
      if (source.provider === "aksor") return await resolveSource(source, signal, fresh);
      if (source.provider === "sibnet") return await resolveSibnet(source, signal, fresh);
      if (source.provider === "alloha") return await resolveAlloha(source, signal, fresh);
      if (source.provider === "cvh") return await resolveCvh(source, signal, fresh);
      throw new Error("У этой озвучки нет перехватываемого потока. Выберите другую озвучку.");
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") throw error;
      lastError = error;
    }
  }
  throw lastError instanceof Error ? lastError : new Error("Не удалось получить видео выбранной озвучки.");
}