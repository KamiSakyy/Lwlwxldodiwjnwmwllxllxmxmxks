export type GatewayStatus = {
  service: string;
  version: number;
  yummyConfigured: boolean;
  mediaProxy: boolean;
  directVoices?: boolean;
  allohaResolver?: boolean;
  cvhResolver?: boolean;
  sibnetResolver?: boolean;
};

export type MediaProxyCtx = { origin?: string; referer?: string };

let gatewayPromise: Promise<GatewayStatus | null> | undefined;

export function getGateway(): Promise<GatewayStatus | null> {
  if (!gatewayPromise) gatewayPromise = (async () => {
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), 1600);
    try {
      const response = await fetch("/api/kurenai/status", { signal: controller.signal, headers: { Accept: "application/json" } });
      if (!response.ok || !response.headers.get("content-type")?.includes("application/json")) return null;
      const data = await response.json();
      return data?.service === "kurenai-gateway" ? data as GatewayStatus : null;
    } catch { return null; }
    finally { clearTimeout(timer); }
  })();
  return gatewayPromise;
}

export function httpsUrl(value?: string | null, base?: string): string {
  if (!value) return "";
  try {
    const url = new URL(value.startsWith("//") ? `https:${value}` : value, base);
    if (!["https:", "http:"].includes(url.protocol)) return "";
    if (url.username || url.password) return "";
    return url.href;
  } catch { return ""; }
}

export async function mediaUrl(url: string, ctx?: MediaProxyCtx): Promise<string> {
  const gateway = await getGateway();
  if (!gateway?.mediaProxy) return url;
  try {
    const parsed = new URL(url);
    const primary = /(^|\.)libria\.fun$/i.test(parsed.hostname) && parsed.pathname.startsWith("/videos/");
    const additional = gateway.directVoices && /(^|\.)takehost-cdn\.aksor\.tv$/i.test(parsed.hostname) && /^\/static\d*\/video\//.test(parsed.pathname);
    const sibnet = gateway.directVoices && /(^|\.)video\.sibnet\.ru$/i.test(parsed.hostname) && parsed.pathname.startsWith("/sh/");
    const okcdn = gateway.cvhResolver && /(^|\.)okcdn\.ru$/i.test(parsed.hostname);
    const alloha = gateway.allohaResolver && /(^|\.)(vkvideo\.cloud|stloadi\.live)$/i.test(parsed.hostname);
    if (parsed.protocol === "https:" && (primary || additional || sibnet || okcdn || alloha)) {
      let out = `/api/kurenai/media?url=${encodeURIComponent(url)}`;
      // Alloha edges demand the player Origin/Referer or answer 403.
      if (alloha && ctx?.origin && ctx?.referer) {
        out += `&origin=${encodeURIComponent(ctx.origin)}&referer=${encodeURIComponent(ctx.referer)}`;
      }
      return out;
    }
  } catch { /* The player will explain an invalid or absent stream. */ }
  return url;
}

export function getApplicationToken(): string {
  try { return sessionStorage.getItem("kurenai.yummy.application") || ""; } catch { return ""; }
}

export function setApplicationToken(value: string) {
  try {
    if (value.trim()) sessionStorage.setItem("kurenai.yummy.application", value.trim());
    else sessionStorage.removeItem("kurenai.yummy.application");
  } catch { throw new Error("Браузер не разрешает сохранить настройки сеанса."); }
  window.dispatchEvent(new Event("kurenai:connections"));
}
