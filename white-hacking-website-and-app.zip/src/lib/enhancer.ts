export type EnhanceMode = "off" | "balanced" | "quality";

export type EnhanceOptions = {
  mode: EnhanceMode;
  sharpness: number;
  denoise: number;
  compare: boolean;
  split: number;
};

export type EnhanceStats = {
  sourceWidth: number;
  sourceHeight: number;
  width: number;
  height: number;
  fps: number;
  frames: number;
};

const vertex = `
attribute vec2 aPosition;
#ifdef GL_FRAGMENT_PRECISION_HIGH
varying highp vec2 vUv;
#else
varying mediump vec2 vUv;
#endif
void main() {
  vUv = aPosition * 0.5 + 0.5;
  gl_Position = vec4(aPosition, 0.0, 1.0);
}`;

const precision = `
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
varying vec2 vUv;
uniform sampler2D uImage;
uniform vec2 uSize;
`;

// Pass 1: a bilateral filter rejects neighbours across line-art boundaries.
const denoiseShader = precision + `
uniform float uDenoise;
uniform float uVideoFlip;
vec3 readVideo(vec2 uv) {
  return texture2D(uImage, vec2(uv.x, mix(uv.y, 1.0 - uv.y, uVideoFlip))).rgb;
}
void main() {
  vec3 center = readVideo(vUv);
  vec3 sum = vec3(0.0);
  float weights = 0.0;
  for (int y = -1; y <= 1; y++) {
    for (int x = -1; x <= 1; x++) {
      vec2 offset = vec2(float(x), float(y));
      vec3 sampleColor = readVideo(vUv + offset / uSize);
      vec3 difference = sampleColor - center;
      float weight = exp(-dot(offset, offset) * 0.5 - dot(difference, difference) / 0.006);
      sum += sampleColor * weight;
      weights += weight;
    }
  }
  gl_FragColor = vec4(mix(center, sum / max(weights, 0.001), uDenoise), 1.0);
}`;

// Pass 2: true 16-tap Catmull-Rom reconstruction into a larger framebuffer.
const upscaleShader = precision + `
float cubic(float x) {
  x = abs(x);
  if (x < 1.0) return (1.5 * x - 2.5) * x * x + 1.0;
  if (x < 2.0) return ((-0.5 * x + 2.5) * x - 4.0) * x + 2.0;
  return 0.0;
}
void main() {
  vec2 pixel = vUv * uSize - 0.5;
  vec2 base = floor(pixel);
  vec2 fraction = fract(pixel);
  vec3 color = vec3(0.0);
  vec3 low = vec3(1.0);
  vec3 high = vec3(0.0);
  for (int y = -1; y <= 2; y++) {
    for (int x = -1; x <= 2; x++) {
      vec2 offset = vec2(float(x), float(y));
      vec3 sampleColor = texture2D(uImage, (base + offset + 0.5) / uSize).rgb;
      color += sampleColor * cubic(offset.x - fraction.x) * cubic(offset.y - fraction.y);
      if (x >= 0 && x <= 1 && y >= 0 && y <= 1) {
        low = min(low, sampleColor);
        high = max(high, sampleColor);
      }
    }
  }
  // Local bounds suppress ringing around high-contrast ink lines.
  gl_FragColor = vec4(clamp(color, low, high), 1.0);
}`;

// Pass 3: edge-adaptive luma reconstruction, with an unprocessed A/B view.
const finishShader = precision + `
uniform sampler2D uOriginal;
uniform float uSharpness;
uniform float uCompare;
uniform float uSplit;
uniform float uVideoFlip;
float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
void main() {
  vec3 center = texture2D(uImage, vUv).rgb;
  vec3 n = texture2D(uImage, vUv + vec2(0.0, 1.0) / uSize).rgb;
  vec3 s = texture2D(uImage, vUv - vec2(0.0, 1.0) / uSize).rgb;
  vec3 e = texture2D(uImage, vUv + vec2(1.0, 0.0) / uSize).rgb;
  vec3 w = texture2D(uImage, vUv - vec2(1.0, 0.0) / uSize).rgb;
  float low = min(luma(center), min(min(luma(n), luma(s)), min(luma(e), luma(w))));
  float high = max(luma(center), max(max(luma(n), luma(s)), max(luma(e), luma(w))));
  float contrast = high - low;
  float detail = luma(center) - (luma(n) + luma(s) + luma(e) + luma(w)) * 0.25;
  float gain = smoothstep(0.006, 0.07, contrast) * (1.0 - smoothstep(0.4, 0.95, contrast));
  float restored = clamp(luma(center) + detail * uSharpness * gain * 1.8, low, high);
  vec3 color = clamp(center + vec3(restored - luma(center)), 0.0, 1.0);
  if (uCompare > 0.5 && vUv.x < uSplit) color = texture2D(uOriginal, vec2(vUv.x, mix(vUv.y, 1.0 - vUv.y, uVideoFlip))).rgb;
  gl_FragColor = vec4(color, 1.0);
}`;

const orientationShader = precision + `
void main() { gl_FragColor = texture2D(uImage, vUv); }
`;

type Program = { program: WebGLProgram; uniforms: Record<string, WebGLUniformLocation | null> };
type Target = { texture: WebGLTexture; framebuffer: WebGLFramebuffer };

export class VideoEnhancer {
  private gl: WebGLRenderingContext;
  private programs: Program[] = [];
  private targets: Target[] = [];
  private videoTexture: WebGLTexture | null = null;
  private buffer: WebGLBuffer | null = null;
  private frameId = 0;
  private rafId = 0;
  private destroyed = false;
  private failed = false;
  private sourceWidth = 0;
  private sourceHeight = 0;
  private frames = 0;
  private intervalFrames = 0;
  private lastReport = performance.now();
  private measuredFps = 0;
  private lastTime = -1;
  private slowFrames = 0;
  private configuredMode: EnhanceMode = "off";
  private videoFlip = 1;
  private orientationChecked = false;
  private orientationTarget: Target | null = null;
  private orientationReference = document.createElement("canvas");

  constructor(
    private video: HTMLVideoElement,
    private canvas: HTMLCanvasElement,
    private options: EnhanceOptions,
    private onStats: (stats: EnhanceStats) => void,
    private onError: (message: string) => void,
  ) {
    const gl = canvas.getContext("webgl", {
      alpha: false, antialias: false, depth: false, stencil: false,
      preserveDrawingBuffer: false, powerPreference: "high-performance",
    });
    if (!gl) throw new Error("GPU-обработка недоступна в этом браузере. Оригинальное видео продолжит работать.");
    this.gl = gl;
    try {
      for (const source of [denoiseShader, upscaleShader, finishShader, orientationShader]) this.programs.push(this.compile(source));
      this.buffer = gl.createBuffer();
      if (!this.buffer) throw new Error("Недостаточно памяти GPU.");
      gl.bindBuffer(gl.ARRAY_BUFFER, this.buffer);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
      this.videoTexture = this.texture();
      this.orientationTarget = this.target(8, 8);
      this.orientationReference.width = 8;
      this.orientationReference.height = 8;
      gl.disable(gl.DEPTH_TEST);
      gl.disable(gl.BLEND);
      canvas.addEventListener("webglcontextlost", this.contextLost);
      video.addEventListener("seeked", this.redraw);
      video.addEventListener("loadeddata", this.redraw);
      this.tick();
    } catch (error) {
      this.dispose();
      throw error;
    }
  }

  private compile(source: string): Program {
    const gl = this.gl;
    const shaders: WebGLShader[] = [];
    let program: WebGLProgram | null = null;
    try {
      for (const [kind, code] of [[gl.VERTEX_SHADER, vertex], [gl.FRAGMENT_SHADER, source]] as const) {
        const shader = gl.createShader(kind);
        if (!shader) throw new Error("Не удалось создать GPU-программу.");
        shaders.push(shader);
        gl.shaderSource(shader, code);
        gl.compileShader(shader);
        if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
          throw new Error("Видеоустройство не поддерживает этот шейдер. Включён оригинал.");
        }
      }
      program = gl.createProgram();
      if (!program) throw new Error("Не удалось создать GPU-программу.");
      shaders.forEach((shader) => gl.attachShader(program!, shader));
      gl.bindAttribLocation(program, 0, "aPosition");
      gl.linkProgram(program);
      if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error("Шейдеры несовместимы с GPU.");
      const uniforms: Program["uniforms"] = {};
      for (const key of ["uImage", "uSize", "uDenoise", "uSharpness", "uOriginal", "uCompare", "uSplit", "uVideoFlip"]) {
        uniforms[key] = gl.getUniformLocation(program, key);
      }
      return { program, uniforms };
    } catch (error) {
      if (program) gl.deleteProgram(program);
      throw error;
    } finally {
      shaders.forEach((shader) => gl.deleteShader(shader));
    }
  }

  private texture() {
    const gl = this.gl;
    const texture = gl.createTexture();
    if (!texture) throw new Error("Недостаточно памяти GPU.");
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    return texture;
  }

  private target(width: number, height: number): Target {
    const gl = this.gl;
    const texture = this.texture();
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, width, height, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    const framebuffer = gl.createFramebuffer();
    if (!framebuffer) { gl.deleteTexture(texture); throw new Error("Недостаточно памяти GPU."); }
    gl.bindFramebuffer(gl.FRAMEBUFFER, framebuffer);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, texture, 0);
    if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) {
      gl.deleteFramebuffer(framebuffer);
      gl.deleteTexture(texture);
      throw new Error("GPU не может обработать это разрешение. Попробуйте 720p.");
    }
    return { texture, framebuffer };
  }

  private resize() {
    const gl = this.gl;
    const w = this.video.videoWidth;
    const h = this.video.videoHeight;
    if (w === this.sourceWidth && h === this.sourceHeight && this.configuredMode === this.options.mode) return;
    const highPrecision = Boolean(gl.getShaderPrecisionFormat(gl.FRAGMENT_SHADER, gl.HIGH_FLOAT)?.precision);
    const max = Math.min(gl.getParameter(gl.MAX_TEXTURE_SIZE) as number, highPrecision ? 8192 : 1920);
    const memory = (navigator as Navigator & { deviceMemory?: number }).deviceMemory ?? 8;
    const pixels = memory <= 2 ? 3_000_000 : this.options.mode === "quality" ? 8_294_400 : 4_700_000;
    const requested = this.options.mode === "quality" ? 2 : 1.5;
    const scale = Math.min(requested, max / w, max / h, Math.sqrt(pixels / (w * h)));
    if (scale <= 1.01) throw new Error("Для этого разрешения недостаточно памяти GPU. Выберите 720p или оригинал.");
    this.canvas.width = Math.floor(w * scale / 2) * 2;
    this.canvas.height = Math.floor(h * scale / 2) * 2;
    this.targets.forEach((target) => {
      gl.deleteTexture(target.texture);
      gl.deleteFramebuffer(target.framebuffer);
    });
    this.targets = [];
    this.targets.push(this.target(w, h));
    this.targets.push(this.target(this.canvas.width, this.canvas.height));
    this.sourceWidth = w;
    this.sourceHeight = h;
    this.configuredMode = this.options.mode;
  }

  private pass(index: number, image: WebGLTexture, target: WebGLFramebuffer | null, width: number, height: number, sourceW: number, sourceH: number) {
    const gl = this.gl;
    const { program, uniforms: u } = this.programs[index];
    gl.useProgram(program);
    gl.bindFramebuffer(gl.FRAMEBUFFER, target);
    gl.viewport(0, 0, width, height);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buffer);
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, image);
    gl.uniform1i(u.uImage, 0);
    gl.uniform2f(u.uSize, sourceW, sourceH);
    gl.uniform1f(u.uVideoFlip, this.videoFlip);
    if (index === 0) gl.uniform1f(u.uDenoise, this.options.denoise);
    if (index === 2) {
      gl.activeTexture(gl.TEXTURE1);
      gl.bindTexture(gl.TEXTURE_2D, this.videoTexture);
      gl.uniform1i(u.uOriginal, 1);
      gl.uniform1f(u.uSharpness, this.options.sharpness);
      gl.uniform1f(u.uCompare, this.options.compare ? 1 : 0);
      gl.uniform1f(u.uSplit, this.options.split);
    }
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
  }

  private checkVideoOrientation() {
    if (this.orientationChecked || !this.orientationTarget || this.frames % 15 !== 0) return;
    const context = this.orientationReference.getContext("2d", { willReadFrequently: true });
    if (!context) return;
    context.imageSmoothingEnabled = false;
    context.drawImage(this.video, 0, 0, 8, 8);
    const reference = context.getImageData(0, 0, 8, 8).data;
    const actual = new Uint8Array(8 * 8 * 4);
    this.pass(3, this.videoTexture!, this.orientationTarget.framebuffer, 8, 8, this.video.videoWidth, this.video.videoHeight);
    this.gl.readPixels(0, 0, 8, 8, this.gl.RGBA, this.gl.UNSIGNED_BYTE, actual);
    let normal = 0;
    let flipped = 0;
    for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) for (let channel = 0; channel < 3; channel++) {
      const index = (y * 8 + x) * 4 + channel;
      const reverse = ((7 - y) * 8 + x) * 4 + channel;
      normal += Math.abs(reference[index] - actual[index]);
      flipped += Math.abs(reference[index] - actual[reverse]);
    }
    // readPixels is bottom-up; DOM sources are top-down. Calibrate actual
    // decoder behaviour once on a non-symmetric frame, not with CSS transforms.
    if (Math.min(normal, flipped) < 6000 && Math.abs(normal - flipped) > 1000) {
      this.videoFlip = normal < flipped ? 1 : 0;
      this.orientationChecked = true;
    }
  }

  private draw(force = false) {
    const video = this.video;
    if (this.destroyed || this.failed || document.hidden || video.readyState < 2 || !video.videoWidth) return;
    if (!force && this.lastTime === video.currentTime) return;
    const start = performance.now();
    try {
      this.resize();
      const gl = this.gl;
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, this.videoTexture);
      // Only video sampling in pass 1 (and the raw comparison) changes Y.
      // Intermediate framebuffer textures must never be flipped again.
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
      gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, video);
      this.checkVideoOrientation();
      const [clean, upscaled] = this.targets;
      const { width, height } = this.canvas;
      this.pass(0, this.videoTexture!, clean.framebuffer, this.sourceWidth, this.sourceHeight, this.sourceWidth, this.sourceHeight);
      this.pass(1, clean.texture, upscaled.framebuffer, width, height, this.sourceWidth, this.sourceHeight);
      this.pass(2, upscaled.texture, null, width, height, width, height);
      if (this.frames % 90 === 0 && gl.getError() !== gl.NO_ERROR) throw new Error("Ошибка GPU при обработке видео. Показан оригинал.");
      if (this.lastTime !== video.currentTime) this.intervalFrames++;
      this.lastTime = video.currentTime;
      this.frames++;
      const now = performance.now();
      this.slowFrames = now - start > 40 ? this.slowFrames + 1 : Math.max(0, this.slowFrames - 1);
      if (this.slowFrames > 35) throw new Error("Обработка слишком тяжёлая для устройства. Включён оригинал; попробуйте режим «Баланс».");
      const reportDue = now - this.lastReport > 1000;
      if (reportDue) {
        this.measuredFps = Math.round(this.intervalFrames * 1000 / (now - this.lastReport));
        this.intervalFrames = 0;
        this.lastReport = now;
      }
      if (this.frames === 1 || reportDue || force) {
        this.onStats({ sourceWidth: this.sourceWidth, sourceHeight: this.sourceHeight, width, height,
          fps: video.paused ? 0 : this.measuredFps, frames: this.frames });
      }
    } catch (error) {
      this.failed = true;
      this.onError(error instanceof DOMException && error.name === "SecurityError"
        ? "Браузер запретил обработку этого видео. Просмотр продолжится без апскейла."
        : error instanceof Error ? error.message : "Обработка GPU недоступна.");
    }
  }

  private tick = () => {
    if (this.destroyed || this.failed) return;
    this.draw();
    if (typeof this.video.requestVideoFrameCallback === "function") {
      this.frameId = this.video.requestVideoFrameCallback(this.tick);
    } else {
      this.rafId = requestAnimationFrame(this.tick);
    }
  };

  private redraw = () => this.draw(true);
  private contextLost = (event: Event) => {
    event.preventDefault();
    this.failed = true;
    this.onError("GPU был приостановлен системой. Просмотр продолжится в оригинале.");
  };

  update(options: EnhanceOptions) {
    this.options = options;
    this.draw(true);
  }

  dispose() {
    this.destroyed = true;
    cancelAnimationFrame(this.rafId);
    if (this.frameId && this.video.cancelVideoFrameCallback) this.video.cancelVideoFrameCallback(this.frameId);
    this.video.removeEventListener("seeked", this.redraw);
    this.video.removeEventListener("loadeddata", this.redraw);
    this.canvas.removeEventListener("webglcontextlost", this.contextLost);
    const gl = this.gl;
    this.programs.forEach((p) => gl.deleteProgram(p.program));
    this.targets.forEach((t) => { gl.deleteTexture(t.texture); gl.deleteFramebuffer(t.framebuffer); });
    if (this.orientationTarget) { gl.deleteTexture(this.orientationTarget.texture); gl.deleteFramebuffer(this.orientationTarget.framebuffer); }
    gl.deleteTexture(this.videoTexture);
    gl.deleteBuffer(this.buffer);
  }
}