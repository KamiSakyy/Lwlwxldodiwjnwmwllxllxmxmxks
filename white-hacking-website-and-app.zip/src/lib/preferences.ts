import type { EnhanceOptions } from "./enhancer";

export const defaultEnhance: EnhanceOptions = {
  mode: "off", sharpness: 0.45, denoise: 0.3, compare: false, split: 0.5,
};

export function readPreference<T>(key: string, fallback: T): T {
  try {
    const value = localStorage.getItem(`kurenai.${key}`);
    return value ? JSON.parse(value) as T : fallback;
  } catch { return fallback; }
}

export function savePreference(key: string, value: unknown) {
  try { localStorage.setItem(`kurenai.${key}`, JSON.stringify(value)); } catch { /* Storage can be disabled. */ }
}

export function readEnhance(): EnhanceOptions {
  const saved = readPreference<Partial<EnhanceOptions>>("enhance", {});
  return {
    ...defaultEnhance,
    mode: saved?.mode === "quality" || saved?.mode === "balanced" ? saved.mode : "off",
    sharpness: typeof saved?.sharpness === "number" ? Math.max(0, Math.min(1, saved.sharpness)) : 0.45,
    denoise: typeof saved?.denoise === "number" ? Math.max(0, Math.min(1, saved.denoise)) : 0.3,
  };
}