import type { Episode, EpisodeSource, SourceProvider } from "../api";
import { episodesForVoice, voiceChoices } from "./playback";
import { aksorVideoId, migrateVoice, voiceIdentity } from "./voices";

export function checkVoiceLibrary(): string {
  const assert = (condition: boolean, message: string) => { if (!condition) throw new Error(message); };
  const alpha = voiceIdentity("Озвучка Studio A");
  const beta = voiceIdentity("Озвучка Studio B");
  const gamma = voiceIdentity("Озвучка Studio C");
  const source = (id: string, voice: typeof alpha, ordinal: number, provider: SourceProvider = "aksor", url = `https://player.aksor.tv/video/${"a".repeat(32)}`): EpisodeSource => ({
    id, voiceId: voice.id, name: voice.name, provider, url,
    videoId: provider === "aksor" ? "a".repeat(32) : provider === "sibnet" ? "700000" : url,
    animeId: 1, episodeLabel: String(ordinal), duration: 1200,
  });
  const allohaRef = "https://alloha.yani.tv/?token=a&token_movie=b&translation=4&season=1&episode=4";
  const episodes: Episode[] = [
    { id: "one", ordinal: 1, hls_720: "https://example.invalid/one.m3u8", sources: [source("a1", alpha, 1), source("mirror-a1", alpha, 1), source("b1", beta, 1)] },
    { id: "two", ordinal: 2, sources: [source("a2", alpha, 2)] },
    { id: "three", ordinal: 3, sources: [source("b3", beta, 3)] },
    // Studio C publishes this episode only through an intercepted player.
    { id: "four", ordinal: 4, sources: [source("c4", gamma, 4, "alloha", allohaRef)] },
    { id: "unpublished", ordinal: 5, sources: [] },
  ];
  const choices = voiceChoices(episodes);
  assert(choices.length === 4, "Озвучки каталога потерялись или дублируются.");
  assert(choices.some((voice) => voice.id === gamma.id && voice.count === 1), "Озвучка с перехватом исчезла из списка.");
  assert(choices.find((voice) => voice.id === alpha.id)?.count === 2, "Неверный счётчик первой озвучки.");
  assert(choices.find((voice) => voice.id === beta.id)?.count === 2, "Неверный счётчик второй озвучки.");
  assert(episodesForVoice(episodes, alpha.id).map((item) => item.ordinal).join(",") === "1,2", "Галерея содержит чужие серии.");
  const betaEpisodes = episodesForVoice(episodes, beta.id);
  assert(betaEpisodes[1].ordinal === 3, "Автопереход не учитывает пропуски выбранной озвучки.");
  assert(episodesForVoice(episodes, "primary").length === 1, "В основной озвучке появились отсутствующие видео.");
  assert(voiceChoices([{ id: "empty", ordinal: 1 }]).length === 0, "Пустая озвучка показана как доступная.");
  assert(voiceIdentity("Озвучка AniLibria").id === voiceIdentity("AniLiberty").id, "Дубли переименованной студии.");
  assert(voiceIdentity("Субтитры Studio A").id !== alpha.id, "Озвучка смешалась с субтитрами.");
  assert(migrateVoice("yummy:4:Озвучка Studio A") === alpha.id, "Старые ссылки не мигрируют.");
  assert(aksorVideoId("https://not-player.example/video/" + "a".repeat(32)) === null, "Принят неподдерживаемый адрес.");
  assert(episodesForVoice([...episodes, episodes[0]], alpha.id).length === 2, "Дубликаты серий увеличили счётчик.");
  assert(episodesForVoice(episodes, alpha.id)[0].sources?.[0]?.provider === "aksor", "Приоритет прямых источников нарушен.");
  assert(source("x", gamma, 4, "alloha", allohaRef).provider === "alloha", "Источник Alloha потерялся.");
  assert(new URL(allohaRef).searchParams.get("episode") === "4", "Номер серии Alloha потерялся.");
  return "15 проверок: озвучки, счётчики серий, автопереход, приоритет перехвата и миграция ссылок. Видеоданные не загружались.";
}
