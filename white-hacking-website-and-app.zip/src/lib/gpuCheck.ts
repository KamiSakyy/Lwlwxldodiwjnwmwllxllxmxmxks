import { VideoEnhancer } from "./enhancer";

export async function checkGpuOrientation(): Promise<string> {
  const input = document.createElement("canvas");
  input.width = 96; input.height = 64;
  const context = input.getContext("2d");
  if (!context || typeof input.captureStream !== "function") throw new Error("Этот браузер не поддерживает тестовый видеопоток. Проверьте ориентацию на обычной серии.");
  context.fillStyle = "#f02020"; context.fillRect(0, 0, 96, 32);
  context.fillStyle = "#2040f0"; context.fillRect(0, 32, 96, 32);
  const stream = input.captureStream(5);
  const video = document.createElement("video");
  video.muted = true; video.playsInline = true; video.srcObject = stream;
  video.style.cssText = "position:fixed;left:-9999px;width:96px;height:64px;pointer-events:none";
  document.body.appendChild(video);
  const output = document.createElement("canvas");
  let engine: VideoEnhancer | null = null;
  try {
    return await new Promise<string>((resolve, reject) => {
      let settled = false;
      const finish = (error?: Error, result?: string) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        error ? reject(error) : resolve(result!);
      };
      const timer = window.setTimeout(() => finish(new Error("Проверка не завершилась. GPU или тестовое видео недоступны в этом браузере.")), 7000);
      const start = () => {
        if (settled || engine || !video.videoWidth || video.readyState < 2) return;
        try {
          engine = new VideoEnhancer(video, output, { mode: "quality", denoise: 0, sharpness: 0, compare: false, split: .5 }, (stats) => {
            const gl = output.getContext("webgl");
            if (!gl) return;
            const top = new Uint8Array(4); const bottom = new Uint8Array(4);
            gl.bindFramebuffer(gl.FRAMEBUFFER, null);
            gl.readPixels(Math.floor(stats.width / 2), stats.height - 6, 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, top);
            gl.readPixels(Math.floor(stats.width / 2), 5, 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, bottom);
            const upright = top[0] > top[2] + 80 && bottom[2] > bottom[0] + 80;
            if (stats.width !== 192 || stats.height !== 128) finish(new Error("GPU ограничил разрешение тестового кадра."));
            else if (upright) finish(undefined, "3 прохода GPU: верх и низ совпадают с оригиналом. Апскейл 96×64 → 192×128 подтверждён на этом устройстве.");
            else finish(new Error("Ориентация не совпала с оригиналом. Отключите Enhance и сообщите модель устройства и браузер."));
          }, (message) => finish(new Error(message)));
        } catch (error) { finish(error instanceof Error ? error : new Error("GPU недоступен.")); }
      };
      video.addEventListener("loadeddata", start, { once: true });
      video.addEventListener("playing", start, { once: true });
      void video.play().then(start).catch(() => finish(new Error("Браузер не разрешил запустить тестовое видео.")));
    });
  } finally {
    (engine as VideoEnhancer | null)?.dispose();
    video.pause(); video.srcObject = null; video.remove();
    stream.getTracks().forEach((track) => track.stop());
  }
}