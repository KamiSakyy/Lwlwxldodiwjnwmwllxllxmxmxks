import { useEffect, useState } from "react";
import type { Episode, Release } from "../api";
import { getAlternativeEpisodes } from "./yummy";

const EMPTY_EPISODES: Episode[] = [];

export function useReleaseEpisodes(release: Release | null) {
  const [extra, setExtra] = useState<{ id: number; episodes: Episode[] } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [retry, setRetry] = useState(0);
  useEffect(() => {
    let live = true;
    setError("");
    if (!release || release.provider === "yummy" || release.is_blocked_by_geo || release.is_blocked_by_copyrights) { setLoading(false); return; }
    setLoading(true);
    getAlternativeEpisodes(release).then((data) => { if (live) setExtra({ id: release.id, episodes: data.episodes }); })
      .catch((error) => { if (live) setError(error instanceof Error ? error.message : "Другие озвучки пока недоступны."); })
      .finally(() => { if (live) setLoading(false); });
    return () => { live = false; };
  }, [release, retry]);
  return { episodes: extra && release && extra.id === release.id ? extra.episodes : release?.episodes || EMPTY_EPISODES, loading, error, retry: () => setRetry((count) => count + 1) };
}