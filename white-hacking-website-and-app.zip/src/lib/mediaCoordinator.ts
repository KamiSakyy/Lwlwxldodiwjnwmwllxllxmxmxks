type StopReason = "switch" | "download";
type Owner = { token: symbol; stop: (reason: StopReason) => Promise<void>; local: boolean };
let owner: Owner | null = null;
let transition = Promise.resolve();
let downloading = false;

export const isDownloadActive = () => downloading;

export async function acquirePlayback(stop: Owner["stop"], signal: AbortSignal, local = false): Promise<() => void> {
  const token = Symbol("playback");
  const task = transition.then(async () => {
    if (signal.aborted) throw new DOMException("Cancelled", "AbortError");
    if (downloading && !local) throw new Error("Идёт скачивание. Дождитесь завершения или отмените его в загрузках.");
    const previous = owner;
    owner = null;
    if (previous) await previous.stop("switch");
    if (signal.aborted) throw new DOMException("Cancelled", "AbortError");
    if (downloading && !local) throw new Error("Идёт скачивание. Просмотр можно продолжить после него.");
    owner = { token, stop, local };
  });
  transition = task.catch(() => undefined);
  await task;
  return () => { if (owner?.token === token) owner = null; };
}

export async function beginDownload() {
  if (downloading) throw new Error("Другая загрузка уже выполняется.");
  downloading = true;
  window.dispatchEvent(new Event("kurenai:transfer"));
  try {
    await transition;
    if (owner && !owner.local) {
      const current = owner; owner = null;
      await current.stop("download");
    }
  } catch (error) { endDownload(); throw error; }
}

export function endDownload() {
  downloading = false;
  window.dispatchEvent(new Event("kurenai:transfer"));
}