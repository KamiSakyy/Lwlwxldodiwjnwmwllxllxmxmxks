import Hls, { type HlsConfig } from "hls.js";
import shaka from "shaka-player";
import type { MediaVariant, VideoQuality } from "../api";
import type { ResolvedMedia } from "./resolveMedia";
import { acquirePlayback, isDownloadActive } from "./mediaCoordinator";
import { mediaUrl } from "./network";

export type PlaybackStatus = "resolving" | "loading" | "ready" | "playing" | "paused" | "buffering" | "offline" | "error" | "download" | "ended";
export type PlaybackState = {
  status: PlaybackStatus; time: number; duration: number; buffered: number;
  playing: boolean; ready: boolean; error: string; code: string;
  media: ResolvedMedia | null; variant: MediaVariant | null; receivedBytes: number;
};
export const emptyPlayback: PlaybackState = { status: "resolving", time: 0, duration: 0, buffered: 0, playing: false, ready: false, error: "", code: "", media: null, variant: null, receivedBytes: 0 };

type Options = {
  resolve: (signal: AbortSignal) => Promise<ResolvedMedia>;
  quality: VideoQuality; initialTime: number; autoplay: boolean; volume: number; speed: number; local?: boolean;
  update: (state: PlaybackState) => void;
  save: (time: number, duration: number) => void;
  ended: () => void;
};

const loadPolicy = (retries: number, timeout = 40_000): HlsConfig["fragLoadPolicy"] => ({ default: {
  maxTimeToFirstByteMs: 15_000, maxLoadTimeMs: timeout,
  timeoutRetry: { maxNumRetry: retries, retryDelayMs: 1200, maxRetryDelayMs: 5000 },
  errorRetry: { maxNumRetry: retries, retryDelayMs: 1200, maxRetryDelayMs: 5000, backoff: "exponential" },
} });

export class SingleMediaSession {
  private aborter = new AbortController();
  private disposed = false;
  private stopPromise: Promise<void> | null = null;
  private hls: Hls | null = null;
  private dash: shaka.Player | null = null;
  private releaseLease: (() => void) | undefined;
  private bound = false;
  private state: PlaybackState = { ...emptyPlayback };
  private events: [string, EventListener][] = [];
  private monitor = 0;
  private desiredPlay: boolean;
  private started = false;
  private positionApplied = false;
  private lastSaved = 0;
  private lastActivity = Date.now();
  private lastTime = -1;
  private networkRecovery = 0;
  private mediaRecovery = 0;
  private recoveringMedia = false;
  private terminal = false;
  private retryTimer = 0;
  private nativeRetried = false;
  private loadingStopped = false;
  private hasManifest = false;
  private loadedUrl = "";

  constructor(private video: HTMLVideoElement, private options: Options) {
    this.desiredPlay = options.autoplay;
  }

  private patch(update: Partial<PlaybackState>) {
    if (this.disposed) return;
    this.state = { ...this.state, ...update };
    this.options.update(this.state);
  }

  private check() {
    if (this.disposed || this.aborter.signal.aborted) throw new DOMException("Cancelled", "AbortError");
  }

  async start() {
    try {
      this.releaseLease = await acquirePlayback((reason) => this.stop(reason), this.aborter.signal, this.options.local);
      this.check();
      this.patch({ status: "resolving" });
      const media = await this.options.resolve(this.aborter.signal);
      this.check();
      const variant = media.variants.find((item) => item.quality === this.options.quality)
        || media.variants.find((item) => item.quality === "720") || media.variants[0];
      if (!variant) throw new Error("Для этой серии не найдено доступное видео.");
      const url = await mediaUrl(variant.url, media.proxy);
      this.check();
      this.patch({ media, variant, status: "loading" });
      this.bind();
      this.video.volume = this.options.volume;
      this.video.defaultPlaybackRate = this.options.speed;
      this.video.playbackRate = this.options.speed;
      this.video.crossOrigin = "anonymous";
      this.video.preload = "metadata";
      this.lastActivity = Date.now();
      this.monitor = window.setInterval(this.monitorProgress, 2000);
      if (this.options.local || variant.kind === "mp4") {
        this.video.src = url;
        this.video.load();
      } else if (variant.kind === "dash") {
        await this.startDash(url);
      } else if (Hls.isSupported()) {
        this.startHls(url);
      } else if (this.video.canPlayType("application/vnd.apple.mpegurl")) {
        this.video.src = url;
        this.video.load();
      } else throw new Error("Этот браузер не поддерживает формат видео. Попробуйте актуальный браузер.");
    } catch (error) {
      if (this.disposed || (error instanceof DOMException && error.name === "AbortError")) {
        await this.stop();
        this.releaseLease?.();
        return;
      }
      this.fail(error instanceof Error ? error.message : "Не удалось начать просмотр.", "START");
    }
  }

  private startHls(url: string) {
    this.loadedUrl = url;
    const hls = new Hls({
      enableWorker: false, autoStartLoad: false, startPosition: this.options.initialTime || 0,
      maxBufferLength: 24, maxMaxBufferLength: 36, backBufferLength: 18, maxBufferSize: 24 * 1024 * 1024,
      startFragPrefetch: false, testBandwidth: false, lowLatencyMode: false,
      manifestLoadPolicy: loadPolicy(1, 25_000), playlistLoadPolicy: loadPolicy(2, 30_000), fragLoadPolicy: loadPolicy(2, 180_000),
      keyLoadPolicy: loadPolicy(1, 25_000), preserveManualLevelOnError: true,
    });
    this.hls = hls;
    let manifestRequested = false;
    let initialLoadStarted = false;
    hls.on(Hls.Events.MEDIA_ATTACHED, () => {
      if (!this.disposed && !manifestRequested) { manifestRequested = true; hls.loadSource(url); }
    });
    hls.on(Hls.Events.MANIFEST_PARSED, () => {
      if (this.disposed) return;
      this.hasManifest = true;
      this.lastActivity = Date.now();
      if (!initialLoadStarted) { initialLoadStarted = true; hls.startLoad(this.options.initialTime || 0); }
    });
    hls.on(Hls.Events.FRAG_LOADED, (_, data) => {
      this.lastActivity = Date.now();
      this.patch({ receivedBytes: this.state.receivedBytes + (data.frag.stats.loaded || 0) });
    });
    hls.on(Hls.Events.ERROR, (_, data) => {
      if (!data.fatal || this.disposed || this.terminal) return;
      const status = data.response?.code;
      if (!navigator.onLine) { hls.stopLoad(); this.loadingStopped = true; this.patch({ status: "offline", error: "Нет интернета. Продолжим после восстановления связи." }); return; }
      if (!this.desiredPlay && this.state.ready && data.type === Hls.ErrorTypes.NETWORK_ERROR) {
        hls.stopLoad(); this.loadingStopped = true; this.patch({ status: "paused", playing: false }); return;
      }
      if (data.type === Hls.ErrorTypes.MEDIA_ERROR && this.video.error?.code === 3 && this.mediaRecovery < 1) {
        this.mediaRecovery++; this.recoveringMedia = true;
        this.patch({ status: "buffering" }); hls.recoverMediaError(); return;
      }
      if (data.type === Hls.ErrorTypes.NETWORK_ERROR && this.state.ready && ![401, 403, 404].includes(status || 0) && this.networkRecovery < 1) {
        this.networkRecovery++;
        this.patch({ status: "buffering" });
        this.retryTimer = window.setTimeout(() => { if (!this.disposed && !this.terminal) hls.startLoad(this.video.currentTime, true); }, 1800);
        return;
      }
      this.fail(status === 401 || status === 403 ? "Серия сейчас недоступна для просмотра. Попробуйте другую озвучку."
        : "Не удалось продолжить загрузку серии. Позиция сохранена; можно повторить подключение.", `VIDEO_${status || data.details}`);
    });
    hls.attachMedia(this.video);
  }

  private async startDash(url: string) {
    shaka.polyfill.installAll();
    if (!shaka.Player.isBrowserSupported()) throw new Error("Браузер не поддерживает формат этой озвучки.");
    const dash = new shaka.Player();
    this.dash = dash;
    const retryParameters = { maxAttempts: 3, baseDelay: 1000, backoffFactor: 2, fuzzFactor: .4, timeout: 180_000, stallTimeout: 15_000, connectionTimeout: 12_000 };
    dash.configure({
      abr: { enabled: false },
      streaming: { bufferingGoal: 24, rebufferingGoal: 2, bufferBehind: 18, lowLatencyMode: false,
        segmentPrefetchLimit: 0, disableAudioPrefetch: true, disableVideoPrefetch: true, disableTextPrefetch: true,
        stopFetchingOnPause: true, preloadNextUrlWindow: 0, retryParameters, loadTimeout: 180 },
      manifest: { retryParameters: { ...retryParameters, maxAttempts: 2, timeout: 25_000 }, dash: { ignoreMinBufferTime: true } },
    });
    const network = dash.getNetworkingEngine();
    const proxy = this.state.media?.proxy;
    network?.registerRequestFilter(async (_type, request) => {
      this.check();
      request.uris = await Promise.all(request.uris.map(async (uri) => new URL(await mediaUrl(uri, proxy), window.location.href).href));
      this.check();
      request.allowCrossSiteCredentials = false;
    });
    network?.registerResponseFilter((type, response) => {
      this.lastActivity = Date.now();
      if (type === shaka.net.NetworkingEngine.RequestType.SEGMENT) this.patch({ receivedBytes: this.state.receivedBytes + response.data.byteLength });
    });
    dash.addEventListener("error", (event) => {
      if (this.disposed || this.terminal) return;
      const detail = (event as unknown as { detail: { severity: number; code: number } }).detail;
      if (detail?.severity !== 2) return;
      if (!navigator.onLine) { this.patch({ status: "offline", error: "Нет интернета. Продолжим после восстановления связи." }); return; }
      this.fail("Видео этой озвучки не удалось загрузить. Повторите подключение с сохранённого момента.", `VIDEO_${detail.code}`);
    });
    await dash.attach(this.video);
    this.check();
    await dash.load(url, this.options.initialTime || 0, "application/dash+xml");
    this.check();
    this.positionApplied = true;
    this.onReady();
  }

  private bind() {
    this.bound = true;
    this.events = [
      ["loadedmetadata", this.onReady], ["canplay", this.onReady], ["loadeddata", this.onReady],
      ["play", this.onPlay], ["playing", this.onPlaying], ["pause", this.onPause], ["waiting", this.onWaiting],
      ["seeking", this.onWaiting], ["seeked", this.onReady], ["progress", this.onProgress], ["timeupdate", this.onTime],
      ["ended", this.onEnded], ["error", this.onVideoError],
    ];
    this.events.forEach(([name, callback]) => this.video.addEventListener(name, callback));
    window.addEventListener("online", this.onOnline);
    window.addEventListener("offline", this.onOffline);
    window.addEventListener("pagehide", this.save);
  }

  private onReady = () => {
    if (this.disposed || this.terminal || this.video.readyState < 1) return;
    const duration = this.video.duration;
    if (!this.positionApplied && Number.isFinite(duration)) {
      this.positionApplied = true;
      if (this.options.initialTime > 1 && this.options.initialTime < duration - 3 && Math.abs(this.video.currentTime - this.options.initialTime) > 1) this.video.currentTime = this.options.initialTime;
    }
    this.patch({ ready: true, duration: Number.isFinite(duration) ? duration : 0, status: this.video.paused ? "ready" : "playing", error: "" });
    if (!this.started) {
      this.started = true;
      if (this.desiredPlay) this.play(); else this.hls?.pauseBuffering();
    } else if (this.recoveringMedia) {
      this.recoveringMedia = false;
      if (this.desiredPlay) this.play();
    }
  };

  private resumeLoading() {
    if (!this.hls) return;
    if (this.loadingStopped) {
      this.loadingStopped = false;
      if (!this.hasManifest) this.hls.loadSource(this.loadedUrl);
      else this.hls.startLoad(this.video.currentTime, true);
    } else this.hls.resumeBuffering();
  }
  private onPlay = () => { this.desiredPlay = true; this.resumeLoading(); };
  private onPlaying = () => { this.lastActivity = Date.now(); this.patch({ playing: true, status: "playing", error: "", code: "" }); };
  private onPause = () => {
    if (this.disposed || this.terminal || this.recoveringMedia || !this.started || !this.state.ready || this.video.ended) return;
    this.desiredPlay = false; this.hls?.pauseBuffering(); this.save();
    this.patch({ playing: false, status: "paused" });
  };
  private onWaiting = () => { if (!this.disposed && !this.terminal && !this.video.paused) this.patch({ status: navigator.onLine ? "buffering" : "offline" }); };
  private onProgress = () => {
    if (this.disposed) return;
    let buffered = 0;
    for (let i = 0; i < this.video.buffered.length; i++) {
      if (this.video.currentTime >= this.video.buffered.start(i) - .1 && this.video.currentTime <= this.video.buffered.end(i)) buffered = this.video.buffered.end(i);
    }
    if (buffered > this.state.buffered) this.lastActivity = Date.now();
    this.patch({ buffered });
  };
  private onTime = () => {
    if (this.disposed) return;
    if (Math.abs(this.video.currentTime - this.lastTime) > .05) { this.lastActivity = Date.now(); this.lastTime = this.video.currentTime; }
    this.patch({ time: this.video.currentTime, duration: Number.isFinite(this.video.duration) ? this.video.duration : this.state.duration });
    this.onProgress();
    if (Date.now() - this.lastSaved > 5000) this.save();
  };
  private onEnded = () => { this.save(); this.patch({ playing: false, status: "ended" }); this.options.ended(); };
  private onVideoError = () => {
    if (this.disposed || this.terminal || !this.video.error) return;
    if (this.hls || this.dash) return; // Their error policy owns recovery.
    if (this.state.variant?.kind === "hls" && !this.nativeRetried && !this.state.ready) {
      this.nativeRetried = true;
      const url = this.video.currentSrc;
      this.video.removeAttribute("src"); this.video.load();
      this.video.removeAttribute("crossorigin");
      this.video.src = url; this.video.load();
      return;
    }
    this.fail("Браузер не смог открыть это видео. Попробуйте повторить подключение.", `MEDIA_${this.video.error.code}`);
  };
  private onOffline = () => {
    if (this.disposed) return;
    if (this.hls) { this.hls.stopLoad(); this.loadingStopped = true; }
    this.patch({ status: "offline", error: "Нет интернета. Ожидаем восстановление связи." });
  };
  private onOnline = () => {
    if (this.disposed || this.terminal || this.state.status !== "offline") return;
    this.lastActivity = Date.now();
    this.patch({ error: "", status: this.desiredPlay ? "buffering" : "paused" });
    if (this.hls && this.desiredPlay) this.resumeLoading();
    else if (this.dash && this.desiredPlay) this.dash.retryStreaming(1);
    if (this.desiredPlay) this.play();
  };

  private monitorProgress = () => {
    if (this.disposed || this.terminal || !navigator.onLine || document.hidden || (this.state.ready && this.video.paused)) { this.lastActivity = Date.now(); return; }
    // Network loaders own their progress/stall deadlines. Some valid DASH
    // segments span 30+ seconds and must not be cut off by a second UI timer.
    if ((this.hls || this.dash) && this.state.buffered <= this.video.currentTime + .25) return;
    // A fixed UI spinner timeout used to report normal long segments as errors.
    // Only no progress for 90s is terminal; never restart a healthy stream.
    if (Date.now() - this.lastActivity > 90_000) this.fail("Загрузка остановилась. Позиция сохранена; попробуйте продолжить.", "NO_PROGRESS");
  };

  private fail(message: string, code: string) {
    if (this.disposed || this.terminal) return;
    this.terminal = true;
    this.save(); if (this.bound) this.video.pause(); this.hls?.stopLoad();
    this.patch({ status: "error", playing: false, error: message, code });
    void this.stop();
  }

  play() {
    if (this.disposed || this.terminal) return;
    if (isDownloadActive() && !this.options.local) return;
    this.desiredPlay = true;
    this.resumeLoading();
    void this.video.play().catch((error) => {
      if (this.disposed) return;
      if (error instanceof DOMException && error.name === "AbortError") return;
      this.patch({ status: "paused", playing: false });
      this.hls?.pauseBuffering();
    });
  }

  pause() { this.desiredPlay = false; this.video.pause(); this.hls?.pauseBuffering(); }

  snapshot() {
    return { time: this.bound && this.state.ready ? this.video.currentTime : this.state.time || this.options.initialTime,
      duration: this.state.duration, wantsPlay: this.desiredPlay };
  }

  save = () => {
    if (!this.bound || !this.state.ready || !Number.isFinite(this.video.duration) || this.video.currentTime < 1) return;
    this.lastSaved = Date.now();
    this.options.save(this.video.currentTime, this.video.duration);
  };

  stop(reason?: "switch" | "download"): Promise<void> {
    if (this.stopPromise) return this.stopPromise;
    if (reason === "download") this.patch({ status: "download", playing: false, error: "Просмотр приостановлен на время скачивания." });
    this.save();
    if (this.bound && this.state.ready) this.state = { ...this.state, time: this.video.currentTime };
    this.disposed = true;
    this.aborter.abort();
    clearInterval(this.monitor); clearTimeout(this.retryTimer);
    this.events.forEach(([name, callback]) => this.video.removeEventListener(name, callback));
    window.removeEventListener("online", this.onOnline); window.removeEventListener("offline", this.onOffline); window.removeEventListener("pagehide", this.save);
    this.hls?.stopLoad(); this.hls?.destroy(); this.hls = null;
    if (this.bound) this.video.pause();
    this.stopPromise = (async () => {
      try { await this.dash?.destroy(); }
      catch { /* Teardown still releases the element and the session lease. */ }
      finally {
        this.dash = null;
        if (this.bound) { this.video.removeAttribute("src"); this.video.load(); this.bound = false; }
        this.releaseLease?.();
      }
    })();
    return this.stopPromise;
  }
}