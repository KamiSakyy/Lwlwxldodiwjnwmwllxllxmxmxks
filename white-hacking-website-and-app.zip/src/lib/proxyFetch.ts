// Metadata-only fallback when our own gateway is not deployed.
// Carries ONLY tiny page/API responses. Video bytes always stream direct
// (or via our gateway) — never through here, never duplicated.

const GET_PROXIES = [
  (u: string) => `https://api.allorigins.win/raw?url=${encodeURIComponent(u)}`,
  (u: string) => `https://api.codetabs.com/v1/proxy?quest=${encodeURIComponent(u)}`,
];

async function once(url: string, init: RequestInit | undefined, ms: number): Promise<Response> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), ms);
  try {
    const res = await fetch(url, { ...init, signal: controller.signal, credentials: "omit" });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res;
  } finally {
    window.clearTimeout(timer);
  }
}

export function proxyFetcher(timeoutMs = 12000): (url: string, init?: RequestInit) => Promise<Response> {
  return async (url, init = {}) => {
    const method = (init.method || "GET").toUpperCase();
    let lastErr: unknown = null;
    try {
      return await once(url, init, timeoutMs);
    } catch (e) {
      lastErr = e;
    }
    try {
      // corsproxy.io forwards method + headers, so POST resolvers work too.
      return await once(`https://corsproxy.io/?url=${encodeURIComponent(url)}`, init, timeoutMs);
    } catch (e) {
      lastErr = e;
    }
    if (method === "GET") {
      for (const build of GET_PROXIES) {
        try {
          return await once(build(url), { headers: { Accept: "*/*" } }, timeoutMs);
        } catch (e) {
          lastErr = e;
        }
      }
    }
    throw lastErr instanceof Error ? lastErr : new Error("Fetch failed");
  };
}
