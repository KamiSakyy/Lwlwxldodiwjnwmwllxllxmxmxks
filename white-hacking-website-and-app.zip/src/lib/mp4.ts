type Box = { type: string; start: number; data: number; end: number };

function boxes(bytes: Uint8Array, start = 0, end = bytes.length): Box[] {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const found: Box[] = [];
  for (let offset = start; offset + 8 <= end;) {
    let size = view.getUint32(offset);
    let header = 8;
    if (size === 1) {
      if (offset + 16 > end) break;
      size = view.getUint32(offset + 8) * 2 ** 32 + view.getUint32(offset + 12);
      header = 16;
    } else if (size === 0) size = end - offset;
    if (size < header || offset + size > end || !Number.isSafeInteger(size)) break;
    const type = String.fromCharCode(...bytes.subarray(offset + 4, offset + 8));
    found.push({ type, start: offset, data: offset + header, end: offset + size });
    offset += size;
  }
  return found;
}

function find(bytes: Uint8Array, path: string[], start = 0, end = bytes.length): Box[] {
  const result = boxes(bytes, start, end).filter((box) => box.type === path[0]);
  return path.length === 1 ? result : result.flatMap((box) => find(bytes, path.slice(1), box.data, box.end));
}

export function trackSignature(bytes: Uint8Array): string {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  return find(bytes, ["moov", "trak"]).map((track) => {
    const header = find(bytes, ["tkhd"], track.data, track.end)[0];
    const description = find(bytes, ["mdia", "minf", "stbl", "stsd"], track.data, track.end)[0];
    if (!header || !description) throw new Error("Не удалось прочитать дорожки MP4.");
    const id = view.getUint32(header.data + (bytes[header.data] === 1 ? 20 : 12));
    return `${id}:${Array.from(bytes.subarray(description.data, description.end), (byte) => byte.toString(16).padStart(2, "0")).join("")}`;
  }).join("|");
}

export function hasVideoAndAudio(bytes: Uint8Array): boolean {
  const types = find(bytes, ["moov", "trak", "mdia", "hdlr"]).map((box) => String.fromCharCode(...bytes.subarray(box.data + 8, box.data + 12)));
  return types.includes("vide") && types.includes("soun");
}

// Streaming initialization segments use unknown durations. Write real VOD
// durations so a saved file has a useful timeline in standalone players.
export function setMp4Duration(input: Uint8Array, seconds: number): Uint8Array<ArrayBuffer> {
  const bytes = new Uint8Array(input);
  const view = new DataView(bytes.buffer);
  const movie = find(bytes, ["moov", "mvhd"])[0];
  if (!movie) throw new Error("Видео не содержит заголовка MP4.");
  const movieVersion = bytes[movie.data];
  const movieTimescale = view.getUint32(movie.data + (movieVersion === 1 ? 20 : 12));
  const write = (offset: number, version: number, timescale: number) => {
    const duration = Math.round(seconds * timescale);
    if (!Number.isFinite(duration) || duration < 0 || (!version && duration > 0xfffffffe)) throw new Error("Видео слишком длинное для этого формата скачивания.");
    if (version === 1) { view.setUint32(offset, Math.floor(duration / 2 ** 32)); view.setUint32(offset + 4, duration % 2 ** 32); }
    else view.setUint32(offset, duration);
  };
  write(movie.data + (movieVersion === 1 ? 24 : 16), movieVersion, movieTimescale);
  for (const track of find(bytes, ["moov", "trak"])) {
    const header = find(bytes, ["tkhd"], track.data, track.end)[0];
    const media = find(bytes, ["mdia", "mdhd"], track.data, track.end)[0];
    if (header) {
      const version = bytes[header.data];
      write(header.data + (version === 1 ? 28 : 20), version, movieTimescale);
    }
    if (media) {
      const version = bytes[media.data];
      const timescale = view.getUint32(media.data + (version === 1 ? 20 : 12));
      write(media.data + (version === 1 ? 24 : 16), version, timescale);
    }
  }
  for (const extended of find(bytes, ["moov", "mvex", "mehd"])) write(extended.data + 4, bytes[extended.data], movieTimescale);
  return bytes;
}