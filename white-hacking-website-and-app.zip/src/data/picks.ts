import type { Release } from "../api";

// Editorial selections use verified release IDs; playback is always fetched fresh.
export const picks: Release[] = [
  { id: 9542, name: { main: "Провожающая в последний путь Фрирен", english: "Sousou no Frieren" }, year: 2023, type: { description: "ТВ" }, episodes_total: 28, poster: { src: "/storage/releases/posters/9542/8UGD4dHHp1kdjquBph2CUSk9pLNsGtYw.webp" } },
  { id: 9293, name: { main: "Одинокий рокер!", english: "BOCCHI THE ROCK!" }, year: 2022, type: { description: "ТВ" }, episodes_total: 12, poster: { src: "/storage/releases/posters/9293/KarR06vYIuQfrUhPaghuq6VPSJ7JNfBb.webp" } },
  { id: 9953, name: { main: "Моменты оваций", english: "Suu-funkan no Yell wo" }, year: 2024, type: { description: "Фильм" }, episodes_total: 1, poster: { src: "/storage/releases/posters/9953/dK8MeLOS2yvFYSwPnG5H1urchTbAzTln.webp" } },
  { id: 6877, name: { main: "Давайте сыграем", english: "Asobi Asobase" }, year: 2018, type: { description: "ТВ" }, episodes_total: 12, poster: { src: "/storage/releases/posters/6877/Q290Iiul9pvbz4UNFf1QdwEhnWGi7Qt1.webp" } },
  { id: 8469, name: { main: "Пушечные ядра", english: "Cannon Busters" }, year: 2019, type: { description: "ONA" }, episodes_total: 12, poster: { src: "/storage/releases/posters/8469/pwP636CtWpPbWgxLrokUrZOWdPZ7kvRg.webp" } },
  { id: 8391, name: { main: "Мастер дразнилок Такаги OVA", english: "Karakai Jouzu no Takagi-san OVA" }, year: 2018, type: { description: "OVA" }, poster: { src: "/storage/releases/posters/8391/1DN8mmQSreRbFDGLqZ0C2h4DBwXSxsfd.webp" } },
];