import { useCallback, useEffect, useMemo, useState } from "react";
import { Check, Download, Film, FolderOpen, LoaderCircle, Play, RotateCcw, Trash2, X } from "lucide-react";
import { useDownloads } from "../lib/downloads";
import { readableBytes } from "../lib/download";
import { type Episode, type Release } from "../api";
import Player from "../components/Player";
import InstallButton from "../components/InstallButton";

type LocalFile = { name: string; url: string; owned: boolean };

export default function Downloads() {
  const { jobs, start, cancel, remove, markSaved } = useDownloads();
  const [local, setLocal] = useState<LocalFile | null>(null);
  const [fileError, setFileError] = useState("");
  const localMedia = useMemo(() => {
    if (!local) return null;
    const episode: Episode = { id: "local-file", ordinal: 1 };
    const release: Release = { id: -1, name: { main: local.name }, episodes: [episode] };
    return { episode, release, episodes: [episode] };
  }, [local]);
  useEffect(() => () => { if (local?.owned) URL.revokeObjectURL(local.url); }, [local]);
  const noChange = useCallback(() => undefined, []);

  return <div className="page-shell page-enter py-10 sm:py-14">
    <div className="flex flex-wrap items-end justify-between gap-5"><div><p className="tag text-gold">С собой в любую историю</p><h1 className="disp mt-3 text-5xl italic sm:text-6xl">Загрузки</h1><p className="mt-4 text-sm text-mist">Любимые серии для дороги, самолёта и тихих вечеров.</p></div><InstallButton /></div>

    <div className="mt-10 flex flex-wrap items-center justify-between gap-4 border-y border-white/10 py-5"><div className="flex items-center gap-3"><FolderOpen size={20} className="text-gold" /><div><p className="text-sm">Уже есть видео на устройстве?</p><p className="mt-1 text-xs text-mist">Откройте его в нашем плеере, в том числе с Enhance.</p></div></div><label className="btn btn-secondary btn-small cursor-pointer"><Film size={15} />Открыть видео<input className="sr-only" type="file" accept="video/*,.mkv,.mp4,.webm,.m4v,.mov" aria-label="Выбрать видео с устройства" onChange={(event) => { const file = event.target.files?.[0]; if (!file) return; if (file.size === 0) { setFileError("Выбран пустой файл."); return; } setFileError(""); setLocal({ name: file.name, url: URL.createObjectURL(file), owned: true }); event.target.value = ""; }} /></label></div>
    {fileError && <p role="alert" className="mt-3 text-sm text-shu">{fileError}</p>}
    {local && localMedia && <section className="mt-8"><div className="mb-3 flex items-center justify-between gap-4"><h2 className="truncate text-sm">{local.name}</h2><button className="icon-button" aria-label="Закрыть локальное видео" onClick={() => setLocal(null)}><X size={20} /></button></div><Player key={local.url} release={localMedia.release} episode={localMedia.episode} episodes={localMedia.episodes} localSource={local.url} onChange={noChange} /></section>}

    <div className="mt-10 flex items-center justify-between"><h2 className="section-heading">Твои файлы</h2><span className="text-xs text-mist">{jobs.length ? `${jobs.length} в списке` : "Пока пусто"}</span></div>
    {jobs.length === 0 ? <div className="flex flex-col items-center py-20 text-center"><Download size={34} strokeWidth={1.25} className="text-white/30" /><h3 className="mt-5 text-lg">Здесь начнётся офлайн-просмотр</h3><p className="mt-3 max-w-[43ch] text-xs leading-6 text-mist">Включите серию, нажмите «Скачать» под плеером и выберите качество. Мы соберём видео в один файл.</p><a href="#/catalog" className="btn btn-secondary mt-6">Выбрать аниме</a></div> : <div className="mt-3">
      {jobs.map((job) => <article className="download-row" key={job.id}>
        <div className="aspect-[2/3] overflow-hidden rounded-md bg-panel">{job.poster && <img src={job.poster} alt="" className="h-full w-full object-cover" />}</div>
        <div className="min-w-0 self-center"><h3 className="truncate text-sm font-medium">{job.name}</h3><p className="mt-2 text-xs text-mist">Серия {job.episode} <span className="mx-1.5">·</span>{job.quality}p <span className="mx-1.5">·</span>MP4{job.voiceName ? ` · ${job.voiceName}` : ""}</p>
          {job.status === "loading" && <><div className="mt-4 h-1 overflow-hidden rounded-full bg-white/10"><div className="h-full bg-shu transition-[width]" style={{ width: `${job.total ? job.completed / job.total * 100 : 0}%` }} /></div><div className="mt-2 flex items-center gap-2 text-[10px] text-mist"><LoaderCircle size={11} className="animate-spin" />{job.total ? `${Math.round(job.completed / job.total * 100)}% · ${readableBytes(job.bytes)} · ${readableBytes(job.speed)}/с` : "Подготавливаем файл..."}</div></>}
          {job.status === "ready" && <p className="mt-3 flex items-center gap-2 text-xs text-[#b5d5b8]"><Check size={13} />Готов к сохранению · {readableBytes(job.bytes)}</p>}
          {job.status === "saved" && <p className="mt-3 flex items-center gap-2 text-xs text-[#b5d5b8]"><Check size={13} />{job.blobUrl ? "Передано браузеру для сохранения" : "Файл сохранён"} · {readableBytes(job.bytes)}</p>}
          {job.status === "error" && <p role="alert" className="mt-3 max-w-[62ch] text-xs leading-6 text-shu">{job.error}</p>}
          {job.status === "cancelled" && <p className="mt-3 text-xs text-mist">Загрузка отменена</p>}
        </div>
        <div className="flex flex-wrap items-center gap-2 self-center">
          {job.status === "loading" && <button className="btn btn-secondary btn-small" onClick={() => cancel(job.id)}><X size={14} />Отменить</button>}
          {job.blobUrl && <><a className="btn btn-primary btn-small" href={job.blobUrl} download={job.filename} onClick={() => markSaved(job.id)}><Download size={14} />Сохранить файл</a><button className="icon-button" aria-label="Смотреть скачанное видео" onClick={() => { setLocal({ name: job.name, url: job.blobUrl!, owned: false }); window.scrollTo({ top: 0, behavior: "smooth" }); }}><Play size={16} /></button></>}
          {(job.status === "error" || job.status === "cancelled") && <button className="icon-button" aria-label="Повторить скачивание" onClick={() => { remove(job.id); start(job); }}><RotateCcw size={16} /></button>}
          {job.status !== "loading" && <button className="icon-button" aria-label="Убрать запись и освободить память" onClick={() => { if (job.status === "ready" && !window.confirm("Файл ещё не сохранён. Удалить его из памяти?")) return; if (local?.url === job.blobUrl) setLocal(null); remove(job.id); }}><Trash2 size={15} /></button>}
        </div>
      </article>)}
    </div>}
    <p className="mt-8 max-w-[80ch] text-[11px] leading-6 text-mist">Не закрывайте вкладку во время загрузки. Готовый файл нужно сохранить на устройство до перезагрузки страницы. На Android он обычно находится в папке Downloads. Удаление записи здесь не удаляет уже сохранённый файл.</p>
  </div>;
}