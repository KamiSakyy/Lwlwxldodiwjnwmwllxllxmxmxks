import { useEffect, useState } from "react";
import { Bookmark, Play, Trash2, X } from "lucide-react";
import { getFavs, getHistory, removeFavorite, removeHistory } from "../store";
import { Empty } from "../components/Poster";
import { watchHref } from "../lib/playback";

export default function Favorites() {
  const [saved, setSaved] = useState(getFavs);
  const [history, setHistory] = useState(getHistory);
  const [tab, setTab] = useState<"saved" | "history">("saved");
  useEffect(() => {
    const sync = () => { setSaved(getFavs()); setHistory(getHistory()); };
    window.addEventListener("kurenai:library", sync);
    return () => window.removeEventListener("kurenai:library", sync);
  }, []);
  return <div className="page-shell page-enter py-10 sm:py-14">
    <p className="tag text-gold">Только твои истории</p><h1 className="disp mt-3 text-5xl italic sm:text-6xl">Моя коллекция</h1><p className="mt-4 text-sm text-mist">То, что хочется посмотреть. И то, к чему хочется вернуться.</p>
    <div className="mt-9 flex gap-7 border-b border-white/10" role="tablist" aria-label="Моя коллекция">
      <button role="tab" aria-selected={tab === "saved"} onClick={() => setTab("saved")} className={`border-b-2 pb-4 text-[13px] ${tab === "saved" ? "border-shu text-ink" : "border-transparent text-mist"}`}>Смотреть позже<span className="ml-2 text-[10px] text-mist">{saved.length}</span></button>
      <button role="tab" aria-selected={tab === "history"} onClick={() => setTab("history")} className={`border-b-2 pb-4 text-[13px] ${tab === "history" ? "border-shu text-ink" : "border-transparent text-mist"}`}>История просмотра<span className="ml-2 text-[10px] text-mist">{history.length}</span></button>
    </div>
    {tab === "saved" && (saved.length === 0 ? <Empty title="Место для любимого" text="Нажмите на закладку у любого аниме. Оно будет ждать вас здесь, без регистрации." /> : <div className="mt-8 grid grid-cols-2 gap-x-5 gap-y-8 sm:grid-cols-4 lg:grid-cols-6">
      {saved.map((item) => <article key={item.id} className="group relative"><div className="poster-image"><a href={`#/title/${item.id}`} className="absolute inset-0">{item.poster && <img src={item.poster} alt={item.name} loading="lazy" className="h-full w-full object-cover" />}<div className="poster-play"><Play size={28} fill="currentColor" /></div></a><button className="absolute right-2 top-2 grid h-9 w-9 place-items-center rounded-full bg-black/65 text-white" aria-label={`Убрать ${item.name} из коллекции`} onClick={() => removeFavorite(item.id)}><Bookmark size={16} fill="currentColor" /></button></div><a className="poster-title line-clamp-2 hover:text-shu" href={`#/title/${item.id}`}>{item.name}</a></article>)}
    </div>)}
    {tab === "history" && (history.length === 0 ? <Empty title="Начнём новую историю?" text="После начала просмотра здесь появится серия и сохранённая позиция. Продолжайте в своём ритме." /> : <div className="mt-8 grid gap-7 sm:grid-cols-2 lg:grid-cols-3">
      {history.map((item) => <article key={item.id} className="group relative"><div className="relative aspect-video overflow-hidden rounded-lg bg-panel"><a href={watchHref(item.id, item.ep, item.voice)} className="absolute inset-0">{item.poster && <img src={item.poster} alt="" className="h-full w-full object-cover" />}<div className="absolute inset-0 bg-gradient-to-t from-black/85 to-black/10" /><span className="absolute bottom-4 left-4 text-xs">Серия {item.ep}</span><Play size={20} fill="currentColor" className="absolute bottom-4 right-4" /><div className="absolute inset-x-0 bottom-0 h-0.5 bg-white/20"><div className="h-full bg-shu" style={{ width: `${item.duration ? Math.min(100, item.time / item.duration * 100) : 0}%` }} /></div></a><button className="absolute right-2 top-2 grid h-8 w-8 place-items-center rounded-full bg-black/60" aria-label={`Убрать ${item.name} из истории`} onClick={() => removeHistory(item.id)}><X size={15} /></button></div><a href={watchHref(item.id, item.ep, item.voice)} className="poster-title line-clamp-1 hover:text-shu">{item.name}</a><p className="poster-meta">{item.voiceName ? `${item.voiceName} · ` : ""}{item.duration - item.time > 30 ? `Осталось ${Math.ceil((item.duration - item.time) / 60)} мин` : "Серия просмотрена"}</p></article>)}
    </div>)}
    <div className="mt-12 flex items-center gap-2 text-[10px] text-mist"><Trash2 size={12} />Коллекция и история сохраняются в этом браузере. Синхронизации с другими устройствами пока нет.</div>
  </div>;
}