import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight, Play, RotateCcw } from "lucide-react";
import { getCatalog, getLatest, getRecommended, getRelease, type Release } from "../api";
import { getHistory } from "../store";
import { PosterCard, Rail, SkeletonPoster } from "../components/Poster";
import { picks } from "../data/picks";
import InstallButton from "../components/InstallButton";
import { EpisodeImage } from "../components/EpisodeGallery";
import { episodeTitle, watchHref } from "../lib/playback";

export default function Home() {
  const [latest, setLatest] = useState<Release[] | null>(null);
  const [recommended, setRecommended] = useState<Release[] | null>(null);
  const [top, setTop] = useState<Release[] | null>(null);
  const [multiVoice, setMultiVoice] = useState<Release[] | null>(null);
  const [featured, setFeatured] = useState<Release | null>(null);
  const [tab, setTab] = useState("picks");
  const [error, setError] = useState(false);
  const [retry, setRetry] = useState(0);
  const history = getHistory();

  useEffect(() => {
    let live = true;
    setError(false);
    getLatest(18).then((items) => { if (live) setLatest(items); }).catch(() => { if (live) { setLatest([]); setError(true); } });
    getRecommended(12).then((items) => { if (live) setRecommended(items); }).catch(() => { if (live) setRecommended([]); });
    getCatalog({ limit: 18, sorting: "RATING_DESC" }).then((data) => { if (live) setTop(data.items); }).catch(() => { if (live) setTop([]); });
    getCatalog({ limit: 12, sorting: "RATING_DESC", provider: "yummy" }).then((data) => { if (live) setMultiVoice(data.items); }).catch(() => { if (live) setMultiVoice([]); });
    getRelease(9542).then((data) => { if (live) setFeatured(data); }).catch(() => undefined);
    return () => { live = false; };
  }, [retry]);

  const selected = tab === "latest" ? latest : tab === "top" ? top : picks;
  return <div className="pb-16">
    <section className="hero-stage">
      <img className="hero-visual" src="/images/kurenai-hero.jpg" alt="Аниме-иллюстрация: эльфийская путешественница смотрит на залитую солнцем долину" fetchPriority="high" />
      <div className="hero-shade" />
      <motion.div className="hero-content page-shell" initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .8, delay: .08 }}>
        <span className="tag text-gold">Твой маленький кинотеатр</span>
        <h1 className="hero-wordmark">Kurenai<span className="text-shu">.</span></h1>
        <h2 className="hero-heading">Останься ещё<br />на одну серию.</h2>
        <p className="mt-5 max-w-[34ch] text-[13px] leading-6 text-[#bbb8b2] sm:text-sm">Любимые миры. Новые истории.<br />Большие чувства на любом экране.</p>
        <div className="mt-8 flex flex-wrap items-center gap-3">
          <a className="btn btn-primary" href="#/watch/9542/1"><Play size={15} fill="currentColor" />Смотреть Фрирен</a>
          <a className="btn btn-secondary !border-white/20 !bg-black/15" href="#/catalog">Открыть каталог<ArrowRight size={15} /></a>
        </div>
      </motion.div>
    </section>

    <section className="page-shell -mt-1">
      <div className="flex items-center justify-between gap-3 border-b border-white/9">
        <div className="hide-scroll flex gap-7 overflow-auto" role="tablist" aria-label="Подборка аниме">
          {[['picks', 'Выбор Kurenai'], ['latest', 'Новые серии'], ['top', 'Популярное']].map(([key, label]) => <button key={key} role="tab" aria-selected={key === tab} onClick={() => setTab(key)} className={`relative whitespace-nowrap pb-4 pt-2 text-[13px] transition-colors ${tab === key ? "text-ink" : "text-mist hover:text-ink"}`}>{label}{tab === key && <motion.span layoutId="home-tab" className="absolute inset-x-0 bottom-0 h-0.5 rounded-full bg-shu" />}</button>)}
        </div>
        <a href="#/catalog" className="mb-2 hidden items-center gap-2 text-[11px] text-mist transition-colors hover:text-ink sm:flex">Весь каталог<ArrowRight size={14} /></a>
      </div>
      <div className="mb-6 mt-8 flex items-end justify-between"><div><h2 className="section-heading">Твоя следующая история</h2><p className="mt-2 text-xs text-mist">Нажми play. Остальное подождёт.</p></div><span className="hidden font-display text-3xl italic text-white/25 sm:block">for you</span></div>
      <div className="hide-scroll rail flex gap-5 overflow-x-auto pb-2" role="tabpanel">
        {selected ? selected.map((release) => <div className="poster-slot" key={release.id}><PosterCard r={release} href={`#/title/${release.id}`} /></div>) : <SkeletonPoster />}
        {selected?.length === 0 && <p className="py-12 text-sm text-mist">Не удалось загрузить подборку. Попробуйте позже.</p>}
      </div>
      {error && <div role="status" className="mt-4 flex items-center gap-3 text-xs text-mist">Обновления пока недоступны. Сохранённая подборка остаётся с вами.<button className="icon-button" onClick={() => setRetry((value) => value + 1)} aria-label="Повторить загрузку"><RotateCcw size={15} /></button></div>}
    </section>

    {featured && featured.episodes?.length ? <Rail label="Ещё ближе к истории" kicker="Фрирен · первые главы" more="#/title/9542">{featured.episodes.slice(0, 8).map((episode) => <a key={episode.id} href={`#/watch/9542/${episode.ordinal}`} className="episode-feature group"><div className="relative"><EpisodeImage episode={episode} release={featured} /><span className="episode-duration">{episode.duration ? `${Math.round(episode.duration / 60)} мин` : `Серия ${episode.ordinal}`}</span><span className="episode-play"><Play size={18} fill="currentColor" /></span></div><p className="mt-3 text-[9px] uppercase tracking-[.14em] text-gold">Серия {String(episode.ordinal).padStart(2, "0")}</p><h3 className="mt-1.5 text-[13px] font-medium leading-6">{episodeTitle(episode)}</h3></a>)}</Rail> : null}

    {history.length > 0 && <Rail label="Продолжим с того же места?" more="#/favorites">
      {history.slice(0, 12).map((item) => <a key={item.id} href={watchHref(item.id, item.ep, item.voice)} className="group block w-[260px] shrink-0 sm:w-[300px]">
        <div className="relative aspect-video overflow-hidden rounded-lg bg-panel">{item.poster && <img src={item.poster} alt="" className="h-full w-full object-cover" />}<div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" /><span className="absolute bottom-4 left-4 text-xs">Серия {item.ep}</span><Play size={21} className="absolute bottom-4 right-4" /><div className="absolute inset-x-0 bottom-0 h-[3px] bg-white/25"><div className="h-full bg-shu" style={{ width: `${item.duration ? Math.min(100, item.time / item.duration * 100) : 0}%` }} /></div></div>
        <p className="poster-title line-clamp-1">{item.name}</p>
      </a>)}
    </Rail>}

    <Rail label="Сейчас самое время посмотреть" more="#/catalog?sort=FRESH_AT_DESC">
      {latest ? (latest.length ? latest : picks).map((release) => <div className="poster-slot" key={release.id}><PosterCard r={release} href={`#/title/${release.id}`} /></div>) : <SkeletonPoster />}
    </Rail>
    {(recommended === null || recommended.length > 0) && <Rail label="Возможно, это любовь" more="#/catalog?sort=RATING_DESC">
      {recommended ? recommended.map((release) => <div className="poster-slot" key={release.id}><PosterCard r={release} href={`#/title/${release.id}`} /></div>) : <SkeletonPoster />}
    </Rail>}

    {(multiVoice === null || multiVoice.length > 0) && <Rail label="Больше историй. Больше голосов." kicker="Дополнительная коллекция" more="#/catalog?source=yummy">{multiVoice ? multiVoice.map((release) => <div className="poster-slot" key={release.id}><PosterCard r={release} href={`#/title/${release.id}`} /></div>) : <SkeletonPoster />}</Rail>}

    <section className="page-shell mt-20">
      <div className="flex flex-col justify-between gap-6 border-y border-white/10 py-10 sm:flex-row sm:items-center">
        <div><span className="tag text-gold">Твой мир. Твой ритм.</span><h2 className="disp mt-3 text-4xl italic">Хорошие истории всегда рядом.</h2><p className="mt-3 max-w-[52ch] text-xs leading-6 text-mist">Добавь Kurenai на главный экран. Продолжай с того же момента и сохраняй любимые серии в дорогу.</p></div>
        <div className="shrink-0"><InstallButton /></div>
      </div>
    </section>
  </div>;
}