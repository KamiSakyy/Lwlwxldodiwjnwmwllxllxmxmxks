import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, Bookmark, Check, Headphones, Play, RotateCcw, Star } from "lucide-react";
import { getRelease, img, ratingOf, titleOf, type Release } from "../api";
import { isFav, progressOf, toggleFav } from "../store";
import { Empty } from "../components/Poster";
import EpisodeGallery from "../components/EpisodeGallery";
import { useReleaseEpisodes } from "../lib/useReleaseEpisodes";
import { episodeCountText, episodesForVoice, voiceChoices, watchHref } from "../lib/playback";
import VoicePicker from "../components/VoicePicker";
import { migrateVoice } from "../lib/voices";
import { readPreference, savePreference } from "../lib/preferences";

export default function Title({ id }: { id: number }) {
  const [release, setRelease] = useState<Release | null>(null);
  const [error, setError] = useState(false);
  const [retry, setRetry] = useState(0);
  const [favorite, setFavorite] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [voice, setVoice] = useState("");
  const variants = useReleaseEpisodes(release);
  const choices = useMemo(() => voiceChoices(variants.episodes), [variants.episodes]);
  const wanted = voice || migrateVoice(readPreference<string>(`voice.${id}`, "primary"));
  const selected = choices.some((choice) => choice.id === wanted) ? wanted : choices[0]?.id || "";
  const episodes = useMemo(() => episodesForVoice(variants.episodes, selected), [variants.episodes, selected]);
  const progress = progressOf(id, selected);
  useEffect(() => {
    let live = true;
    setRelease(null); setError(false); setExpanded(false); setVoice("");
    getRelease(id, retry > 0).then((data) => { if (live) { setRelease(data); setFavorite(isFav(data.id)); document.title = `${titleOf(data)} - Kurenai`; } })
      .catch(() => { if (live) setError(true); });
    return () => { live = false; };
  }, [id, retry]);
  if (error) return <div><Empty title="Небольшой антракт" text="Не удалось открыть эту историю. Возможно, соединение прервалось." /><div className="-mt-10 pb-16 text-center"><button className="btn btn-secondary" onClick={() => setRetry((value) => value + 1)}><RotateCcw size={15} />Повторить</button></div></div>;
  if (!release || release.id !== id) return <div className="page-shell py-12"><div className="skeleton h-[440px] rounded-xl" /></div>;
  const start = progress && episodes.some((episode) => episode.ordinal === progress.ep) ? progress.ep : episodes[0]?.ordinal ?? 1;
  const poster = img(release.poster);
  const rating = ratingOf(release);
  const blocked = release.is_blocked_by_geo || release.is_blocked_by_copyrights;
  return <div className="page-enter pb-16">
    <section className="relative isolate overflow-hidden">
      {poster && <img src={poster} alt="" aria-hidden="true" className="absolute inset-0 -z-20 h-full w-full object-cover object-center opacity-[.12] blur-xl" />}
      <div className="absolute inset-0 -z-10 bg-gradient-to-t from-void to-transparent" />
      <div className="page-shell pb-10 pt-6 sm:pb-16">
        <a href="#/catalog" className="inline-flex items-center gap-2 py-2 text-xs text-mist hover:text-ink"><ArrowLeft size={13} />Вернуться в каталог</a>
        <div className="mt-7 grid gap-8 md:grid-cols-[220px_1fr] lg:grid-cols-[250px_1fr] lg:gap-12">
          <div className="mx-auto w-[180px] md:mx-0 md:w-auto"><div className="relative aspect-[2/3] overflow-hidden rounded-lg bg-panel shadow-2xl">{poster && <img src={poster} alt={titleOf(release)} className="h-full w-full object-cover" />}</div></div>
          <div className="min-w-0 self-center">
            <div className="flex flex-wrap items-center gap-4 text-[11px] text-mist">{rating && <span className="flex items-center gap-1.5 text-gold"><Star size={13} fill="currentColor" />{rating.toFixed(1)}</span>}<span>{release.year}</span><span>{release.type?.description || "Аниме"}</span><span>{release.age_rating?.label}</span><span className={release.is_ongoing ? "text-shu" : "text-mist"}>{release.is_ongoing ? "Выходит" : "Завершено"}</span></div>
            <h1 className="disp mt-5 max-w-[27ch] text-[clamp(2.5rem,4.3vw,4.5rem)] leading-[1.06] italic">{titleOf(release)}</h1>
            {release.name.english && <p className="mt-3 text-xs tracking-wide text-mist">{release.name.english}</p>}
            <div className="mt-5 flex flex-wrap gap-x-3 gap-y-2">{release.genres?.map((genre) => <a key={genre.id} className="text-[11px] text-[#bba894] underline-offset-4 hover:underline" href={`#/catalog?genre=${genre.id}${release.provider === "yummy" ? "&source=yummy" : ""}`}>{genre.name}</a>)}</div>
            <p className={`mt-5 max-w-[76ch] whitespace-pre-line text-[13px] leading-7 text-[#aba7ad] ${expanded ? "" : "line-clamp-4"}`}>{release.description}</p>
            {(release.description?.length || 0) > 270 && <button className="mt-2 py-1 text-[11px] text-gold" onClick={() => setExpanded(!expanded)}>{expanded ? "Свернуть описание" : "Читать дальше"}</button>}
            <div className="mt-7 flex flex-wrap items-center gap-3">{blocked ? <button className="btn btn-secondary" disabled>Просмотр ограничен</button> : episodes.length ? <a href={watchHref(id, start, selected)} className="btn btn-primary"><Play size={15} fill="currentColor" />{progress ? `Продолжить · серия ${start}` : "Начать смотреть"}</a> : <button className="btn btn-secondary" disabled>{variants.loading ? "Проверяем озвучки..." : "Нет доступного видео"}</button>}<button className={`btn btn-secondary ${favorite ? "!border-shu/40 !text-shu" : ""}`} aria-pressed={favorite} onClick={() => setFavorite(toggleFav(release))}>{favorite ? <Check size={16} /> : <Bookmark size={16} />}{favorite ? "В твоей коллекции" : "Смотреть позже"}</button></div>
            <p className="mt-4 text-[10px] text-mist">{episodeCountText(episodes.length)} в выбранной озвучке</p>
            <p className="mt-2 flex items-center gap-1.5 text-[10px] text-gold"><Headphones size={12} />{variants.loading ? "Подбираем озвучки..." : `${choices.length} доступных озвучек`}</p>
          </div>
        </div>
      </div>
    </section>
    <section className="page-shell mt-6">
      <VoicePicker choices={choices} selected={selected} onSelect={(value) => { setVoice(value); savePreference(`voice.${id}`, value); }} loading={variants.loading} error={variants.error} onRetry={variants.retry} />
      <div className="mt-7"><EpisodeGallery release={release} episodes={episodes} voice={selected} title="История по главам" /></div>
    </section>
  </div>;
}