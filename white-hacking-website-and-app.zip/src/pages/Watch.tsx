import { useCallback, useEffect, useMemo, useState } from "react";
import { ArrowLeft, ArrowRight, Bookmark, Check, ChevronRight, Headphones, Play, Share2 } from "lucide-react";
import { getRelease, titleOf, type Release } from "../api";
import { isFav, progressOf, toggleFav } from "../store";
import Player from "../components/Player";
import EpisodeGallery from "../components/EpisodeGallery";
import VoicePicker from "../components/VoicePicker";
import { Empty } from "../components/Poster";
import { useReleaseEpisodes } from "../lib/useReleaseEpisodes";
import { episodeCountText, episodeNumber, episodeTitle, episodesForVoice, voiceChoices, watchHref } from "../lib/playback";
import { readPreference, savePreference } from "../lib/preferences";
import { migrateVoice } from "../lib/voices";

export default function Watch({ id, ep, voice }: { id: number; ep: number; voice?: string }) {
  const [release, setRelease] = useState<Release | null>(null);
  const [error, setError] = useState("");
  const [favorite, setFavorite] = useState(false);
  const [shared, setShared] = useState("");
  const [retry, setRetry] = useState(0);
  const [switchNotice, setSwitchNotice] = useState("");
  const variants = useReleaseEpisodes(release);

  useEffect(() => {
    let live = true;
    setRelease(null); setError("");
    getRelease(id, retry > 0).then((data) => { if (live) { setRelease(data); setFavorite(isFav(data.id)); document.title = `${titleOf(data)} - Kurenai`; } })
      .catch((error) => { if (live) setError(error instanceof Error ? error.message : "Не удалось открыть аниме. Проверьте соединение и попробуйте снова."); });
    return () => { live = false; };
  }, [id, retry]);

  const choices = useMemo(() => voiceChoices(variants.episodes), [variants.episodes]);
  const wanted = migrateVoice(voice || readPreference<string>(`voice.${id}`, "primary"));
  const waitingForVoice = variants.loading && !choices.some((choice) => choice.id === wanted);
  const keepSelection = choices.some((choice) => choice.id === wanted) || Boolean(voice) || waitingForVoice;
  const selected = keepSelection ? wanted : choices[0]?.id || "";
  const selectedChoice = choices.find((choice) => choice.id === selected);
  const episodes = useMemo(() => episodesForVoice(variants.episodes, selected), [variants.episodes, selected]);
  const episode = episodes.find((item) => item.ordinal === ep);
  const index = episodes.findIndex((item) => item.ordinal === ep);
  const next = episodes[index + 1];
  const previous = episodes[index - 1];
  const onChange = useCallback((ordinal: number) => { location.hash = watchHref(id, ordinal, selected).slice(1); }, [id, selected]);
  const selectVoice = (value: string) => {
    const list = episodesForVoice(variants.episodes, value);
    if (!list.length) return;
    const saved = progressOf(id, value);
    const target = list.some((item) => item.ordinal === ep) ? ep : list.some((item) => item.ordinal === saved?.ep) ? saved!.ep : list[0].ordinal;
    setSwitchNotice(target !== ep ? `В этой озвучке другая доступность серий. Открыта ${episodeNumber(list.find((item) => item.ordinal === target)!).toLocaleLowerCase("ru")}.` : "");
    savePreference(`voice.${id}`, value); location.hash = watchHref(id, target, value).slice(1);
  };
  const alternative = () => {
    document.getElementById("voice-selector")?.scrollIntoView({ behavior: "smooth", block: "center" });
    document.querySelector<HTMLSelectElement>("#voice-selector select")?.focus({ preventScroll: true });
  };
  const share = async () => {
    try {
      if (navigator.share) await navigator.share({ title: release ? titleOf(release) : "Kurenai", url: location.href });
      else if (navigator.clipboard) { await navigator.clipboard.writeText(location.href); setShared("Ссылка на эту серию и озвучку скопирована"); }
      else setShared("Скопируйте ссылку из адресной строки браузера.");
    } catch (error) { if (!(error instanceof DOMException && error.name === "AbortError")) setShared("Скопируйте ссылку из адресной строки."); }
  };

  if (error) return <div><Empty title="Небольшой антракт" text={error} /><div className="-mt-12 mb-16 flex justify-center gap-3"><button className="btn btn-secondary" onClick={() => setRetry((value) => value + 1)}>Попробовать снова</button><a href="#/connections" className="btn btn-secondary">Подключения</a></div></div>;
  if (!release || release.id !== id) return <div className="page-shell py-10"><div className="skeleton mb-5 h-4 w-1/3 rounded" /><div className="skeleton aspect-video rounded-lg" /></div>;
  if (release.is_blocked_by_geo || release.is_blocked_by_copyrights) return <Empty title="Просмотр недоступен" text="Этот выпуск недоступен в вашем регионе или ограничен правообладателем." />;

  return <div className="page-shell watch-page pb-16 max-md:!px-0">
    <div className="watch-breadcrumb"><a href="#/catalog">Каталог</a><ChevronRight size={11} /><a href={`#/title/${id}`} className="truncate">{titleOf(release)}</a><ChevronRight size={11} /><span className="shrink-0 text-white/80">{episode ? episodeNumber(episode) : `Серия ${ep}`}</span></div>
    <div className="watch-layout">
      <div className="min-w-0">
        {episode && selectedChoice ? <Player key={`${release.id}:${selected}`} release={release} episode={episode} episodes={episodes} voice={selected} voiceName={selectedChoice.name} onChange={onChange} onAlternative={choices.length > 1 ? alternative : undefined} />
          : <div className="missing-episode"><Headphones size={30} strokeWidth={1.3} className="text-shu" /><h2>{waitingForVoice ? "Подбираем твою озвучку" : choices.length ? "Эта серия пока недоступна" : "История ещё готовится"}</h2><p>{waitingForVoice ? "Проверяем опубликованные серии. Видео других озвучек в фоне не запускается." : choices.length ? "Выберите доступную серию или другую озвучку. Список справа содержит только выбранный перевод." : "Пока не найдено озвучек, доступных для нашего плеера. Попробуйте другую историю или повторите загрузку позже."}</p>{!waitingForVoice && choices.filter((choice) => choice.ordinals.includes(ep)).slice(0, 3).map((choice) => <button className="btn btn-secondary btn-small" key={choice.id} onClick={() => selectVoice(choice.id)}><Play size={12} />{choice.name}</button>)}</div>}

        <VoicePicker choices={choices} selected={selected} onSelect={selectVoice} loading={variants.loading} error={variants.error} onRetry={variants.retry} />
        {switchNotice && <p role="status" className="mt-3 text-[11px] leading-6 text-gold max-md:px-5">{switchNotice}</p>}

        <div className="watch-title-block">
          <div className="flex items-start justify-between gap-4"><div className="min-w-0"><a className="text-[11px] text-gold hover:text-shu" href={`#/title/${id}`}>{titleOf(release)}</a><h1 className="mt-2.5 text-[25px] font-medium leading-snug tracking-[-.7px] sm:text-[32px]">{episode ? episodeTitle(episode) : `Эпизод ${ep}`}</h1><p className="mt-2 text-[11px] text-mist">{episode ? episodeNumber(episode) : "Серия не опубликована"}{episode?.duration ? ` · ${Math.round(episode.duration / 60)} мин` : ""}{release.year ? ` · ${release.year}` : ""}</p></div><div className="flex shrink-0 gap-1"><button className={`icon-button border ${favorite ? "border-shu/35 !text-shu" : "border-white/10"}`} aria-label={favorite ? "Убрать из коллекции" : "В коллекцию"} aria-pressed={favorite} onClick={() => setFavorite(toggleFav(release))}>{favorite ? <Check size={17} /> : <Bookmark size={17} />}</button><button className="icon-button border border-white/10" aria-label="Поделиться" onClick={share}><Share2 size={16} /></button></div></div>
          {shared && <p role="status" className="mt-3 text-[11px] text-gold">{shared}</p>}
          <div className="episode-nav"><button disabled={!previous} onClick={() => previous && onChange(previous.ordinal)}><ArrowLeft size={17} /><span><small>Предыдущая серия</small><strong>{previous ? episodeTitle(previous) : "Начало истории"}</strong></span></button><button className="text-right" disabled={!next} onClick={() => next && onChange(next.ordinal)}><span><small>Следующая серия</small><strong>{next ? episodeTitle(next) : "Продолжение следует"}</strong></span><ArrowRight size={17} /></button></div>
          <details className="mt-6 border-t border-white/10 pt-5"><summary className="cursor-pointer text-[12px] text-white/70">Об этой истории</summary><p className="mt-4 whitespace-pre-line text-[13px] leading-7 text-mist">{release.description}</p></details>
        </div>
      </div>
      <aside className="watch-episodes"><div className="voice-library-heading"><span className="tag text-gold">Твоя озвучка</span><span className="mt-2 block text-[12px] font-medium">{selectedChoice?.name || "Выберите озвучку"}</span><p className="mt-1 text-[10px] text-mist">{episodeCountText(episodes.length)} доступно</p></div><EpisodeGallery release={release} episodes={episodes} current={ep} voice={selected} compact title="Серии" /></aside>
    </div>
  </div>;
}