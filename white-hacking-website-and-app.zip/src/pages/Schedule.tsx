import { useEffect, useMemo, useState } from "react";
import { getSchedule, type Release } from "../api";
import { href } from "../router";
import { PosterCard, Empty } from "../components/Poster";

const DAYS = ["", "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"];

export default function Schedule() {
  const [items, setItems] = useState<{ release: Release }[] | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const today = new Date().getDay(); // 0 sun
  const todayApi = today === 0 ? 7 : today;

  useEffect(() => {
    getSchedule()
      .then(setItems)
      .catch(() => setErr("Расписание не загрузилось"));
  }, []);

  const byDay = useMemo(() => {
    const map: Record<number, Release[]> = { 1: [], 2: [], 3: [], 4: [], 5: [], 6: [], 7: [] };
    (items || []).forEach((it) => {
      const d = it.release.publish_day?.value || 0;
      if (map[d] && !map[d].some((release) => release.id === it.release.id)) map[d].push(it.release);
    });
    return map;
  }, [items]);

  if (err) return <Empty title="Тишина в зале" text={err} />;

  return (
    <div className="page-shell page-enter py-10 sm:py-14">
      <div className="tag text-gold">Неделя озвучки</div>
      <h1 className="disp mt-3 text-5xl text-ink italic sm:text-6xl">Расписание</h1>
      <p className="mt-3 max-w-[56ch] text-mist">
        Новые встречи с любимыми героями. Планируйте свой аниме-вечер.
      </p>

      {!items && (
        <div className="mt-10 grid gap-6">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="h-40 animate-pulse bg-panel" />
          ))}
        </div>
      )}

      {items && (
        <div className="mt-10 space-y-12">
          {[1, 2, 3, 4, 5, 6, 7].map((d) => (
            <section key={d}>
              <div className="mb-4 flex items-baseline gap-3 border-b border-line pb-2">
                <h2 className={`disp text-2xl italic ${d === todayApi ? "text-shu" : "text-ink"}`}>{DAYS[d]}</h2>
                <span className="tag text-mist">{byDay[d].length} релизов</span>
              </div>
              {byDay[d].length === 0 ? (
                <p className="text-sm text-mist">В этот день тишина.</p>
              ) : (
                <div className="grid grid-cols-2 gap-4 sm:grid-cols-4 lg:grid-cols-6">
                  {byDay[d].map((r) => (
                    <PosterCard key={r.id} r={r} href={href(`/title/${r.id}`)} />
                  ))}
                </div>
              )}
            </section>
          ))}
        </div>
      )}
    </div>
  );
}


