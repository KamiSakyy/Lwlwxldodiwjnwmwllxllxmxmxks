import { useEffect, useRef, useState } from "react";
import { ArrowLeft, CheckCircle2, Cpu, ExternalLink, Headphones, ListChecks, LoaderCircle, Play, RefreshCw, ShieldCheck } from "lucide-react";
import { getRelease } from "../api";
import { getApplicationToken, getGateway, mediaUrl, setApplicationToken, type GatewayStatus } from "../lib/network";
import { testYummyConnection } from "../lib/yummy";
import { checkGpuOrientation } from "../lib/gpuCheck";
import { checkVoiceLibrary } from "../lib/voiceChecks";

type CheckState = { loading: boolean; ok?: boolean; message: string };
const initial: CheckState = { loading: false, message: "Ещё не проверено" };

export default function Connections() {
  const [primary, setPrimary] = useState<CheckState>(initial);
  const [extra, setExtra] = useState<CheckState>(initial);
  const [gpu, setGpu] = useState<CheckState>(initial);
  const [voices, setVoices] = useState<CheckState>(initial);
  const [token, setToken] = useState(getApplicationToken);
  const [gateway, setGateway] = useState<GatewayStatus | null>(null);
  const [saved, setSaved] = useState("");
  const mounted = useRef(true);
  useEffect(() => { mounted.current = true; void getGateway().then((status) => { if (mounted.current) setGateway(status); }); return () => { mounted.current = false; }; }, []);

  const run = async (kind: "primary" | "extra" | "gpu" | "voices") => {
    const setter = kind === "primary" ? setPrimary : kind === "extra" ? setExtra : kind === "voices" ? setVoices : setGpu;
    setter({ loading: true, message: "Проверяем..." });
    try {
      let message = "";
      if (kind === "primary") {
        const release = await getRelease(9542, true);
        if (release.is_blocked_by_geo || release.is_blocked_by_copyrights) throw new Error("Проверочный релиз недоступен в вашем регионе. Выберите разрешённый релиз в каталоге.");
        const episode = release.episodes?.find((item) => item.ordinal === 1);
        const url = episode?.hls_720 || episode?.hls_480 || episode?.hls_1080;
        if (!url) throw new Error("Каталог доступен, но видео для проверочной серии не опубликовано.");
        const controller = new AbortController();
        const timeout = window.setTimeout(() => controller.abort(), 12_000);
        try {
          const response = await fetch(await mediaUrl(url), { signal: controller.signal });
          if (!response.ok) throw new Error(`Каталог V1 доступен, видеосервер ответил HTTP ${response.status}.`);
          if (!(await response.text()).trimStart().startsWith("#EXTM3U")) throw new Error("Вместо плейлиста пришёл другой ответ.");
          message = "Каталог V1 и плейлист доступны из этого браузера. Декодирование проверяется при запуске серии.";
        } finally { clearTimeout(timeout); }
      } else if (kind === "extra") {
        await testYummyConnection();
        message = "Дополнительный каталог отвечает. Прямое видео запрашивается только для выбранной серии и озвучки.";
      } else if (kind === "voices") message = checkVoiceLibrary();
      else message = await checkGpuOrientation();
      if (mounted.current) setter({ loading: false, ok: true, message });
    } catch (error) {
      if (mounted.current) setter({ loading: false, ok: false, message: error instanceof TypeError ? "Браузер не смог выполнить запрос. Возможны ограничения сети или CORS. Для своего сервера предусмотрен шлюз подключения." : error instanceof Error ? error.message : "Проверка не завершилась." });
    }
  };

  const rows = [
    { kind: "primary" as const, title: "Основной видеокаталог", text: "Проверка каталога V1 и доступности видеоплейлиста", icon: Play, state: primary },
    { kind: "extra" as const, title: "Коллекция с разными голосами", text: "Поиск, дополнительные тайтлы и студии озвучки", icon: Headphones, state: extra },
    { kind: "gpu" as const, title: "Ориентация изображения", text: "Реальная GPU-проверка: красный верх, синий низ, увеличение 2×", icon: Cpu, state: gpu },
    { kind: "voices" as const, title: "Озвучки и серии", text: "Проверка группировки, счётчиков и перехода по сериям без сетевых запросов", icon: ListChecks, state: voices },
  ];
  return <div className="page-shell page-enter max-w-[1100px] py-10 sm:py-14">
    <a href="#/catalog" className="inline-flex items-center gap-2 text-xs text-mist hover:text-ink"><ArrowLeft size={13} />Вернуться к историям</a>
    <p className="tag mt-9 text-gold">Чтобы ничто не отвлекало</p><h1 className="disp mt-3 text-5xl italic">Настроим просмотр</h1><p className="mt-4 max-w-[65ch] text-sm leading-7 text-mist">Проверьте соединение и обработку изображения прямо на своём устройстве. Результаты ниже появляются только после настоящей проверки.</p>
    <div className="mt-9 border-t border-white/10">{rows.map((row) => <section key={row.kind} className="flex flex-col gap-4 border-b border-white/10 py-7 sm:flex-row sm:items-start sm:justify-between"><div className="flex gap-4"><row.icon className="mt-1 shrink-0 text-gold" size={23} strokeWidth={1.4} /><div><h2 className="text-[15px] font-medium">{row.title}</h2><p className="mt-2 text-xs text-mist">{row.text}</p><p role="status" className={`mt-3 flex max-w-[64ch] items-start gap-2 text-[11px] leading-6 ${row.state.ok ? "text-[#add1b6]" : row.state.ok === false ? "text-[#ebaa9d]" : "text-mist"}`}>{row.state.ok && <CheckCircle2 size={13} className="mt-1.5 shrink-0" />}{row.state.message}</p></div></div><button className="btn btn-secondary btn-small self-start" disabled={row.state.loading} onClick={() => run(row.kind)}>{row.state.loading ? <LoaderCircle size={14} className="animate-spin" /> : <RefreshCw size={14} />}Проверить</button></section>)}</div>
    <details className="mt-9 rounded-xl border border-white/10 p-5"><summary className="cursor-pointer text-sm">Настройки доступа к дополнительной коллекции</summary><p className="mt-4 text-xs leading-6 text-mist">{gateway?.yummyConfigured ? "Ключ приложения настроен на сервере. Вводить его здесь не нужно." : "YummyAnime описывает ключ X-Application как обязательный для приложений. Если публичные запросы отклоняются, используйте собственный публичный ключ приложения. Пароли и личные токены сюда вводить не нужно."}</p>
      {!gateway?.yummyConfigured && <form className="mt-4" onSubmit={(event) => { event.preventDefault(); try { setApplicationToken(token); setSaved(token.trim() ? "Ключ сохранён только для этой вкладки. Теперь запустите проверку." : "Ключ удалён из сеанса."); } catch (error) { setSaved(error instanceof Error ? error.message : "Не удалось сохранить."); } }}><label htmlFor="application-key" className="text-[11px] text-mist">Публичный ключ приложения</label><div className="mt-2 flex flex-col gap-2 sm:flex-row"><input id="application-key" type="password" autoComplete="off" value={token} onChange={(event) => setToken(event.target.value)} className="min-w-0 flex-1 rounded-md border border-white/15 bg-panel px-3 py-3 text-xs outline-none focus:border-shu" placeholder="Не пароль аккаунта" /><button className="btn btn-secondary btn-small">Сохранить в сеансе</button></div></form>}
      {saved && <p className="mt-3 text-[11px] text-gold" role="status">{saved}</p>}
      <a href="https://yummyani.me/dev/applications" target="_blank" rel="noopener noreferrer" className="mt-4 inline-flex items-center gap-2 text-xs text-shu">Получить свой ключ<ExternalLink size={12} /></a>
      <p className="mt-3 text-[10px] leading-6 text-mist">По условиям API коммерческое использование согласовывается с владельцем. Ключ не отправляется сторонним публичным прокси.</p>
    </details>
    <p className="mt-6 flex items-start gap-2 text-[10px] leading-6 text-mist"><ShieldCheck size={14} className="mt-1 shrink-0" />{gateway ? "Серверный шлюз сайта подключён." : "Сайт подключается напрямую. При сетевых ограничениях владелец может запустить комплектный серверный шлюз."} Доступ к видео по-прежнему зависит от разрешений источника и региона.</p>
  </div>;
}