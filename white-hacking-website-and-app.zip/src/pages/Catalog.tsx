import { useEffect, useState } from "react";
import { ArrowLeft, ArrowRight, Headphones, RotateCcw, Search, Settings2, X } from "lucide-react";
import {
  getCatalog,
  getGenres,
  getYears,
  SEASONS,
  SORTS,
  STATUSES,
  TYPES,
  YEARS,
  type Genre,
  type Release,
} from "../api";
import { catalogHref, href } from "../router";
import { PosterCard, Empty } from "../components/Poster";

export default function Catalog({ q }: { q: Record<string, string> }) {
  const [items, setItems] = useState<Release[] | null>(null);
  const [pages, setPages] = useState(1);
  const [total, setTotal] = useState<number | null>(0);
  const [hasMore, setHasMore] = useState(false);
  const [genres, setGenres] = useState<Genre[]>([]);
  const [err, setErr] = useState<string | null>(null);
  const [years, setYears] = useState<number[]>(YEARS);
  const [retry, setRetry] = useState(0);
  const [search, setSearch] = useState(q.q || "");
  const page = Math.max(1, Math.floor(Number(q.page) || 1));
  const provider = q.source === "yummy" ? "yummy" : "libria";

  const filter = {
    provider,
    page,
    limit: 24,
    sorting: q.sort || (provider === "yummy" ? "RATING_DESC" : "FRESH_AT_DESC"),
    genres: q.genre,
    years: q.year,
    types: q.type,
    seasons: q.season,
    status: q.status,
    search: q.q,
  };

  useEffect(() => {
    let live = true;
    setGenres([]);
    getGenres(provider).then((data) => { if (live) setGenres(data); }).catch(() => undefined);
    getYears().then(setYears).catch(() => undefined);
    return () => { live = false; };
  }, [provider]);

  useEffect(() => { setSearch(q.q || ""); }, [q.q]);

  useEffect(() => {
    let live = true;
    setItems(null);
    setErr(null);
    getCatalog({ ...filter, provider })
      .then((res) => {
        if (!live) return;
        setItems(res.items);
        setPages(res.pages);
        setTotal(res.total);
        setHasMore(res.hasMore ?? page < res.pages);
      })
      .catch((error) => {
        if (live) { setErr(error instanceof Error ? error.message : "Каталог пока недоступен. Проверьте подключение и повторите попытку."); setItems([]); }
      });
    return () => {
      live = false;
    };
  }, [q.sort, q.genre, q.year, q.type, q.season, q.status, q.q, q.page, provider, retry]);

  const set = (key: string, value: string) => {
    const next = { ...q, [key]: value, page: undefined };
    if (!value) delete next[key];
    location.hash = catalogHref(next).slice(1);
  };

  const sel = (key: string, label: string, value: string, options: { v: string; t: string }[], all = true) => (
    <label className="flex min-w-0 flex-col gap-1">
      <span className="tag text-mist">{label}</span>
      <select
        value={value}
        onChange={(e) => set(key, e.target.value)}
        className="min-h-11 rounded-md border border-line bg-panel px-3 py-2.5 text-[12px] text-ink outline-none focus:border-shu"
      >
        {all && <option value="">Все</option>}
        {options.map((o) => (
          <option key={o.v} value={o.v}>
            {o.t}
          </option>
        ))}
      </select>
    </label>
  );

  return (
    <div className="page-shell page-enter py-10 sm:py-14">
      <div className="tag text-gold">Найдите свою историю</div>
      <h1 className="disp mt-3 text-5xl text-ink italic sm:text-6xl">Вся афиша</h1>
      {total != null && total > 0 && <p className="mt-3 text-xs text-mist">{total.toLocaleString("ru")} историй для тебя</p>}
      {provider === "yummy" && <p className="mt-3 text-xs leading-6 text-mist">Больше историй и разные студии озвучки. Наличие видео проверяется отдельно для каждого тайтла.</p>}
      <nav className="catalog-switch" aria-label="Коллекция каталога"><a href={catalogHref({ q: q.q })} className={provider === "libria" ? "active" : ""}>Основная коллекция</a><a href={catalogHref({ source: "yummy", q: q.q })} className={`flex items-center gap-2 ${provider === "yummy" ? "active" : ""}`}><Headphones size={15} />Мультиозвучка</a><a href="#/connections" className="ml-auto !text-mist" aria-label="Настройки подключения"><Settings2 size={15} /></a></nav>

      <form className="mt-7 flex max-w-xl items-center gap-3 rounded-lg border border-white/10 bg-panel px-4 py-2" onSubmit={(event) => { event.preventDefault(); set("q", search.trim()); }}><Search size={17} className="text-mist" /><input className="min-w-0 flex-1 bg-transparent py-1 text-sm outline-none" placeholder="Название на русском или английском" aria-label="Поиск по каталогу" value={search} onChange={(event) => setSearch(event.target.value)} /><button className="btn btn-secondary btn-small !min-h-8" type="submit">Найти</button></form>
      <div className={`mt-7 grid grid-cols-2 gap-3 sm:grid-cols-3 ${provider === "yummy" ? "lg:grid-cols-5" : "lg:grid-cols-6"}`}>
        {sel("sort", "Сортировка", q.sort || (provider === "yummy" ? "RATING_DESC" : "FRESH_AT_DESC"), SORTS.filter((sort) => provider !== "yummy" || sort.value !== "FRESH_AT_DESC").map((s) => ({ v: s.value, t: s.label || s.value })), false)}
        {sel("genre", "Жанр", q.genre || "", genres.map((g) => ({ v: String(g.id), t: g.name })))}
        {provider === "libria" && sel("year", "Год", q.year || "", years.map((y) => ({ v: String(y), t: String(y) })))}
        {sel("type", "Тип", q.type || "", TYPES.map((t) => ({ v: t.value, t: t.description || t.value })))}
        {sel("season", "Сезон", q.season || "", SEASONS.map((s) => ({ v: s.value, t: s.description || s.value })))}
        {sel("status", "Статус", q.status || "", STATUSES.map((s) => ({ v: s.value, t: s.description || s.value })))}
      </div>

      {Object.keys(q).some((key) => key !== "page" && key !== "source") && <a className="mt-4 inline-flex items-center gap-1.5 text-xs text-mist hover:text-shu" href={catalogHref({ source: q.source })}><X size={13} />Сбросить фильтры</a>}

      {err && <div role="alert" className="my-14 text-center"><p className="text-sm text-mist">{err}</p><div className="mt-5 flex justify-center gap-3"><button className="btn btn-secondary" onClick={() => setRetry((value) => value + 1)}><RotateCcw size={15} />Попробовать снова</button><a href="#/connections" className="btn btn-secondary">Настройки подключения</a></div></div>}

      {!items && (
        <div className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-4 lg:grid-cols-6">
          {Array.from({ length: 12 }).map((_, i) => (
            <div key={i} className="aspect-[2/3] animate-pulse bg-panel" />
          ))}
        </div>
      )}

      {!err && items && items.length === 0 && <Empty title="Пока ни одной истории" text="По этим фильтрам ничего не найдено. Попробуйте другой жанр или год." />}

      {items && items.length > 0 && (
        <div className="mt-10 grid grid-cols-2 gap-x-4 gap-y-8 sm:grid-cols-4 lg:grid-cols-6">
          {items.map((r) => (
            <PosterCard key={r.id} r={r} href={href(`/title/${r.id}`)} />
          ))}
        </div>
      )}

      {!err && items && (pages > 1 || page > 1) && (
        <nav className="mt-12 flex flex-wrap items-center justify-center gap-2" aria-label="Страницы каталога">
          <button className="icon-button border border-white/10" disabled={page <= 1} aria-label="Предыдущая страница" onClick={() => { location.hash = catalogHref({ ...q, page: String(page - 1) }).slice(1); }}><ArrowLeft size={16} /></button>
          {(provider === "yummy" ? [page] : Array.from(new Set([1, ...Array.from({ length: 5 }, (_, i) => page - 2 + i).filter((n) => n > 1 && n < pages), pages])).sort((a, b) => a - b)).map((n) => {
            const active = n === page;
            return (
              <a
                key={n}
                href={catalogHref({ ...q, page: String(n) })}
                aria-current={active ? "page" : undefined}
                className={`num grid h-11 min-w-10 place-items-center rounded-md px-2 text-[12px] ${
                  active ? "bg-shu text-void" : "border border-line text-mist hover:text-ink"
                }`}
              >
                {n}
              </a>
            );
          })}
          <button className="icon-button border border-white/10" disabled={!hasMore} aria-label="Следующая страница" onClick={() => { location.hash = catalogHref({ ...q, page: String(page + 1) }).slice(1); }}><ArrowRight size={16} /></button>
        </nav>
      )}
    </div>
  );
}
