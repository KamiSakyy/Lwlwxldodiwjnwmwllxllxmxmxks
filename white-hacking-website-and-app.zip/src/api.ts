import { getGateway, httpsUrl } from "./lib/network";

export const IMG = "https://anilibria.top";
const HOSTS = ["https://aniliberty.top", "https://anilibria.top"];
export const YUMMY_ID_OFFSET = 1_000_000_000;
export type AnimeProvider = "libria" | "yummy";

export type Poster = {
  src?: string | null;
  preview?: string | null;
  thumbnail?: string | null;
  optimized?: { src?: string | null; preview?: string | null; thumbnail?: string | null } | null;
};

export type Genre = { id: number; name: string; total_releases?: number };
export type Named = { value?: string | null; description?: string | null };
export type Age = { value?: string; label?: string; is_adult?: boolean };

export type Skip = { start?: number | null; stop?: number | null };
export type VideoQuality = "1080" | "720" | "480" | "360" | "auto";
export type MediaVariant = { quality: VideoQuality; url: string; kind: "hls" | "dash" | "mp4" };

/** Catalogued voice providers. Only ones with a legitimate direct stream are playable. */
export type SourceProvider = "aksor" | "sibnet" | "alloha" | "cvh" | "vk" | "rutube" | "zedfilm" | "other";

export type EpisodeSource = {
  id: string;
  voiceId: string;
  name: string;
  provider: SourceProvider;
  url: string;
  videoId?: string;
  animeId?: number;
  episodeLabel: string;
  duration?: number | null;
  opening?: Skip | null;
  ending?: Skip | null;
};

export type Episode = {
  id: string;
  name?: string | null;
  name_english?: string | null;
  ordinal: number;
  opening?: Skip | null;
  ending?: Skip | null;
  preview?: Poster | null;
  hls_480?: string | null;
  hls_720?: string | null;
  hls_1080?: string | null;
  duration?: number | null;
  sort_order?: number;
  release_id?: number;
  label?: string;
  sources?: EpisodeSource[];
  preview_is_poster?: boolean;
  voiceId?: string;
  voiceName?: string;
};

export type Release = {
  id: number;
  provider?: AnimeProvider;
  provider_id?: number;
  primary_alias?: string;
  primary_id?: number;
  catalog_rating?: number | null;
  alias?: string;
  year?: number | null;
  name: { main: string; english?: string | null; alternative?: string | null };
  type?: Named | null;
  season?: Named | null;
  poster?: Poster | null;
  publish_day?: { value?: number | null; description?: string | null } | null;
  fresh_at?: string;
  is_ongoing?: boolean;
  age_rating?: Age | null;
  description?: string | null;
  notification?: string | null;
  episodes_total?: number | null;
  external_player?: string | null;
  is_in_production?: boolean;
  is_blocked_by_geo?: boolean;
  is_blocked_by_copyrights?: boolean;
  added_in_users_favorites?: number;
  average_duration_of_episode?: number | null;
  genres?: Genre[];
  episodes?: Episode[];
  shikimori?: { id?: number | null; rating?: number | null; votes?: number | null; url?: string | null } | null;
  mal?: { id?: number | null; rating?: number | null; votes?: number | null } | null;
};

export type CatalogFilter = {
  provider?: AnimeProvider;
  page?: number;
  limit?: number;
  sorting?: string;
  genres?: string;
  years?: string;
  types?: string;
  seasons?: string;
  status?: string;
  search?: string;
};

export type CatalogResult = { items: Release[]; pages: number; total: number | null; hasMore?: boolean };

export type RefItem = { value: string; description?: string; label?: string };

const cache = new Map<string, { data: unknown; time: number }>();
const pending = new Map<string, Promise<unknown>>();

async function apiGet<T>(path: string, fresh = false): Promise<T> {
  const p = path.startsWith("/") ? path : `/${path}`;
  const cached = cache.get(p);
  if (!fresh && cached && Date.now() - cached.time < 60_000) return cached.data as T;
  if (!fresh && pending.has(p)) return pending.get(p) as Promise<T>;
  const request = (async () => {
    const gateway = await getGateway();
    const urls = gateway ? [`/api/kurenai/libria${p}`] : HOSTS.map((host) => `${host}/api/v1${p}`);
    for (const url of urls) {
      const controller = new AbortController();
      const timer = window.setTimeout(() => controller.abort(), gateway ? 18_000 : 9000);
      try {
        const response = await fetch(url, { signal: controller.signal, headers: { Accept: "application/json" }, credentials: "omit", cache: fresh ? "no-store" : "default" });
        if (!response.ok) continue;
        const data = await response.json() as T;
        cache.set(p, { data, time: Date.now() });
        if (cache.size > 120) cache.delete(cache.keys().next().value!);
        return data;
      } catch { /* Try the alternate origin; never send streams to a public proxy. */ }
      finally { clearTimeout(timer); }
    }
    throw new Error("Не удалось подключиться. Проверьте интернет и повторите попытку.");
  })();
  pending.set(p, request);
  try { return await request; } finally { if (pending.get(p) === request) pending.delete(p); }
}

function asList(data: unknown): Release[] {
  if (Array.isArray(data)) return data as Release[];
  if (data && typeof data === "object" && Array.isArray((data as { data?: unknown }).data)) {
    return (data as { data: Release[] }).data;
  }
  return [];
}

export function img(p?: Poster | null, size: "src" | "preview" | "thumbnail" = "src"): string {
  const path =
    p?.optimized?.[size] || p?.[size] || p?.optimized?.src || p?.src || p?.optimized?.preview || p?.preview;
  if (!path) return "";
  return httpsUrl(path, IMG);
}

export function titleOf(r: Pick<Release, "name">): string {
  return r.name?.main || r.name?.english || "Без названия";
}

export function ratingOf(r: Release): number | null {
  const v = r.catalog_rating ?? r.shikimori?.rating ?? r.mal?.rating ?? null;
  return typeof v === "number" && v > 0 ? v : null;
}

export function embedOf(ext?: string | null): string | null {
  return httpsUrl(ext) || null;
}

export function streamOf(ep: Episode, q: "1080" | "720" | "480"): string | null {
  const order: ("1080" | "720" | "480")[] =
    q === "1080" ? ["1080", "720", "480"] : q === "720" ? ["720", "1080", "480"] : ["480", "720", "1080"];
  for (const k of order) {
    const url = ep[`hls_${k}` as const];
    if (url) return url;
  }
  return null;
}

export function qualities(ep: Episode): ("1080" | "720" | "480")[] {
  return (["1080", "720", "480"] as const).filter((k) => Boolean(ep[`hls_${k}` as const]));
}

function qs(f: CatalogFilter): string {
  const p: string[] = [`page=${f.page ?? 1}`, `limit=${f.limit ?? 24}`];
  if (f.sorting) p.push(`f[sorting]=${encodeURIComponent(f.sorting)}`);
  if (f.genres) p.push(`f[genres]=${encodeURIComponent(f.genres)}`);
  if (f.years) p.push(`f[years]=${encodeURIComponent(f.years)}`);
  if (f.types) p.push(`f[types]=${encodeURIComponent(f.types)}`);
  if (f.seasons) p.push(`f[seasons]=${encodeURIComponent(f.seasons)}`);
  if (f.status) p.push(`f[production_statuses]=${encodeURIComponent(f.status)}`);
  if (f.search) p.push(`f[search]=${encodeURIComponent(f.search)}`);
  return p.join("&");
}

export async function getLatest(limit = 20): Promise<Release[]> {
  return asList(await apiGet(`/anime/releases/latest?limit=${limit}`));
}

export async function getRecommended(limit = 14): Promise<Release[]> {
  return asList(await apiGet(`/anime/releases/recommended?limit=${limit}`));
}

export async function getRandom(): Promise<Release | null> {
  const list = asList(await apiGet(`/anime/releases/random`));
  return list[0] ?? null;
}

export async function getRelease(id: number | string, fresh = false): Promise<Release> {
  if (typeof id === "number" && id >= YUMMY_ID_OFFSET) {
    const { getYummyRelease } = await import("./lib/yummy");
    return getYummyRelease(id - YUMMY_ID_OFFSET, fresh);
  }
  const raw = await apiGet<Release>(`/anime/releases/${encodeURIComponent(String(id))}`, fresh);
  if (!raw || !Number.isFinite(raw.id) || !raw.name) throw new Error("Не удалось прочитать этот релиз.");
  return {
    ...raw, provider: "libria", provider_id: raw.id,
    episodes: (raw.episodes || []).map((episode) => ({
      ...episode, ordinal: Number(episode.ordinal),
      hls_480: httpsUrl(episode.hls_480, IMG) || null,
      hls_720: httpsUrl(episode.hls_720, IMG) || null,
      hls_1080: httpsUrl(episode.hls_1080, IMG) || null,
    })).filter((episode) => Number.isFinite(episode.ordinal)),
  };
}

export async function refreshEpisode(release: Release, ordinal: number): Promise<Episode> {
  const fresh = await getRelease(release.primary_id || release.id, true);
  if (fresh.is_blocked_by_geo || fresh.is_blocked_by_copyrights) throw new Error("Просмотр ограничен для этого релиза.");
  const episode = fresh.episodes?.find((item) => item.ordinal === ordinal);
  if (!episode) throw new Error("Выбранная серия больше недоступна.");
  return episode;
}

export async function searchReleases(query: string, onPartial?: (items: Release[]) => void): Promise<Release[]> {
  const { searchYummy } = await import("./lib/yummy");
  const partial: Release[][] = [[], []];
  const collect = () => {
    const merged: Release[] = [];
    for (let index = 0; index < Math.max(...partial.map((items) => items.length)); index++) {
      for (const items of partial) if (items[index]) merged.push(items[index]);
    }
    return merged;
  };
  const completed = (index: number, items: Release[]) => {
    partial[index] = items;
    if (items.length) onPartial?.(collect());
    return items;
  };
  const results = await Promise.allSettled([
    apiGet(`/app/search/releases?query=${encodeURIComponent(query)}`).then(asList).then((items) => completed(0, items)),
    searchYummy(query).then((items) => completed(1, items)),
  ]);
  if (results.every((result) => result.status === "rejected")) throw new Error("Поиск временно недоступен.");
  return collect();
}

export async function getCatalog(f: CatalogFilter): Promise<CatalogResult> {
  if (f.provider === "yummy") {
    const { getYummyCatalog } = await import("./lib/yummy");
    return getYummyCatalog(f);
  }
  const data = await apiGet<unknown>(`/anime/catalog/releases?${qs(f)}`);
  if (Array.isArray(data)) return { items: data as Release[], pages: 1, total: data.length };
  const obj = data as { data?: Release[]; meta?: { pagination?: { total_pages?: number; total?: number } } };
  return {
    items: obj.data ?? [],
    pages: obj.meta?.pagination?.total_pages ?? 1,
    total: obj.meta?.pagination?.total ?? obj.data?.length ?? 0,
  };
}

export async function getGenres(provider: AnimeProvider = "libria"): Promise<Genre[]> {
  if (provider === "yummy") {
    const { getYummyGenres } = await import("./lib/yummy");
    return getYummyGenres();
  }
  const data = await apiGet<unknown>(`/anime/catalog/references/genres`);
  return Array.isArray(data) ? (data as Genre[]) : [];
}

export async function getYears(): Promise<number[]> {
  const data = await apiGet<unknown>("/anime/catalog/references/years");
  return Array.isArray(data) ? data.filter((item): item is number => typeof item === "number").sort((a, b) => b - a) : YEARS;
}

export async function getSchedule(): Promise<{ release: Release }[]> {
  const data = await apiGet<unknown>(`/anime/schedule/week`);
  if (!Array.isArray(data)) return [];
  return data as { release: Release }[];
}

export const SORTS: RefItem[] = [
  { value: "FRESH_AT_DESC", label: "Свежие" },
  { value: "RATING_DESC", label: "Рейтинг" },
  { value: "YEAR_DESC", label: "Новые" },
  { value: "YEAR_ASC", label: "Старые" },
];

export const TYPES: RefItem[] = [
  { value: "TV", description: "ТВ" },
  { value: "MOVIE", description: "Фильм" },
  { value: "ONA", description: "ONA" },
  { value: "OVA", description: "OVA" },
  { value: "SPECIAL", description: "Спешл" },
];

export const SEASONS: RefItem[] = [
  { value: "winter", description: "Зима" },
  { value: "spring", description: "Весна" },
  { value: "summer", description: "Лето" },
  { value: "autumn", description: "Осень" },
];

export const STATUSES: RefItem[] = [
  { value: "IS_IN_PRODUCTION", description: "В озвучке" },
  { value: "IS_NOT_IN_PRODUCTION", description: "Завершено" },
];

export const YEARS = [2026, 2025, 2024, 2023, 2022, 2021, 2020, 2019, 2018, 2017, 2016, 2015, 2014, 2013, 2012, 2010, 2004];

export function fmtTime(sec: number): string {
  if (!Number.isFinite(sec) || sec < 0) return "0:00";
  const s = Math.floor(sec % 60);
  const m = Math.floor(sec / 60) % 60;
  const h = Math.floor(sec / 3600);
  const pad = (n: number) => String(n).padStart(2, "0");
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
}
