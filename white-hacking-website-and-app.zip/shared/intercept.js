// Shared stream interceptors — imported by BOTH the Node gateway (server/gateway.mjs)
// and the browser client (src/lib/resolveMedia.ts). No DOM, no Node-only APIs.
// `fetcher` is fetch-compatible: (url, init) => { ok, status, text(), json() }.
// Returns direct manifest/file URLs that OUR <video> plays. No iframes, ever.

export const BROWSER_UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
export const YUMMY_ORIGIN = "https://site.yummyani.me";

// ---------------- base64 / caesar ----------------

export function b64ToBytes(s) {
  s = String(s).replace(/-/g, "+").replace(/_/g, "/");
  while (s.length % 4) s += "=";
  if (typeof Buffer !== "undefined") return new Uint8Array(Buffer.from(s, "base64"));
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

export function b64ToUtf8(s) {
  return new TextDecoder().decode(b64ToBytes(s));
}

export function utf8ToB64(s) {
  if (typeof Buffer !== "undefined") return Buffer.from(s, "utf8").toString("base64");
  const bytes = new TextEncoder().encode(s);
  let bin = "";
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin);
}

export function caesarShift(text, shift) {
  return String(text).replace(/[A-Za-z]/g, (ch) => {
    const base = ch <= "Z" ? 65 : 97;
    return String.fromCharCode(base + (((ch.charCodeAt(0) - base + shift) % 26 + 26) % 26));
  });
}

// ---------------- cvh (CdnVideoHub) ----------------

const CVH_API = "https://plapi.cdnvideohub.com/api/v1/player/sv";
const CVH_MP4 = {
  mpegTinyUrl: 144,
  mpegLowestUrl: 240,
  mpegLowUrl: 360,
  mpegMediumUrl: 480,
  mpegHighUrl: 720,
  mpegFullHdUrl: 1080,
  mpegQhdUrl: 1440,
  mpeg2kUrl: 2048,
  mpeg4kUrl: 2160,
};

export function parseCvhTag(html) {
  const m = html.match(/<video-player\b([^>]*)>/is);
  if (!m) return null;
  const tag = m[1];
  const attr = (n) => tag.match(new RegExp(`${n}=["']([^"']+)["']`, "i"))?.[1] ?? null;
  const pub = attr("data-publisher-id");
  const aggr = attr("data-aggregator");
  const id = attr("data-title-id");
  return pub && aggr && id ? { pub, aggr, id } : null;
}

function normStudio(s) {
  return String(s || "")
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]/gu, "");
}

export async function interceptCvh(fetcher, embedUrl) {
  const pageRes = await fetcher(embedUrl, {
    headers: { Referer: `${YUMMY_ORIGIN}/`, Accept: "text/html,*/*" },
  });
  if (!pageRes.ok) throw new Error(`CVH page ${pageRes.status}`);
  const html = await pageRes.text();
  let creds = parseCvhTag(html);
  if (!creds) {
    // The page is a thin shell that loads a module script holding the params.
    const jsPath = html.match(/<script[^>]+type=["']module["'][^>]*src=["']([^"']+)["']/i)?.[1];
    if (!jsPath) throw new Error("CVH params not found");
    const jsRes = await fetcher(new URL(jsPath, embedUrl).href, {
      headers: { Referer: embedUrl, Accept: "*/*" },
    });
    if (!jsRes.ok) throw new Error("CVH script unreachable");
    const js = await jsRes.text();
    const pub = js.match(/"data-publisher-id":\s?"(\d+)"/)?.[1];
    const aggr = js.match(/"data-aggregator":\s?"([^"]+)"/)?.[1];
    const id = new URL(embedUrl).searchParams.get("anime_id") || "";
    if (!pub || !aggr || !id) throw new Error("CVH params not found");
    creds = { pub, aggr, id };
  }
  const plRes = await fetcher(
    `${CVH_API}/playlist?pub=${encodeURIComponent(creds.pub)}&aggr=${encodeURIComponent(creds.aggr)}&id=${encodeURIComponent(creds.id)}`,
    { headers: { Referer: embedUrl, Accept: "application/json" } },
  );
  if (!plRes.ok) throw new Error(`CVH playlist ${plRes.status}`);
  const items = (await plRes.json())?.items || [];
  if (!items.length) throw new Error("CVH playlist empty");
  const q = new URL(embedUrl).searchParams;
  const wantEp = parseInt(q.get("episode") || "", 10);
  const wantStudio = q.get("dubbing") || q.get("dubbing_code") || "";
  let pool = items.filter((i) => !Number.isFinite(wantEp) || Number(i.episode) === wantEp);
  if (!pool.length) pool = items;
  const w = normStudio(wantStudio);
  const item =
    pool.find((i) => w && normStudio(i.voiceStudio) === w) ||
    pool.find((i) => {
      const s = normStudio(i.voiceStudio);
      return w && s && (w.includes(s) || s.includes(w));
    }) ||
    pool.find((i) => Number(i.season) === 1) ||
    pool[0];
  const vRes = await fetcher(`${CVH_API}/video/${item.vkId}`, {
    headers: { Referer: embedUrl, Accept: "application/json" },
  });
  if (!vRes.ok) throw new Error(`CVH video ${vRes.status}`);
  const data = await vRes.json();
  const sources = data?.sources || {};
  const mp4 = {};
  for (const [k, v] of Object.entries(sources)) {
    if (typeof v === "string" && v.startsWith("http") && CVH_MP4[k]) mp4[CVH_MP4[k]] = v;
  }
  if (!sources.hlsUrl && !sources.dashUrl && !sources.dashManifestUrl && !Object.keys(mp4).length) {
    throw new Error("CVH returned no streams");
  }
  return {
    hls: sources.hlsUrl || null,
    dash: sources.dashUrl || sources.dashManifestUrl || null,
    mp4,
    thumb: data?.thumbUrl || null,
    duration: data?.duration ?? null,
    studio: item.voiceStudio || null,
  };
}

// ---------------- alloha ----------------

export const ALLOHA_ACCEPTS_PREFIX = "9badb2c5dd28e9cd0bed84e7391523d9d308a48b690428dae6049233218645d9";
export const ALLOHA_GUARD =
  "pXzvbyDGLYyB6VkwsWZDv3iMKZtsXNzpzRyxZUcsKHXxsSeaYakbo3hw9mBFRc5VQTpqAX6BW8aDEqyLaHYcXSQiV6KHYTVTK6MYRphNAy5sBjtrevqkDzKmLqNdfMZGEU9NELjmtKfZy3RNGzCd767sNh1mXEj4tCcvqndHtzmwAbZNkhm4ghDEasodotMBewypNQ56uotJAQGX11csfeRfBAPk8DcUWWkkqzxca8vbnEw12vUFbBzT6hz8ZB3F3dzUhUXoL2cr1WM1bXQArRCS1MUNMz3X5WDMMQoZKxj2AMTRqp7QQX4dDB9B7VzEZTmyFULhm1AcHHMkoMvSVvKYoBoAKLycYAgMHeD4ECJcGEAGpnkJhrV57zQ7";

function allohaZy(zj) {
  const zs = zj.length;
  if (zs <= 0) return zj;
  let zb = 0;
  while ((1 << zb) < zs) zb++;
  const zkOf = (q1) => {
    if (q1 === 0) return 0;
    let q2 = 1;
    while (q1 > 1) {
      q2++;
      q1 >>= 1;
    }
    return q2;
  };
  const counts = new Array(zb + 1).fill(0);
  for (let zl = 0; zl < zs; zl++) counts[zkOf(zl)]++;
  const zp = new Array(zb + 1);
  let zf = 0;
  for (let zh = zb; zh >= 0; zh--) {
    zp[zh] = zj.substr(zf, counts[zh]);
    zf += counts[zh];
  }
  const idx = new Array(zb + 1).fill(0);
  const zw = new Array(zs);
  for (let zv = 0; zv < zs; zv++) {
    const zk = zkOf(zv);
    zw[zv] = zp[zk][idx[zk]++];
  }
  return zw.join("");
}

function allohaZz(zj) {
  const zs = zj.length;
  if (zs <= 0) return zj;
  let zb = 0;
  while ((1 << zb) < zs) zb++;
  const zkOf = (q0) => {
    if (q0 === 0) return zb;
    let q1 = 0;
    while ((1 & q0) === 0) {
      q1++;
      q0 >>= 1;
    }
    return q1;
  };
  const counts = new Array(zb + 1).fill(0);
  for (let zl = 0; zl < zs; zl++) counts[zkOf(zl)]++;
  const zp = new Array(zb + 1);
  let zf = 0;
  for (let zh = 0; zh <= zb; zh++) {
    zp[zh] = zj.substr(zf, counts[zh]);
    zf += counts[zh];
  }
  const idx = new Array(zb + 1).fill(0);
  const out = new Array(zs);
  for (let zw = 0; zw < zs; zw++) {
    const zv = zkOf(zw);
    out[zw] = zp[zv][idx[zv]++];
  }
  return out.join("");
}

function allohaIsPrime(n) {
  if (n < 2) return false;
  if (n % 2 === 0) return n === 2;
  for (let w = 3; w * w <= n; w += 2) if (n % w === 0) return false;
  return true;
}

function allohaZ9(zj) {
  const zs = zj.length;
  if (zs <= 1) return zj;
  let w = Math.max(2, zs + 1);
  while (!allohaIsPrime(w)) w++;
  const zk = w;
  const visited = new Array(zs).fill(false);
  const order = [];
  let zp = 0;
  while (order.length < zs) {
    zp = (zp + 2) % zk;
    if (zp < zs && !visited[zp]) {
      order.push(zp);
      visited[zp] = true;
    }
  }
  const out = new Array(zs);
  for (let zh = 0; zh < zs; zh++) out[order[zh]] = zj[zh];
  return out.join("");
}

export async function allohaBorth(viewporti, sha256hex) {
  const transformed = allohaZ9(allohaZz(allohaZy(viewporti)));
  return `${await sha256hex("fingerprint-alloha")}|${transformed}`;
}

export function parseAllohaPage(html) {
  const viewporti = html.match(/name=["']viewporti["']\s+content=["']([^"']+)["']/i)?.[1];
  if (!viewporti) throw new Error("Alloha page has no signature seed");
  const fl =
    html.match(/fileList\s*=\s*JSON\.parse\('([^']+)'\);/s)?.[1] ??
    html.match(/fileList\s*=\s*JSON\.parse\("(.+?)"\);/s)?.[1];
  if (!fl) throw new Error("Alloha page has no file list");
  return { viewporti, fileList: JSON.parse(fl) };
}

export function allohaFileId(fileList, { translation, season, episode }) {
  const all = fileList?.all;
  const trKey = translation != null && translation !== "" ? `t${translation}` : null;
  if (all && trKey && season > 0 && episode > 0) {
    const id = all?.[String(season)]?.[String(episode)]?.[trKey]?.id;
    if (id) return String(id);
  }
  if (all && trKey) {
    for (const section of ["theatrical", "directors"]) {
      const group = all?.[section]?.[trKey];
      if (group && typeof group === "object") {
        for (const v of Object.values(group)) {
          if (v?.id) return String(v.id);
        }
      }
    }
  }
  const active = fileList?.active?.id;
  if (active) return String(active);
  throw new Error("Alloha file id not found");
}

export async function interceptAlloha(fetcher, embedUrl, sha256hex) {
  const u = new URL(embedUrl);
  const token = u.searchParams.get("token") || "";
  const translation = u.searchParams.get("translation") || "";
  const season = parseInt(u.searchParams.get("season") || "", 10) || 0;
  const episode = parseInt(u.searchParams.get("episode") || "", 10) || 0;
  if (!token) throw new Error("Alloha link has no token");
  const sep = embedUrl.includes("?") ? "&" : "?";
  const pageRes = await fetcher(`${embedUrl}${sep}_r=${Date.now()}`, {
    headers: { Referer: `${YUMMY_ORIGIN}/`, Accept: "text/html,*/*", "Upgrade-Insecure-Requests": "1" },
  });
  if (!pageRes.ok) throw new Error(`Alloha page ${pageRes.status}`);
  const { viewporti, fileList } = parseAllohaPage(await pageRes.text());
  const fileId = allohaFileId(fileList, { translation, season, episode });
  const borth = await allohaBorth(viewporti, sha256hex);
  const origin = `${u.protocol}//${u.host}`;
  const body = new URLSearchParams({
    token,
    av1: "false",
    autoplay: "0",
    audio: translation || "66",
  });
  const bnsiRes = await fetcher(`${origin}/bnsi/movies/${fileId}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      Referer: embedUrl,
      Origin: origin,
      "X-Requested-With": "XMLHttpRequest",
      Borth: borth,
      Accept: "application/json, text/plain, */*",
    },
    body: body.toString(),
  });
  if (!bnsiRes.ok) throw new Error(`Alloha videos ${bnsiRes.status}`);
  const data = await bnsiRes.json();
  const qualities = {};
  const voices = [];
  for (const src of data?.hlsSource || []) {
    if (src.label) voices.push(src.label);
    for (const [q, v] of Object.entries(src.quality || {})) {
      const first = String(v).split(" or ")[0].trim();
      if (first && !qualities[q]) qualities[q] = first;
    }
    for (const k of ["manifest", "url", "src"]) {
      if (typeof src[k] === "string" && src[k] && !qualities.auto) {
        qualities.auto = src[k].split(" or ")[0].trim();
      }
    }
  }
  if (!Object.keys(qualities).length) throw new Error("Alloha returned no streams");
  return { qualities, voices: [...new Set(voices)], origin, referer: embedUrl };
}

// ---------------- sibnet ----------------

export function parseSibnetPage(html) {
  const m = html.match(/player\.src\{[^}]*?src:\s*"([^"]+)"/);
  if (!m) throw new Error("Sibnet file not published");
  const url = new URL(m[1], "https://video.sibnet.ru/").href;
  const parsed = new URL(url);
  if (parsed.protocol !== "https:" || !/(^|\.)video\.sibnet\.ru$/i.test(parsed.hostname) || !parsed.pathname.startsWith("/sh/")) {
    throw new Error("Sibnet file not published");
  }
  return url;
}

export async function interceptSibnet(fetcher, videoId) {
  if (!/^\d{4,10}$/.test(String(videoId))) throw new Error("Bad Sibnet id");
  const res = await fetcher(`https://video.sibnet.ru/shell.php?videoid=${videoId}`, {
    headers: { Referer: "https://video.sibnet.ru/", Accept: "text/html,*/*" },
  });
  if (!res.ok) throw new Error(`Sibnet page ${res.status}`);
  return { id: String(videoId), url: parseSibnetPage(await res.text()) };
}
