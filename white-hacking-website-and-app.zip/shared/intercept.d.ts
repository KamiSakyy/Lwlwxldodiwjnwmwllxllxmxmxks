export type FetchLike = (url: string, init?: RequestInit) => Promise<Response>;
export type Sha256Hex = (text: string) => Promise<string>;

export declare const BROWSER_UA: string;
export declare const YUMMY_ORIGIN: string;

export declare function b64ToUtf8(s: string): string;
export declare function utf8ToB64(s: string): string;
export declare function caesarShift(text: string, shift: number): string;

export declare function parseCvhTag(html: string): { pub: string; aggr: string; id: string } | null;
export declare function interceptCvh(
  fetcher: FetchLike,
  embedUrl: string,
): Promise<{
  hls: string | null;
  dash: string | null;
  mp4: Record<number, string>;
  thumb: string | null;
  duration: number | null;
  studio: string | null;
}>;

export declare const ALLOHA_ACCEPTS_PREFIX: string;
export declare const ALLOHA_GUARD: string;
export declare function allohaBorth(viewporti: string, sha256hex: Sha256Hex): Promise<string>;
export declare function parseAllohaPage(html: string): { viewporti: string; fileList: unknown };
export declare function allohaFileId(
  fileList: unknown,
  sel: { translation: string; season: number; episode: number },
): string;
export declare function interceptAlloha(
  fetcher: FetchLike,
  embedUrl: string,
  sha256hex: Sha256Hex,
): Promise<{
  qualities: Record<string, string>;
  voices: string[];
  origin: string;
  referer: string;
}>;

export declare function parseSibnetPage(html: string): string;
export declare function interceptSibnet(
  fetcher: FetchLike,
  videoId: string,
): Promise<{ id: string; url: string }>;
