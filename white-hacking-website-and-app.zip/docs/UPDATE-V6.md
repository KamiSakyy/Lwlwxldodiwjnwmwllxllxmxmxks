# All Catalogued Voices, Still One Player

## What Changed

The previous build over-filtered: only voices served by one direct provider were
listed, so most of the additional catalog appeared to vanish. Catalogued voices
are now all listed again, per anime, with real per-voice episode counts. No
provider or player names are shown to the viewer.

Playback still uses exactly one video element. Iframe embedding, a second hidden
video element, canvas capture and MediaRecorder re-encoding are all absent. When
a provider exposes a legitimate direct stream, it is played by the Kurenai
player. When it does not, the viewer gets an explicit message rather than a
hidden player.

## Voice Sources And Reality

`src/lib/yummy.ts` no longer drops entries by provider. It records the provider
for each episode's video (`aksor`, `sibnet`, `kodik`, `alloha`, `cvh`, `vk`,
`rutube`, `zedfilm`, `other`) with its reference id. `src/lib/playback.ts` groups
voices by normalized studio name, merges renamed-studio duplicates, keeps
subtitles separate, and sorts attempts by a direct-stream preference order.

Playable today:

- Primary catalog HLS (480/720/1080) — our player, direct.
- Additional catalog voices published with direct DASH/HLS/MP4 addresses —
  read from the public per-video metadata endpoint and validated against the
  catalog entry (`anime_id`, episode label, video id) before use.
- Sibnet MP4 — the address is published only on Sibnet's own page, which is
  blocked by browser CORS. The optional first-party gateway reads that page and
  returns the MP4 only if it matches the allowlist.

Not playable, and not faked: providers that require an application token or
publish only protected embeds. The user sees "У этой озвучки нет прямой
видеодорожки для нашего плеера" and can pick another voice. No traffic is
doubled and no third-party player is started to scrape frames.

## Catalog Size

No "60000+" figure is displayed anywhere. The additional catalog's own public
counts endpoint reported, during development, roughly ten thousand titles across
TV, ONA, OVA, films and specials. Voice counts are computed per anime from
actual catalog entries; some titles do list dozens of voices, others list one.

## Traffic Discipline

- One playback engine per tab; the previous engine is fully destroyed before a
  new one attaches.
- No bandwidth-test segment, no next-fragment prefetch, no DASH audio/video/text
  prefetch, no next-URL preload.
- Only the selected quality is requested. A DASH presentation's separate audio
  and video tracks are parts of one movie, not a duplicate download.
- Resolutions of the same voice are metadata, not parallel downloads.
- A full download still stops network playback first.

## Verification

The production build is checked with the supplied build tool. The voice-model
checks in «Настройки просмотра» now cover 15 deterministic cases, including that
a voice published only through an embed remains listed with its episode count
and that direct providers sort first. Sibnet resolution requires the optional
gateway; without it the message names the requirement. Real browser playback,
Android devices and measured transfer totals are not verified in this
environment.
