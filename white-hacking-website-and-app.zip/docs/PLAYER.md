# Kurenai Player

The current one-player architecture and voice coverage are described in
`docs/UPDATE-V5.md` and `docs/UPDATE-V6.md`. `docs/UPDATE-V4.md` records the
earlier orientation correction. Server deployment is in `server/README.md`.

## GPU Processing

`src/lib/enhancer.ts` contains an original three-pass WebGL 1 pipeline. It is not
Anime4K, a neural model, a CSS filter, or a promise of recovering lost detail.

1. A 3x3 bilateral filter reduces low-amplitude noise without averaging across
   strong colour boundaries.
2. A 16-tap Catmull-Rom bicubic reconstruction writes into a genuinely larger
   RGBA framebuffer. Neighbourhood clamping suppresses ringing.
3. An edge-adaptive, luma-only detail pass sharpens contours, with a local
   contrast clamp to avoid introducing bright or dark halos.

Balanced mode requests a 1.5x linear scale. Quality mode requests 2x. The actual
dimensions are limited by the GPU texture limit, shader precision and a device
memory budget. A 1920x1080 source can produce a 3840x2160 render target, but a
device with insufficient resources will receive a lower scale or original video.
The player displays measured source/output dimensions, processed-frame counts
and callback throughput, not fabricated performance figures.

Frames are uploaded with `texImage2D(video)`. `requestVideoFrameCallback` is used
where available; otherwise an animation-frame loop checks the media timestamp.
Background tabs stop rendering. GPU initialization errors, allocation errors,
context loss, inaccessible video pixels and persistently slow processing leave
the original video available. Controls and audio use the original video element.

The comparison mode renders untreated video on the left and the processed result
on the right in the same output canvas. System Picture-in-Picture displays the
original video, not the canvas. Enhancement is off by default to conserve power.

## Downloads

`src/lib/download.ts` parses the selected-quality playlist with `m3u8-parser`.
MPEG-TS H.264/AAC segments are remuxed into fragmented MP4 with `mux.js`, without
re-encoding or changing the requested quality. Compatible multiplexed fMP4 is
also supported. MP4 movie and track durations are corrected using VOD timing.
Mixed codecs/configurations, separate audio renditions, live streams and DRM
formats fail explicitly instead of producing a misleading or muted file.

Ordinary AES-128 HLS is supported only with a publicly retrievable key and
browser Web Crypto. No DRM, authorization or regional restriction is bypassed.
Master playlists must offer the requested resolution; another resolution is not
silently substituted.

There is one active download at a time, three segment requests per batch,
timeouts, retries, byte-range support, progress and cancellation. If available,
the File System Access API streams output to the user-selected file. Where the
file picker is unavailable but OPFS is supported (including modern Android
browsers), segments are written to a private temporary disk file, not collected
in RAM. The final File is offered for an explicit save action. A bounded in-memory
Blob is the last fallback. Temporary files are deleted on removal; abandoned
files older than seven days are cleaned when the next download starts. Prepared
files remain accessible in the current tab only; reload loses that session.
The UI and unload warning make that limitation explicit. Downloads contain the original selected quality;
render-time enhancement is not baked into the file.

## Mobile

The layout includes safe-area padding, bottom navigation, mobile settings sheets,
double-tap seeking, touch lock, session resume, optional opening skip, a sleep
timer and automatic next episode. Supported browsers additionally use screen
wake lock, Media Session, Picture-in-Picture and orientation lock. Unsupported
APIs are feature-detected. A viewport-filling mode substitutes for unsupported
element fullscreen, but does not claim to be OS-native fullscreen.

`public/manifest.webmanifest` and `public/sw.js` provide an installable web app
shell in production over HTTPS. Video is not silently cached. A previously
saved, browser-compatible local file can be opened from the Downloads page.
This is a PWA, not a compiled Android APK.

## Privacy Boundary

Provider names and endpoint descriptions have been removed from the product UI
and page metadata. That is presentation, not secrecy: a browser-only streaming
application exposes its resource requests in developer tools. Hiding an upstream
origin requires a separately deployed, controlled backend/media gateway. Even
such a gateway cannot make playable video impossible to inspect or copy.

## Verification

The production Vite build is checked with the supplied build tool. Public catalog
metadata and a real MPEG-TS VOD playlist were read during implementation.
Hardware-specific GPU execution, real-device installation, cross-origin playback
and complete downloads need device/browser testing; a successful build does not
prove those runtime properties.

Suggested checks in current Android Chrome, Samsung Internet, Firefox and Safari:

1. Start a real episode; change quality while playing and while paused. Position
   and play/pause intent should be preserved.
2. Enable each Enhance mode. Check that output dimensions exceed source
   dimensions, move the A/B boundary, pause and adjust both processing controls.
3. Disable WebGL or force context loss. Video must continue without the canvas.
4. Use mobile double-tap, touch lock, fullscreen and next-episode playback.
5. Download a permitted short episode at each available quality. Check video,
   sound, duration and seeking in a standalone player.
6. Cancel mid-download, disconnect the network, deny the file picker, and choose
   an unsupported stream. Partial or failed files must not be reported as saved.
7. Save the resulting file, reload, then reopen it through the local-file picker.
8. Install the production HTTPS site. Verify standalone layout and offline shell.

## Research

- https://github.com/bloc97/Anime4K
- https://developer.mozilla.org/en-US/docs/Web/API/WebGL_API/Tutorial/Animating_textures_in_WebGL
- https://developer.mozilla.org/en-US/docs/Web/API/HTMLVideoElement/requestVideoFrameCallback
- https://github.com/videojs/m3u8-parser
- https://github.com/videojs/mux.js
- https://developer.mozilla.org/en-US/docs/Web/API/File_System_API/Origin_private_file_system

The dependencies retain their own licenses. Shader code is authored in this
project; no Anime4K model weights or shaders have been copied or relabelled.