# Playback And Catalog Update

## Orientation Fix

Video frames now use an explicit top-down upload: `UNPACK_FLIP_Y_WEBGL = false`.
Only the source-video sampler in pass 1 and the original half of the comparison
normalize Y. Framebuffer-to-framebuffer passes do not invert their coordinates.

An 8x8 reference sampled with Canvas2D is compared to a GPU readback. This detects
the orientation actually used by the video decoder instead of assuming every
browser treats `texImage2D(video)` identically. Calibration waits for a frame
that is not vertically symmetric and runs once per enhancer instance.

The connection settings provide a genuine device-side regression check. A
96x64 canvas generates a video stream with red on top and blue underneath. The
normal three-pass renderer upscales it to 192x128. The test then reads both GPU
regions and checks colour and size. Unsupported captureStream, blocked video
playback, missing WebGL and timeouts are reported as failures, not successes.

## Playback Repair

- The primary adapter continues to use `/api/v1/anime/releases/{id}`.
- All stream parameters from the API are retained; no ad, authentication or
  regional parameters are removed or altered.
- The single-file build does not rely on an unavailable external worker asset.
- Native playback and HLS.js are feature-detected. Automatic native failure can
  switch to the adaptive engine and, when necessary, native compatibility mode.
- Compatibility mode prioritizes playback without a CORS-enabled video texture.
  Pixel processing is disabled in that mode rather than breaking playback.
- "Refresh link" makes a fresh release request and finds the same episode by its
  exact ordinal. It never swaps in episode 1 or a different title.
- Network, permission and decoder errors have separate diagnostics.
- An optional first-party gateway handles the application's CORS needs. It must
  actually be deployed; static Vite hosting alone does not launch Node servers.

## Additional Catalog

The second adapter uses these documented/live-checked operations:

- `GET https://api.yani.tv/anime` with `q`, `limit`, `offset`, `sort`,
  `sort_forward`, `genres`, `types`, `season`, and `status`.
- `GET /anime/{id}?need_videos=1` and `GET /anime/{id}/videos`.
- `GET /anime/genres`.

Its documented application credential is `X-Application`. Public read responses
were available during implementation, but a deployment may require its own
application token. A public token can be entered for a personal browser session;
the recommended server-side setting is `YUMMY_APPLICATION_TOKEN`.

The catalog's usage terms restrict the API to personal use unless commercial
permission is arranged. This project does not provide such permission.

IDs are namespaced with a numeric offset, preserving existing favorites and
history. Additional voice tracks are matched to primary releases only by exact
provider alias, Shikimori ID or MyAnimeList ID. No fuzzy title matching silently
assigns a sequel's video to a different season.

API video entries are grouped by their actual episode labels and by studio/player.
The exact per-episode `iframe_url` is embedded. Direct video URLs are not invented
or extracted from protected third-party players. Consequently, enhancement,
downloads, auto-next events and exact resume are only provided for directly
controlled video, not arbitrary cross-origin iframes.

No "60,000 anime" claim is displayed. The live count endpoint did not substantiate
that figure, and filtered list responses do not provide a reliable total. The
additional collection uses actual paginated results and a next-page lookahead.

## Episode Design

Both title and watch pages use the same episode gallery. It supports large
preview grids, compact lists, published episode names, duration, source availability,
search, ordering, watched toggles, pagination and spoiler hiding. Missing previews
fall back to the title poster, explicitly labelled as a poster. Missing episode
names use the real episode number; names and frame images are not fabricated.

## Verification Boundary

Production builds are checked using the provided build tool. Live metadata,
episode names, preview URLs, a real v1 HLS playlist, additional-catalog results
and actual per-episode iframe links were inspected. The GPU test runs when the
user starts it in Settings. No browser execution or real Android device runner
is available in the coding environment, so actual device playback and shader
orientation cannot be claimed as already tested here. The optional server has
not been launched in this static preview environment.