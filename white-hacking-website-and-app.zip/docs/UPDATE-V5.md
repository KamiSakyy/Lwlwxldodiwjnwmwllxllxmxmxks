# One Player, Voice-Specific Episodes

## Scope

The watch page mounts only the Kurenai video component. External iframe playback,
hidden capture players, screenshots of a second video and MediaRecorder-based
re-encoding have been removed. Public direct HLS from the primary catalog and
public direct DASH/HLS/MP4 returned by the supported additional-video metadata
endpoint feed the same HTMLVideoElement and controls.

The additional adapter reads `GET https://player.aksor.tv/api/video/{id}`.
The response supplies `id`, `anime_id`, `episode`, skip metadata, and a `qualities`
map. Those identity fields are validated against the catalog entry before any
video is loaded. No cookies, fabricated Referer, DRM bypass or secret tokens are
used. A real response and a real DASH manifest were inspected during development.

Other providers that expose only unsupported embedded players are excluded from
the playable voice list. This is deliberately narrower than promising every
voice listed by the catalog. Future adapters must obtain legitimate direct
streams and implement the same cancellation and identity checks.

## Voice Data

`src/lib/voices.ts` normalizes voice labels. Aliases for the renamed primary studio
merge into one voice; subtitles remain separate. Source mirrors are not UI
options. `src/lib/playback.ts` computes a set of episode ordinals for each voice.

Watch and title pages, gallery counts, next/previous controls and auto-next all
use `episodesForVoice`, not the union of all episodes. If a voice switch retains
the current episode, the number stays the same. If it is unavailable, an explicit
user switch opens that voice's saved or first published episode and displays a
notice. A stale episode URL is never silently played as a different episode.

Progress and watched state are keyed by release, voice and episode. Old history
and source-specific URLs migrate to the normalized voice identity.

## Stability

`SingleMediaSession` owns a single media engine. Its lifetime is keyed by release,
voice, episode and selected quality, not by mutable metadata objects or UI state.
Loading additional voices cannot tear down active playback. Creation is deferred
one task so React StrictMode cleanup cancels an unused setup before it requests
a manifest. A serial coordinator waits for the previous engine's destruction
before another session attaches to a video element.

When a direct primary stream exhausts recovery and a published direct mirror for
the exact same voice/episode exists, one sequential failover may run. It is not
attempted for access-denied responses. The old session is destroyed first and
the playback position is retained; the voice is never silently replaced.

HLS.js loads the manifest only on the initial media attachment. Error recovery
must not request the manifest again via the attachment event. One media recovery
and one explicit post-policy network recovery are bounded. Offline state waits
for the browser's online event instead of repeatedly reloading the source.

The old fixed 20-second spinner timeout is removed. A decoded, buffered video
that makes no progress for 90 seconds can become a terminal error. Network
loaders own network timeouts, including long valid DASH segments. The gateway
uses an inactivity deadline reset by streamed chunks, not a fixed duration limit.
Buffering normally does not mean a playback error.
All fatal cases save position and release their media engine. A retry resolves
fresh metadata and resumes only that same voice and episode.

## Traffic

- One video element and one active playback engine per tab.
- No external iframe and no simultaneously running capture player.
- HLS bandwidth-test segment and next-fragment prefetch are disabled.
- DASH audio/video/text prefetch and next-URL preload are disabled.
- Only the selected quality is requested; DASH's separate audio and video tracks
  are complementary parts of that single presentation, not duplicate movies.
- Target buffer: 24 seconds; individual long segments can exceed that target.
- Paused adaptive playback does not fetch additional segments. A request already
  in flight may finish; native fallback is governed by the browser's buffering.
- Metadata is requested for the selected episode, not every quality or voice.
- A full download explicitly stops network playback first. Watching and saving
  are separate transfers; previously viewed bytes are not claimed to be free.
- Quality switches, seeks and genuine network retries may re-request a segment.
  No claim of exactly zero overhead or universally uninterrupted service is made.

## DASH And Gateway

Shaka is the DASH engine under the existing Kurenai UI, not a second visible
player. Public manifests with separate audio/video are played without transcoding.
The first-party gateway can relay allowlisted primary and additional CDN paths.
It rewrites a DASH root BaseURL so relative segment templates resolve correctly;
the client's request filter relays each request once. Redirects remain validated.
Server bandwidth includes inbound and outbound transfer; user traffic receives
one video. A static frontend build does not deploy this server automatically.

Primary HLS-to-MP4 downloading is retained. Offline export of DASH's separate
tracks is not implemented; the UI does not offer a fake file for that format.

## Checks

The build is checked with the supplied production build tool. Connection settings
include a real GPU orientation check and 12 deterministic, no-network voice-model
checks. These checks run when requested in the browser and do not fabricate a
passing status. Target-device continuous playback and measured transfer totals
must still be verified on actual browsers; this environment has no browser runner.

Suggested regression cases: change tabs/settings during playback; let additional
metadata arrive mid-episode; switch repeatedly between two voices with unequal
episode counts; pause and resume; disconnect and reconnect; change quality while
paused; start a download during playback; cancel a download; follow a legacy URL.