# UPDATE-V7 — stream interception into our own player

## What changed

One shared interceptor module (`shared/intercept.js`, plain JS, zero deps) is
used by BOTH the Node gateway and the browser client:

- **Kodik** — embed page → `urlParams` + video id/hash/type → player JS →
  dynamic endpoint (`url:atob(...)`) → POST signatures → per-quality links.
  Encrypted links are Caesar+base64 decoded (shift brute-forced). Result: direct
  HLS manifests (`…/720.mp4:hls:manifest.m3u8`) per quality + translation title
  + opening/ending timecodes. No Kodik API token needed.
- **Alloha** — iframe page → `viewporti` meta + `fileList` JSON → file id →
  `Borth` signature (`SHA256("fingerprint-alloha")` + Zy/Zz/Z9 transpositions,
  ported 1:1) → `POST {origin}/bnsi/movies/{id}` → `hlsSource` quality map.
  Result: direct HLS manifests per quality + required player headers.
- **CVH** — `iframeCVH.html` → `<video-player>` attrs (pub/aggr/title id) →
  `plapi.cdnvideohub.com` playlist → episode+studio match → video API →
  HLS + DASH + MP4 sources.
- **Sibnet** — shell page → plain MP4 (moved into the shared module too).
- **Aksor** — unchanged (public JSON API with direct DASH).

All intercepted streams play in OUR `<video>` element (hls.js / shaka / native).
No iframes, no hidden second players, no canvas capture, no re-encoding —
one video element, one network session, no duplicated traffic.

## Server-first, direct fallback

- With the gateway deployed, the browser calls
  `/api/kurenai/resolve/{kodik,alloha,cvh}?url=<embed>` and plays the returned
  manifests through `/api/kurenai/media` (same-origin, CORS-free, with the
  Origin/Referer/guards each CDN demands — notably Alloha's VK-Video edges,
  which 403 without them).
- Without the gateway, the browser runs the SAME interceptors itself
  (`src/lib/proxyFetch.ts` carries only the tiny page/API responses through a
  public CORS proxy chain; video bytes always stream direct, exactly once).

## Player UI cleanup

The player top bar now shows only the episode label. Brand wordmark, voice
duplication and the Enhance badge were removed from the chrome (Enhance state
lives in settings). No provider/player names anywhere in the UI — the viewer
only ever picks a voice (dub studio).

## Verification

- `npm run build` passes (vite singlefile).
- Settings → voice checks now cover 17 cases incl. Kodik link crypto roundtrip
  and Kodik page parsing on a fixture (no network).
- Yummy catalog, search, genres and per-voice episode lists are untouched —
  nothing was removed; unresolvable voices fail with an explicit message
  instead of a fake player.
- Live upstream behavior (Kodik endpoint rotation, Alloha/CVH markup drift)
  must be re-verified on a real device with network access; resolvers fail
  loudly with provider-specific errors when markup changes.
