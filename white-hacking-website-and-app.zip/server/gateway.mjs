import { createServer } from "node:http";
import { createReadStream } from "node:fs";
import { stat } from "node:fs/promises";
import { Readable, Transform } from "node:stream";
import { pipeline } from "node:stream/promises";
import { fileURLToPath } from "node:url";
import { extname, resolve, sep } from "node:path";
import { createHash } from "node:crypto";
import { DOMParser, XMLSerializer } from "@xmldom/xmldom";
import { interceptCvh, interceptAlloha, BROWSER_UA } from "../shared/intercept.js";

const root = resolve(fileURLToPath(new URL("../dist/", import.meta.url)));
const port = Number(process.env.PORT) || 8080;
const applicationToken = process.env.YUMMY_APPLICATION_TOKEN || "";
const rate = new Map();
const activeMedia = new Map();
const types = { ".html": "text/html; charset=utf-8", ".js": "application/javascript", ".css": "text/css", ".svg": "image/svg+xml", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp", ".webmanifest": "application/manifest+json" };

const MEDIA_HOSTS = [
  { re: /(^|\.)libria\.fun$/i, path: /^\/videos\// },
  { re: /(^|\.)takehost-cdn\.aksor\.tv$/i, path: /^\/static\d*\/video\// },
  { re: /(^|\.)video\.sibnet\.ru$/i, path: /^\/sh\// },
  { re: /(^|\.)okcdn\.ru$/i },
  { re: /(^|\.)vkvideo\.cloud$/i },
  { re: /(^|\.)stloadi\.live$/i },
];

function sendJson(response, status, data) {
  response.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" });
  response.end(JSON.stringify(data));
}

function allowedMedia(value) {
  const url = new URL(value);
  if (url.protocol !== "https:" || url.username || url.password || (url.port && url.port !== "443")) throw new Error("Invalid media URL");
  const ok = MEDIA_HOSTS.some(({ re, path }) => re.test(url.hostname) && (!path || path.test(url.pathname)));
  if (!ok) throw new Error("Media host is not allowed");
  return url;
}

function isAllohaMedia(url) {
  return /(^|\.)(vkvideo\.cloud|stloadi\.live)$/i.test(url.hostname);
}

function mediaLink(value, base, extra) {
  if (value.startsWith("data:")) return value;
  const url = allowedMedia(new URL(value, base).href);
  let out = `/api/kurenai/media?url=${encodeURIComponent(url.href)}`;
  if (extra?.origin && isAllohaMedia(url)) out += `&origin=${encodeURIComponent(extra.origin)}`;
  if (extra?.referer && isAllohaMedia(url)) out += `&referer=${encodeURIComponent(extra.referer)}`;
  return out;
}

function rewriteManifest(text, base, extra) {
  return text.split(/\r?\n/).map((line) => {
    if (!line.trim()) return line;
    if (line.startsWith("#")) return line.replace(/URI="([^"]+)"/g, (_, value) => `URI="${mediaLink(value, base, extra)}"`);
    return mediaLink(line.trim(), base, extra);
  }).join("\n");
}

function rewriteDash(content, original) {
  if (/<!DOCTYPE|<!ENTITY/i.test(content)) throw new Error("Unsafe manifest");
  const document = new DOMParser().parseFromString(content, "application/xml");
  const rootEl = document.documentElement;
  if (!rootEl || rootEl.localName !== "MPD") throw new Error("Invalid DASH manifest");
  const bases = [];
  for (let node = rootEl.firstChild; node; node = node.nextSibling) {
    if (node.nodeType === 1 && node.localName === "BaseURL") bases.push(node);
  }
  if (!bases.length) {
    const base = document.createElementNS(rootEl.namespaceURI, "BaseURL");
    base.textContent = new URL(".", original).href;
    rootEl.insertBefore(base, rootEl.firstChild);
  } else {
    for (const base of bases) base.textContent = allowedMedia(new URL(base.textContent.trim(), original).href).href;
  }
  return new XMLSerializer().serializeToString(document);
}

async function limitedText(response, maximum) {
  if (!response.body) return "";
  const chunks = [];
  let size = 0;
  for await (const chunk of response.body) {
    size += chunk.byteLength;
    if (size > maximum) throw new Error("Upstream response is too large");
    chunks.push(Buffer.from(chunk));
  }
  return Buffer.concat(chunks).toString("utf8");
}

async function media(request, response, address, client) {
  if ((activeMedia.get(client) || 0) >= 8) { sendJson(response, 429, { error: "Too many media requests" }); return; }
  activeMedia.set(client, (activeMedia.get(client) || 0) + 1);
  const controller = new AbortController();
  let timeout = setTimeout(() => controller.abort(), 25_000);
  const activity = () => { clearTimeout(timeout); timeout = setTimeout(() => controller.abort(), 35_000); };
  const closed = () => { if (!response.writableEnded) controller.abort(); };
  response.on("close", closed);
  try {
    let url = allowedMedia(address.searchParams.get("url") || "");
    const extra = { origin: address.searchParams.get("origin") || "", referer: address.searchParams.get("referer") || "" };
    const headers = { Accept: "*/*", "Accept-Encoding": "identity", "User-Agent": BROWSER_UA };
    if (isAllohaMedia(url)) {
      headers.Origin = extra.origin || "https://alloha.yani.tv";
      headers.Referer = extra.referer || "https://alloha.yani.tv/";
      headers["Accepts-Controls"] = "9badb2c5dd28e9cd0bed84e7391523d9d308a48b690428dae6049233218645d9";
      headers.Authorizations = "Bearer pXzvbyDGLYyB6VkwsWZDv3iMKZtsXNzpzRyxZUcsKHXxsSeaYakbo3hw9mBFRc5VQTpqAX6BW8aDEqyLaHYcXSQiV6KHYTVTK6MYRphNAy5sBjtrevqkDzKmLqNdfMZGEU9NELjmtKfZy3RNGzCd767sNh1mXEj4tCcvqndHtzmwAbZNkhm4ghDEasodotMBewypNQ56uotJAQGX11csfeRfBAPk8DcUWWkkqzxca8vbnEw12vUFbBzT6hz8ZB3F3dzUhUXoL2cr1WM1bXQArRCS1MUNMz3X5WDMMQoZKxj2AMTRqp7QQX4dDB9B7VzEZTmyFULhm1AcHHMkoMvSVvKYoBoAKLycYAgMHeD4ECJcGEAGpnkJhrV57zQ7";
    } else if (/(^|\.)okcdn\.ru$/i.test(url.hostname)) {
      headers.Referer = "https://yummyani.me/";
    }
    if (request.headers.range && /^bytes=\d+-\d*$/.test(request.headers.range)) headers.Range = request.headers.range;
    let upstream;
    for (let redirects = 0; redirects < 4; redirects++) {
      upstream = await fetch(url, { signal: controller.signal, headers, redirect: "manual" });
      activity();
      if ([301, 302, 303, 307, 308].includes(upstream.status)) {
        const location = upstream.headers.get("location");
        await upstream.body?.cancel();
        if (!location) throw new Error("Redirect has no location");
        url = allowedMedia(new URL(location, url).href);
      } else break;
    }
    if (!upstream || [301, 302, 303, 307, 308].includes(upstream.status)) throw new Error("Too many redirects");
    if (!upstream.ok) { await upstream.body?.cancel(); sendJson(response, upstream.status, { error: "Media server rejected this request" }); return; }
    if (/\.m3u8$/i.test(url.pathname) || upstream.headers.get("content-type")?.includes("mpegurl")) {
      const content = await limitedText(upstream, 3 * 1024 * 1024);
      if (!content.trimStart().startsWith("#EXTM3U")) throw new Error("Invalid playlist");
      response.writeHead(200, { "Content-Type": "application/vnd.apple.mpegurl", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" });
      response.end(rewriteManifest(content, url, extra));
    } else if (/\.mpd$/i.test(url.pathname) || upstream.headers.get("content-type")?.includes("dash+xml")) {
      const content = await limitedText(upstream, 3 * 1024 * 1024);
      response.writeHead(200, { "Content-Type": "application/dash+xml", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" });
      response.end(rewriteDash(content, url));
    } else {
      if (!upstream.body) throw new Error("Empty video segment");
      const outputHeaders = { "Content-Type": upstream.headers.get("content-type") || "application/octet-stream", "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" };
      for (const name of ["content-length", "content-range", "accept-ranges"]) {
        if (name === "content-length" && upstream.headers.has("content-encoding")) continue;
        if (upstream.headers.has(name)) outputHeaders[name] = upstream.headers.get(name);
      }
      response.writeHead(upstream.status, outputHeaders);
      const monitor = new Transform({ transform(chunk, _encoding, callback) { activity(); callback(null, chunk); } });
      await pipeline(Readable.fromWeb(upstream.body), monitor, response);
    }
  } finally {
    clearTimeout(timeout); response.off("close", closed);
    const remaining = (activeMedia.get(client) || 1) - 1;
    if (remaining) activeMedia.set(client, remaining); else activeMedia.delete(client);
  }
}

function nodeFetch(url, init = {}) {
  const headers = { "User-Agent": BROWSER_UA, ...(init.headers || {}) };
  return fetch(url, { ...init, headers, redirect: "error", signal: AbortSignal.timeout(15_000) });
}

const nodeSha256hex = async (text) => createHash("sha256").update(text, "utf8").digest("hex");

function checkEmbedUrl(raw, hosts) {
  let url;
  try {
    url = new URL(raw.startsWith("//") ? `https:${raw}` : raw);
  } catch {
    throw Object.assign(new Error("Bad embed URL"), { status: 400 });
  }
  if (url.protocol !== "https:" || url.username || url.password) {
    throw Object.assign(new Error("Bad embed URL"), { status: 400 });
  }
  if (!hosts.test(url.hostname)) throw Object.assign(new Error("Embed host not allowed"), { status: 400 });
  return url.href;
}

async function resolveRoute(request, response, address, kind) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30_000);
  const closed = () => { if (!response.writableEnded) controller.abort(); };
  response.on("close", closed);
  try {
    const raw = address.searchParams.get("url") || "";
    if (!raw || raw.length > 2000) { sendJson(response, 400, { error: "Missing url" }); return; }
    let result;
    if (kind === "alloha") {
      const url = checkEmbedUrl(raw, /^(.+\.)?(alloha\.yani\.tv|stloadi\.live)$/i);
      result = await interceptAlloha((u, init) => nodeFetch(u, init), url, nodeSha256hex);
    } else {
      const url = checkEmbedUrl(raw, /^(.+\.)?yummyani\.me$/i);
      if (!/\/iframeCVH/i.test(new URL(url).pathname)) { sendJson(response, 400, { error: "Not a CVH embed" }); return; }
      result = await interceptCvh((u, init) => nodeFetch(u, init), url);
    }
    sendJson(response, 200, result);
  } catch (err) {
    if (err?.status === 400) sendJson(response, 400, { error: err.message });
    else if (/no signatures|no video data|not found|empty|no streams|no file|file id|signature seed/i.test(err?.message || "")) {
      sendJson(response, 404, { error: err.message });
    } else sendJson(response, 502, { error: "Upstream player did not answer. Try again." });
  } finally { clearTimeout(timeout); response.off("close", closed); }
}

async function voiceMetadata(request, response, videoId) {
  if (!/^[a-f0-9]{24,40}$/i.test(videoId)) { sendJson(response, 400, { error: "Invalid video id" }); return; }
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12_000);
  const closed = () => { if (!response.writableEnded) controller.abort(); };
  response.on("close", closed);
  try {
    const upstream = await fetch(`https://player.aksor.tv/api/video/${videoId}`, {
      headers: { Accept: "application/json", "User-Agent": BROWSER_UA }, signal: controller.signal, redirect: "error",
    });
    if (!upstream.ok) { await upstream.body?.cancel(); sendJson(response, upstream.status, { error: "Voice is unavailable" }); return; }
    const data = JSON.parse(await limitedText(upstream, 96 * 1024));
    if (data.id !== videoId || !data.qualities || typeof data.anime_id !== "number") throw new Error("Invalid voice metadata");
    const qualities = {};
    for (const key of ["q1080", "q720", "q480", "q360"]) {
      if (data.qualities[key]) qualities[key] = allowedMedia(data.qualities[key]).href;
    }
    sendJson(response, 200, { id: data.id, anime_id: data.anime_id, episode: data.episode, qualities,
      opening_start: data.opening_start, opening_length: data.opening_length,
      ending_start: data.ending_start, ending_length: data.ending_length });
  } finally { clearTimeout(timeout); response.off("close", closed); }
}

/** Sibnet publishes its MP4 address only on its own shell page. */
async function resolveSibnet(request, response, videoId) {
  if (!/^\d{4,10}$/.test(videoId)) { sendJson(response, 400, { error: "Invalid video id" }); return; }
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12_000);
  const closed = () => { if (!response.writableEnded) controller.abort(); };
  response.on("close", closed);
  try {
    const upstream = await fetch(`https://video.sibnet.ru/shell.php?videoid=${videoId}`, {
      headers: { Accept: "text/html", Referer: "https://video.sibnet.ru/", "User-Agent": BROWSER_UA },
      signal: controller.signal, redirect: "error",
    });
    if (!upstream.ok) { await upstream.body?.cancel(); sendJson(response, upstream.status, { error: "Video is unavailable" }); return; }
    const html = await limitedText(upstream, 512 * 1024);
    const match = html.match(/player\.src\{[^}]*?src:\s*"([^"]+)"/);
    if (!match) { sendJson(response, 404, { error: "Direct file not published" }); return; }
    const file = allowedMedia(new URL(match[1], "https://video.sibnet.ru/").href);
    sendJson(response, 200, { id: videoId, url: file.href });
  } finally { clearTimeout(timeout); response.off("close", closed); }
}

async function catalog(request, response, address, provider) {
  const prefix = `/api/kurenai/${provider}`;
  const path = address.pathname.slice(prefix.length);
  const valid = provider === "libria"
    ? /^(?:\/anime\/releases\/[a-z0-9-]+|\/anime\/catalog\/releases|\/anime\/catalog\/references\/(?:genres|years)|\/anime\/schedule\/week|\/app\/search\/releases)$/i.test(path)
    : /^(?:\/anime|\/anime\/(?:\d+|genres|counts\/types)|\/anime\/\d+\/videos|\/search)$/.test(path);
  if (!valid || address.search.length > 2500) { sendJson(response, 400, { error: "Unsupported catalog request" }); return; }
  const hosts = provider === "libria" ? ["https://aniliberty.top/api/v1", "https://anilibria.top/api/v1"] : ["https://api.yani.tv"];
  const deadline = AbortSignal.timeout(16_000);
  const headers = { Accept: "application/json, image/webp", "User-Agent": BROWSER_UA };
  if (provider === "yummy") {
    const supplied = typeof request.headers["x-application"] === "string" ? request.headers["x-application"] : "";
    const token = applicationToken || supplied;
    if (token.length > 1500 || /[\r\n]/.test(token)) { sendJson(response, 400, { error: "Invalid application token" }); return; }
    if (token) headers["X-Application"] = token;
  }
  for (const host of hosts) {
    let upstream;
    try {
      let target = new URL(`${host}${path}${address.search}`);
      const allowedHosts = provider === "libria" ? ["aniliberty.top", "www.aniliberty.top", "anilibria.top", "www.anilibria.top"] : ["api.yani.tv"];
      for (let redirects = 0; redirects < 4; redirects++) {
        if (target.protocol !== "https:" || target.username || target.password || !allowedHosts.includes(target.hostname)) throw new Error("Untrusted catalog redirect");
        upstream = await fetch(target, { headers, signal: AbortSignal.any([deadline, AbortSignal.timeout(7000)]), redirect: "manual" });
        if (![301, 302, 303, 307, 308].includes(upstream.status)) break;
        const location = upstream.headers.get("location");
        await upstream.body?.cancel();
        if (!location) throw new Error("Missing catalog redirect");
        target = new URL(location, target);
      }
      if (!upstream || [301, 302, 303, 307, 308].includes(upstream.status)) throw new Error("Too many redirects");
      if (upstream.status >= 500 && host !== hosts[hosts.length - 1]) { await upstream.body?.cancel(); continue; }
      const content = await limitedText(upstream, 14 * 1024 * 1024);
      JSON.parse(content);
      response.writeHead(upstream.status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" });
      response.end(content);
      return;
    } catch { if (host === hosts[hosts.length - 1]) throw new Error("Catalog request failed"); }
  }
}

const server = createServer(async (request, response) => {
  try {
    if (!request.url || request.url.length > 7000) { sendJson(response, 414, { error: "Request is too long" }); return; }
    const address = new URL(request.url, "http://localhost");
    const client = request.socket.remoteAddress || "unknown";
    if (address.pathname.startsWith("/api/")) {
      if (request.method !== "GET") { sendJson(response, 405, { error: "GET required" }); return; }
      const slot = `${client}:${Math.floor(Date.now() / 60000)}`;
      const used = (rate.get(slot) || 0) + 1;
      rate.set(slot, used);
      if (rate.size > 10_000) rate.clear();
      if (used > 900) { sendJson(response, 429, { error: "Rate limit" }); return; }
      if (address.pathname === "/api/kurenai/status") {
        sendJson(response, 200, { service: "kurenai-gateway", version: 4, yummyConfigured: Boolean(applicationToken), mediaProxy: true, directVoices: true, allohaResolver: true, cvhResolver: true, sibnetResolver: true });
        return;
      }
      if (address.pathname.startsWith("/api/kurenai/voice/")) { await voiceMetadata(request, response, address.pathname.slice("/api/kurenai/voice/".length)); return; }
      if (address.pathname.startsWith("/api/kurenai/resolve/sibnet/")) { await resolveSibnet(request, response, address.pathname.slice("/api/kurenai/resolve/sibnet/".length)); return; }
      if (address.pathname === "/api/kurenai/resolve/alloha") { await resolveRoute(request, response, address, "alloha"); return; }
      if (address.pathname === "/api/kurenai/resolve/cvh") { await resolveRoute(request, response, address, "cvh"); return; }
      if (address.pathname === "/api/kurenai/media") { await media(request, response, address, client); return; }
      if (address.pathname.startsWith("/api/kurenai/libria/")) { await catalog(request, response, address, "libria"); return; }
      if (address.pathname.startsWith("/api/kurenai/yummy/")) { await catalog(request, response, address, "yummy"); return; }
      sendJson(response, 404, { error: "Unknown endpoint" }); return;
    }
    if (request.method !== "GET" && request.method !== "HEAD") { response.writeHead(405); response.end(); return; }
    const decoded = decodeURIComponent(address.pathname);
    let file = resolve(root, `.${decoded === "/" ? "/index.html" : decoded}`);
    if (!file.startsWith(root + sep) && file !== resolve(root, "index.html")) { response.writeHead(403); response.end(); return; }
    let info;
    try { info = await stat(file); if (!info.isFile()) throw new Error("Not a file"); }
    catch {
      if (extname(decoded)) { response.writeHead(404); response.end(); return; }
      file = resolve(root, "index.html"); info = await stat(file);
    }
    response.writeHead(200, { "Content-Type": types[extname(file)] || "application/octet-stream", "Content-Length": info.size,
      "Cache-Control": file.endsWith("index.html") || file.endsWith("sw.js") ? "no-cache" : "public, max-age=3600", "X-Content-Type-Options": "nosniff" });
    if (request.method === "HEAD") response.end(); else await pipeline(createReadStream(file), response);
  } catch {
    if (!response.headersSent) sendJson(response, 502, { error: "Не удалось подключиться к источнику. Попробуйте позже." });
    else response.destroy();
  }
});

server.listen(port, () => { console.info(`Kurenai is listening on port ${port}`); });
