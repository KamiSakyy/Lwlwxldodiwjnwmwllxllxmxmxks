# Optional First-Party Gateway

The app normally talks to the current v1 catalog and the additional catalog
directly. A frontend cannot override CORS, regional restrictions, or upstream
authorization. The gateway is supplied for a deployment you control; it is not
running merely because the static frontend has been built.

After producing the normal `dist/` build, use Node.js 20 or later to start
`server/gateway.mjs`. The entry command is `node server/gateway.mjs`.
The default port is 8080; set `PORT` to change it. Put a production HTTPS reverse
proxy in front of the process. Serve the built UI and gateway on the same origin.
No Vite configuration changes or third-party public CORS services are required.

Optional environment variable: `YUMMY_APPLICATION_TOKEN`. Obtain your own public
application token from the catalog's developer portal. Do not commit credentials.
This variable stays on the server. The browser can also submit its own public
application token from the connection settings for a personal session.

The UI detects `/api/kurenai/status`. It uses the gateway when present and direct
requests otherwise. API routes are read-only and allowlisted. The media gateway
only allows HTTPS `/videos/` resources on the primary CDN domain, validates every
redirect, rewrites nested playlists and preserves query parameters, keys and
byte ranges. It forwards access-denied responses instead of bypassing them.
The additional adapter reads public per-video metadata, not embedded HTML or a
hidden video player. `/api/kurenai/voice/{id}` forwards only validated metadata;
`/api/kurenai/media` also allows HTTPS paths under `*.takehost-cdn.aksor.tv/static*/video/`
and `video.sibnet.ru/sh/`. `/api/kurenai/resolve/sibnet/{videoid}` reads the
Sibnet page for its published MP4 and returns it only when the address matches
the allowlist. The UI uses one video element for HLS, DASH and MP4. Every
catalogued voice stays listed; voices whose provider publishes no direct stream
fail with an explicit message instead of being hidden or replaced by a hidden
player. See `docs/UPDATE-V6.md` for details.

Use your own rate limits, process monitoring, request-size restrictions and TLS
configuration for a public deployment. No request URLs or application keys are
logged by the gateway. Check the provider's usage terms and secure permission
for commercial use. The frontend does not assert a catalog size or a license to
distribute every title.

Manual checks after deployment:

1. Status should identify `kurenai-gateway` without returning any token.
2. `/#/connections` should pass catalog and playlist checks.
3. Media URLs outside the allowlist must return an error, never be fetched.
4. Denied upstream video stays denied; cookies and authorization are not forged.
5. Byte-range requests and nested playlists should load through the same origin.
6. Test actual playback and downloads on the target Android device.