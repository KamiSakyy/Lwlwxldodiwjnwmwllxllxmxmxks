# R8 full mode: optimize and repackage application classes; keep only the JNI bridge contract.
-allowaccessmodification
-repackageclasses obf
-renamesourcefileattribute SourceFile
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# The bridge class and native method names are looked up by JNI_OnLoad/RegisterNatives.
-keep class com.webapk.security.N {
    public static byte[] k();
    private static native byte[] n();
}
